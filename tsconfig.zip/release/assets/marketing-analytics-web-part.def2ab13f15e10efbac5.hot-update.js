"use strict";
self["webpackHotUpdated4faa06d_862f_4712_a355_4e54547f85f3_0_0_1"]("marketing-analytics-web-part",{

/***/ 5440:
/*!***************************************************************************************!*\
  !*** ./lib/webparts/marketingAnalytics/components/SEOIntelligence/SEOIntelligence.js ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 196);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 5959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SEOIntelligence.module.scss */ 7356);
/* harmony import */ var primereact_chart__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! primereact/chart */ 4964);
/* harmony import */ var _pnp_sp__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @pnp/sp */ 2011);
/* harmony import */ var primereact_datatable__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! primereact/datatable */ 164);
/* harmony import */ var primereact_column__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! primereact/column */ 1182);








var MONTHS = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
];
function defaultYearMonth() {
    var now = new Date();
    return {
        year: now.getFullYear(),
        month: now.getMonth() + 1,
        label: "".concat(MONTHS[now.getMonth()], " ").concat(now.getFullYear()),
    };
}
function filterByYearMonth(items, ym) {
    return items.filter(function (item) {
        if (!item.Date)
            return true;
        var d = new Date(item.Date);
        if (isNaN(d.getTime())) {
            console.warn("Invalid date:", item.Date);
            return true;
        }
        if (d.getFullYear() !== ym.year)
            return false;
        if (ym.month !== null && d.getMonth() + 1 !== ym.month)
            return false;
        return true;
    });
}
// ─── Inline YearMonthPicker ───────────────────────────────────────────────────
var YearMonthPicker = function (_a) {
    var _b;
    var value = _a.value, onChange = _a.onChange, _c = _a.minYear, minYear = _c === void 0 ? 2020 : _c;
    var currentYear = new Date().getFullYear();
    var years = Array.from({ length: currentYear - minYear + 1 }, function (_, i) { return currentYear - i; });
    var handleYear = function (e) {
        var year = Number(e.target.value);
        var label = value.month
            ? "".concat(MONTHS[value.month - 1], " ").concat(year)
            : "Full Year ".concat(year);
        onChange((0,tslib__WEBPACK_IMPORTED_MODULE_3__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_3__.__assign)({}, value), { year: year, label: label }));
    };
    var handleMonth = function (e) {
        var month = e.target.value === "0" ? null : Number(e.target.value);
        var label = month
            ? "".concat(MONTHS[month - 1], " ").concat(value.year)
            : "Full Year ".concat(value.year);
        onChange((0,tslib__WEBPACK_IMPORTED_MODULE_3__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_3__.__assign)({}, value), { month: month, label: label }));
    };
    var chevronSvg = "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'%3E%3Cpath d='M1 1l4 4 4-4' stroke='%2394a3b8' stroke-width='1.5' fill='none' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E\")";
    var selectStyle = {
        appearance: "none",
        WebkitAppearance: "none",
        border: "none",
        background: "transparent",
        fontSize: 13,
        fontWeight: 500,
        color: "#334155",
        cursor: "pointer",
        padding: "0 20px 0 2px",
        backgroundImage: chevronSvg,
        backgroundRepeat: "no-repeat",
        backgroundPosition: "right 2px center",
        outline: "none",
    };
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { style: {
            display: "flex",
            alignItems: "center",
            gap: 6,
            background: "#fff",
            border: "1px solid #e2e8f0",
            borderRadius: 8,
            padding: "6px 10px",
            boxShadow: "0 1px 3px rgba(0,0,0,0.06)",
        } },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { style: { fontSize: 14 } }, "\uD83D\uDCC5"),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("select", { style: selectStyle, value: value.year, onChange: handleYear }, years.map(function (y) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("option", { key: y, value: y }, y)); })),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { style: { fontSize: 13, color: "#cbd5e1", userSelect: "none" } }, "/"),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("select", { style: selectStyle, value: (_b = value.month) !== null && _b !== void 0 ? _b : 0, onChange: handleMonth },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("option", { value: 0 }, "All Months"),
            MONTHS.map(function (m, i) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("option", { key: i + 1, value: i + 1 }, m)); }))));
};
// ─── Aggregation ──────────────────────────────────────────────────────────────
function aggregateFromSPData(keywords, backlinks, _topPages) {
    if (!keywords.length && !backlinks.length)
        return null;
    var keywordsTop10 = keywords.filter(function (k) { return k.AvgPosition <= 10; }).length;
    var totalBacklinksObj = backlinks.find(function (k) { var _a; return ((_a = k.Metric) === null || _a === void 0 ? void 0 : _a.trim()) === "Total Backlinks"; });
    var totalBacklinks = totalBacklinksObj
        ? Number((totalBacklinksObj.Value || "0").replace(/,/g, ""))
        : 0;
    console.log(totalBacklinks, "totalBacklinks");
    var kwImprovedObj = backlinks.find(function (k) { return k.Metric === "KW Rank Improved"; });
    var kwImproved = kwImprovedObj
        ? Number((kwImprovedObj.Value || "0").replace(/,/g, ""))
        : 0;
    var seoLeads = keywords.reduce(function (sum, k) { return sum + k.Clicks; }, 0);
    var rankDist = {
        top10: keywords.filter(function (k) { return k.AvgPosition <= 10; }).length,
        rank11_50: keywords.filter(function (k) { return k.AvgPosition > 10 && k.AvgPosition <= 50; })
            .length,
        rank51_100: keywords.filter(function (k) { return k.AvgPosition > 50 && k.AvgPosition <= 100; }).length,
        notRanked: keywords.filter(function (k) { return k.AvgPosition > 100; }).length,
    };
    var keywordRows = keywords
        .filter(function (k) { return k.AvgPosition <= 10; })
        .map(function (k) { return ({
        keyword: k.Keyword,
        prevRank: "—",
        currRank: "#".concat(Math.round(k.AvgPosition)),
        change: 0,
        volume: k.Impressions.toLocaleString(),
        status: "Top 10",
    }); });
    var backlinkMetrics = backlinks.map(function (b) { return ({
        label: b.Metric,
        value: b.Value.toLocaleString(),
        isDelta: false,
        deltaUp: false,
    }); });
    var rankDistMonths = [(0,tslib__WEBPACK_IMPORTED_MODULE_3__.__assign)({ label: "Current" }, rankDist)];
    var backlinkTrend = [
        { label: "Current", backlinks: Number(totalBacklinks), domains: 0 },
    ];
    return {
        keywordsTop10: keywordsTop10,
        totalBacklinks: totalBacklinks,
        kwImproved: kwImproved,
        seoLeads: seoLeads,
        rankDist: rankDist,
        rankDistMonths: rankDistMonths,
        backlinkTrend: backlinkTrend,
        backlinkMetrics: backlinkMetrics,
        kwSummary: {
            improved: Number(kwImproved),
            declined: keywords.filter(function (k) { return k.Status === "Declined"; }).length,
            unchanged: keywords.filter(function (k) { return k.Status === "Unchanged"; }).length,
        },
        keywordRows: keywordRows,
    };
}
// ─── KpiCard ──────────────────────────────────────────────────────────────────
var KpiCard = function (p) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpi },
    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiTop },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiIcon, style: { background: p.iconBg } }, p.icon),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "".concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiDelta, " ").concat(p.deltaType === "up"
                ? _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].deltaUp
                : p.deltaType === "dn"
                    ? _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].deltaDn
                    : _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].deltaFlat) }, p.deltaText)),
    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiLabel }, p.label),
    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiVal }, p.value),
    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiSub }, p.sub),
    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiAccent, style: { background: p.accentColor } }))); };
// ─── Charts ───────────────────────────────────────────────────────────────────
var RankDistChart = function (_a) {
    var data = _a.data;
    var chartData = {
        labels: data.map(function (d) { return d.label; }),
        datasets: [
            {
                label: "Top 1-10",
                data: data.map(function (d) { return d.top10; }),
                backgroundColor: "#059669",
            },
            {
                label: "11-50",
                data: data.map(function (d) { return d.rank11_50; }),
                backgroundColor: "#0891b2",
            },
            {
                label: "51-100",
                data: data.map(function (d) { return d.rank51_100; }),
                backgroundColor: "#d97706",
            },
            {
                label: "Not Ranked",
                data: data.map(function (d) { return d.notRanked; }),
                backgroundColor: "#e11d48",
            },
        ],
    };
    var options = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { position: "bottom" } },
        scales: { x: { stacked: true }, y: { stacked: true } },
    };
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].chartWrapper }, data.length === 0 ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].emptyChart }, "\uD83D\uDCED No data")) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_chart__WEBPACK_IMPORTED_MODULE_4__.Chart, { type: "bar", data: chartData, options: options }))));
};
var BacklinkGrowthChart = function (_a) {
    var data = _a.data;
    var chartData = {
        labels: data.map(function (d) { return d.label; }),
        datasets: [
            {
                label: "Total Backlinks",
                data: data.map(function (d) { return d.backlinks; }),
                borderColor: "#1a6ef5",
                backgroundColor: "rgba(26,110,245,0.1)",
                tension: 0.4,
                fill: true,
            },
            {
                label: "Referring Domains",
                data: data.map(function (d) { return d.domains; }),
                borderColor: "#7c3aed",
                backgroundColor: "rgba(124,58,237,0.1)",
                tension: 0.4,
                fill: true,
            },
        ],
    };
    var options = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { position: "bottom" } },
    };
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].chartWrapper }, data.length === 0 ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].emptyChart }, "\uD83D\uDCED No data")) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_chart__WEBPACK_IMPORTED_MODULE_4__.Chart, { type: "line", data: chartData, options: options }))));
};
var SeoIntelligenceDashboard = function () {
    var _a = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(defaultYearMonth()), yearMonth = _a[0], setYearMonth = _a[1];
    var _b = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null), aggregated = _b[0], setAggregated = _b[1];
    var _c = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false), loading = _c[0], setLoading = _c[1];
    var _d = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(""), rangeLabel = _d[0], setRangeLabel = _d[1];
    var _e = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null), error = _e[0], setError = _e[1];
    var _f = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]), keywordData = _f[0], setKeywordData = _f[1];
    var _g = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]), topPageData = _g[0], setTopPageData = _g[1];
    var _h = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]), backlinkData = _h[0], setBacklinkData = _h[1];
    var fetchKeywordData = function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(void 0, void 0, void 0, function () {
        var res, err_1;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, _pnp_sp__WEBPACK_IMPORTED_MODULE_2__.sp.web.lists
                            .getByTitle("SEOIntelligence-KeywordRankings")
                            .items.select("ID", "Keyword", "Clicks", "Impressions", "CTR", "AvgPosition", "Status", "Date")
                            .orderBy("Date", false)
                            .getAll()];
                case 1:
                    res = _a.sent();
                    setKeywordData(res.map(function (item) { return ({
                        ID: item.ID,
                        Keyword: item.Keyword,
                        Clicks: Number(item.Clicks || 0),
                        Impressions: Number(item.Impressions || 0),
                        CTR: Number(item.CTR || 0),
                        AvgPosition: Number(item.AvgPosition || 0),
                        Status: item.Status,
                        Date: item.Date || null,
                    }); }));
                    return [3 /*break*/, 3];
                case 2:
                    err_1 = _a.sent();
                    console.error("Keyword fetch error:", err_1);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var fetchTopPageData = function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(void 0, void 0, void 0, function () {
        var res, err_2;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, _pnp_sp__WEBPACK_IMPORTED_MODULE_2__.sp.web.lists
                            .getByTitle("SEOIntelligence-TopPagesDetails(GSC)")
                            .items.select("ID", "PageURL", "Clicks", "Impressions", "CTR", "AvgPosition", "Date")
                            .orderBy("Date", false)
                            .getAll()];
                case 1:
                    res = _a.sent();
                    setTopPageData(res.map(function (item) { return ({
                        ID: item.ID,
                        PageURL: item.PageURL,
                        Clicks: Number(item.Clicks || 0),
                        Impressions: Number(item.Impressions || 0),
                        CTR: Number(item.CTR || 0),
                        AvgPosition: Number(item.AvgPosition || 0),
                        Date: item.Date || null,
                    }); }));
                    return [3 /*break*/, 3];
                case 2:
                    err_2 = _a.sent();
                    console.error("TopPage fetch error:", err_2);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var fetchBacklinkData = function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(void 0, void 0, void 0, function () {
        var res, err_3;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, _pnp_sp__WEBPACK_IMPORTED_MODULE_2__.sp.web.lists
                            .getByTitle("SEOIntelligence-BacklinkSummary")
                            .items.select("ID", "Metric", "Value", "Notes", "Date")
                            .orderBy("Date", false)
                            .getAll()];
                case 1:
                    res = _a.sent();
                    setBacklinkData(res.map(function (item) { return ({
                        ID: item.ID,
                        Metric: item.Metric,
                        Value: item.Value || 0,
                        Notes: item.Notes,
                        Date: item.Date || null,
                    }); }));
                    return [3 /*break*/, 3];
                case 2:
                    err_3 = _a.sent();
                    console.error("Backlink fetch error:", err_3);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function () {
        setLoading(true);
        (fetchKeywordData(), fetchTopPageData(), fetchBacklinkData());
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function () {
        setLoading(true);
        var timer = setTimeout(function () {
            var filteredKeywords = filterByYearMonth(keywordData, yearMonth);
            var filteredBacklinks = filterByYearMonth(backlinkData, yearMonth);
            var filteredTopPages = filterByYearMonth(topPageData, yearMonth);
            var agg = aggregateFromSPData(filteredKeywords, filteredBacklinks, filteredTopPages);
            setAggregated(agg);
            setRangeLabel(yearMonth.label);
            setLoading(false);
        }, 250);
        return function () { return clearTimeout(timer); };
    }, [yearMonth, keywordData, backlinkData, topPageData]);
    var noData = !aggregated;
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].seoDashboard },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].topHeader },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].topTitle }, "SEO Intelligence"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].topSub }, "GSC + Excel \u00B7 Keyword & backlink data")),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].topRight },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].secActions },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(YearMonthPicker, { value: yearMonth, onChange: setYearMonth, minYear: 2020 }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "".concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].sourceBadge, " ").concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].badgeBlue) }, "\uD83D\uDD17 GSC Connected"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].topBtnPrimary }, "Refresh")))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].secHeader },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].secTitleWrap },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].secIcon, style: { background: "#fef3c7" } }, "\uD83D\uDD0D"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].secTitle }, "SEO Performance"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].secSub },
                        "Google Search Console \u00B7 ",
                        rangeLabel))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "".concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].sourceBadge, " ").concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].badgeGreen) }, "\uD83D\uDCCA Excel")),
        error && react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
            "\u26A0\uFE0F ",
            error),
        loading && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].loadingBar },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].loadingFill }))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].g4 },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(KpiCard, { icon: "\uD83D\uDCC8", iconBg: "#d1fae5", accentColor: "#059669", deltaText: noData ? "—" : "\u25B2 ".concat(aggregated.keywordsTop10, " keywords"), deltaType: noData ? "flat" : "up", label: "Keywords Top-10", value: noData ? "—" : String(aggregated.keywordsTop10), sub: "Ranking page 1" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(KpiCard, { icon: "\uD83D\uDD17", iconBg: "#e8f0fe", accentColor: "#1a6ef5", deltaText: noData
                    ? "—"
                    : "\u25B2 Latest ".concat(aggregated.totalBacklinks.toLocaleString()), deltaType: noData ? "flat" : "up", label: "Total Backlinks", value: noData ? "—" : aggregated.totalBacklinks.toLocaleString(), sub: "Acquired in range" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(KpiCard, { icon: "\u2B06\uFE0F", iconBg: "#fef3c7", accentColor: "#d97706", deltaText: noData ? "—" : "\u25B2 ".concat(aggregated.kwImproved, " improved"), deltaType: noData ? "flat" : "up", label: "Kw Rank Improved", value: noData ? "—" : String(aggregated.kwImproved), sub: "vs previous period" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(KpiCard, { icon: "\uD83C\uDFAF", iconBg: "#e0f5fa", accentColor: "#0891b2", deltaText: noData ? "—" : "\u25B2 ".concat(aggregated.seoLeads, " leads"), deltaType: noData ? "flat" : "up", label: "SEO Leads", value: noData ? "—" : aggregated.seoLeads.toLocaleString(), sub: "Organic conversions" })),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "".concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].g2, " ").concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].mt) },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].card },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardHead },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardTitle }, "Keyword Rank Distribution"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardSub },
                            "How keywords are spread across positions \u00B7 ",
                            yearMonth.label))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(RankDistChart, { data: noData ? [] : aggregated.rankDistMonths })),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].card },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardHead },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardTitle }, "Backlink Growth"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardSub },
                            "Total backlinks vs referring domains \u00B7 ",
                            yearMonth.label))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(BacklinkGrowthChart, { data: noData ? [] : aggregated.backlinkTrend }))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "".concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].g2, " ").concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].mt) },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].card },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardHead },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardTitle }, "Keyword Rankings Detail"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardSub },
                            "Top commercial-intent keywords \u00B7 ",
                            yearMonth.label))),
                noData ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].emptyState }, "\uD83D\uDCED No data found for selected period.")) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_datatable__WEBPACK_IMPORTED_MODULE_5__.DataTable, { value: (aggregated === null || aggregated === void 0 ? void 0 : aggregated.keywordRows) || [], paginator: true, rows: 10 },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_column__WEBPACK_IMPORTED_MODULE_6__.Column, { field: "keyword", header: "Keyword" }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_column__WEBPACK_IMPORTED_MODULE_6__.Column, { field: "prevRank", header: "Prev Rank" }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_column__WEBPACK_IMPORTED_MODULE_6__.Column, { field: "currRank", header: "Curr Rank" }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_column__WEBPACK_IMPORTED_MODULE_6__.Column, { field: "change", header: "Change", body: function (rowData) {
                            var isUp = rowData.change > 0;
                            return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "".concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].delta, " ").concat(isUp
                                    ? _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].deltaUp
                                    : rowData.change < 0
                                        ? _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].deltaDn
                                        : _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].deltaFlat) }, isUp
                                ? "\u25B2+".concat(rowData.change)
                                : rowData.change < 0
                                    ? "\u25BC".concat(rowData.change)
                                    : "—"));
                        } }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_column__WEBPACK_IMPORTED_MODULE_6__.Column, { field: "volume", header: "Volume" }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_column__WEBPACK_IMPORTED_MODULE_6__.Column, { field: "status", header: "Status", body: function (rowData) {
                            var statusClass = rowData.status === "Improved"
                                ? _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].pillGreen
                                : rowData.status === "Declined"
                                    ? _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].pillRose
                                    : _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].pillGray;
                            return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "".concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].pill, " ").concat(statusClass) }, rowData.status));
                        } })))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].card },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardHead },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardTitle }, "Backlinks \u2014 Selected Period"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardSub },
                            "Quality & growth metrics \u00B7 ",
                            yearMonth.label))),
                noData ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].emptyState }, "\uD83D\uDCED No data found for selected period.")) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
                    aggregated.backlinkMetrics.map(function (m, i) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].miniM, key: i },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].miniLabel }, m.label),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "".concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].miniVal, " ").concat(m.isDelta
                                ? m.deltaUp
                                    ? _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].deltaUp
                                    : _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].deltaDn
                                : "") }, m.value))); }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].divider }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardHead, style: { marginBottom: 8 } },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardTitle }, "Keywords Improved vs Declined")),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kwSummaryRow },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "".concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kwSummaryBox, " ").concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kwSummaryGreen) },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kwSummaryNum, style: { color: "#059669" } }, aggregated.kwSummary.improved),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kwSummaryLbl, style: { color: "#059669" } }, "Keywords \u25B2 Improved")),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "".concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kwSummaryBox, " ").concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kwSummaryRose) },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kwSummaryNum, style: { color: "#e11d48" } }, aggregated.kwSummary.declined),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kwSummaryLbl, style: { color: "#e11d48" } }, "Keywords \u25BC Declined")),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "".concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kwSummaryBox, " ").concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kwSummaryGray) },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kwSummaryNum, style: { color: "#4a5a7a" } }, aggregated.kwSummary.unchanged),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kwSummaryLbl, style: { color: "#8a9bbf" } }, "Unchanged")))))))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SeoIntelligenceDashboard);


/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("2c1c9fb4951c1f2c720e")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=marketing-analytics-web-part.def2ab13f15e10efbac5.hot-update.js.map