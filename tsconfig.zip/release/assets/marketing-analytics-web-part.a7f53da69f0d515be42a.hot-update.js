"use strict";
self["webpackHotUpdated4faa06d_862f_4712_a355_4e54547f85f3_0_0_1"]("marketing-analytics-web-part",{

/***/ 2872:
/*!*******************************************************************************************!*\
  !*** ./lib/webparts/marketingAnalytics/components/LeadsIntelligence/LeadsIntelligence.js ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 196);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 5959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./LeadsIntelligence.module.scss */ 6412);
/* harmony import */ var _DatePicker_DatePicker__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../DatePicker/DatePicker */ 8938);
/* harmony import */ var primereact_chart__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! primereact/chart */ 4964);
/* harmony import */ var _pnp_sp__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @pnp/sp */ 2011);







// ─── Helpers ─────────────────────────────────────────────────────────────────
function defaultRange() {
    var start = new Date();
    start.setDate(1);
    start.setHours(0, 0, 0, 0); // start of first day of current month
    var end = new Date();
    end.setHours(23, 59, 59, 999); // end of today (not midnight!)
    return {
        startDate: start,
        endDate: end,
        label: "This Month",
    };
}
/**
 * Parse a SharePoint date string safely in LOCAL time.
 * SharePoint returns ISO strings like "2024-06-15T00:00:00Z".
 * If parsed directly, browsers shift by UTC offset (e.g. IST = UTC+5:30
 * turns June 15 into June 14 at 18:30 local), breaking date comparisons.
 * We strip the time part and construct a local-midnight Date instead.
 */
function parseSharePointDate(raw) {
    if (!raw)
        return null;
    try {
        var datePart = raw.split("T")[0]; // "2024-06-15"
        var _a = datePart.split("-").map(Number), y = _a[0], m = _a[1], d = _a[2];
        if (!y || !m || !d)
            return null;
        return new Date(y, m - 1, d); // local midnight — no timezone shift
    }
    catch (_b) {
        return null;
    }
}
var SOURCE_META_LIST = [
    {
        key: "Google Ads",
        icon: "🔍",
        iconBg: "#ffe4e6",
        meta: "Search campaigns",
        countColor: "#e11d48",
    },
    {
        key: "Organic",
        icon: "🌐",
        iconBg: "#e0f5fa",
        meta: "Contact form · SEO",
        countColor: "#0891b2",
    },
    {
        key: "Email",
        icon: "✉️",
        iconBg: "#d1fae5",
        meta: "Campaign emails",
        countColor: "#059669",
    },
    {
        key: "LinkedIn Ads",
        icon: "💼",
        iconBg: "#e8f0fe",
        meta: "Sponsored + InMail",
        countColor: "#1a6ef5",
    },
];
var PILL_MAP = {
    "Google Ads": { source: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].pillBlue, status: "" },
    "LinkedIn Ads": { source: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].pillViolet, status: "" },
    Email: { source: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].pillGreen, status: "" },
    Organic: { source: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].pillTeal, status: "" },
    Qualified: { source: "", status: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].pillGreen },
    Junk: { source: "", status: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].pillRose },
    Review: { source: "", status: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].pillAmber },
};
// ─── Chart: Lead Source Bar ───────────────────────────────────────────────────
var LeadSourceChart = function (_a) {
    var _b, _c, _d, _e;
    var data = _a.data;
    var labels = ["Google Ads", "Website/SEO", "Email", "LinkedIn Ads"];
    var chartData = {
        labels: labels,
        datasets: [
            {
                label: "Leads",
                backgroundColor: ["#e11d48", "#0891b2", "#059669", "#2563eb"],
                borderRadius: 8,
                barThickness: 36,
                data: [
                    (_b = data["Google Ads"]) !== null && _b !== void 0 ? _b : 0,
                    (_c = data["Organic"]) !== null && _c !== void 0 ? _c : 0,
                    (_d = data["Email"]) !== null && _d !== void 0 ? _d : 0,
                    (_e = data["LinkedIn Ads"]) !== null && _e !== void 0 ? _e : 0,
                ],
            },
        ],
    };
    var options = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
            x: {
                grid: { display: false },
                ticks: { color: "#64748b", font: { size: 11 } },
            },
            y: {
                beginAtZero: true,
                ticks: { color: "#94a3b8", font: { size: 11 } },
                grid: { color: "#e5e7eb", drawBorder: false },
            },
        },
    };
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].chartWrapper },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_chart__WEBPACK_IMPORTED_MODULE_4__.Chart, { type: "bar", data: chartData, options: options })));
};
var LeadQualityChart = function (_a) {
    var qualified = _a.qualified, review = _a.review, junk = _a.junk;
    var chartData = {
        labels: ["Qualified", "In Review", "Junk"],
        datasets: [
            {
                data: [qualified, review, junk],
                backgroundColor: ["#059669", "#d97706", "#e11d48"],
                borderWidth: 0,
            },
        ],
    };
    var options = {
        responsive: true,
        maintainAspectRatio: false,
        cutout: "65%",
        plugins: {
            legend: {
                position: "bottom",
                labels: {
                    color: "#64748b",
                    boxWidth: 14,
                    padding: 20,
                    font: { size: 11 },
                },
            },
        },
    };
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].chartWrapper },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_chart__WEBPACK_IMPORTED_MODULE_4__.Chart, { type: "doughnut", data: chartData, options: options })));
};
// ─── Main Component ───────────────────────────────────────────────────────────
var LeadsIntelligenceDashboard = function () {
    var _a = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(defaultRange()), dateRange = _a[0], setDateRange = _a[1];
    var _b = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false), loading = _b[0], setLoading = _b[1];
    var _c = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]), leadData = _c[0], setLeadData = _c[1];
    // ── Fetch from SharePoint
    var fetchLeadData = function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(void 0, void 0, void 0, function () {
        var response, formatted, err_1;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0:
                    setLoading(true);
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 3, 4, 5]);
                    return [4 /*yield*/, _pnp_sp__WEBPACK_IMPORTED_MODULE_3__.sp.web.lists
                            .getByTitle("MarketingAnalytics-LeadsIntelligenceDetails")
                            .items.select("ID", "Date", "LeadName", "PhoneNumber", "CompanyName", "EmailId", "Enquiry", "Source", "Campaign", "Country", "Notes", "Status")
                            .orderBy("Date", false)
                            .getAll()];
                case 2:
                    response = _a.sent();
                    formatted = response.map(function (item) { return ({
                        id: item.ID,
                        // ✅ FIX: Use parseSharePointDate to avoid UTC→local timezone shift
                        date: parseSharePointDate(item.Date),
                        leadName: item.LeadName || "",
                        phoneNumber: item.PhoneNumber || "",
                        companyName: item.CompanyName || "",
                        email: item.EmailId || "",
                        enquiry: item.Enquiry || "",
                        source: item.Source || "",
                        campaign: item.Campaign || "",
                        country: item.Country || "",
                        notes: item.Notes || "",
                        status: item.Status || "",
                    }); });
                    setLeadData(formatted);
                    return [3 /*break*/, 5];
                case 3:
                    err_1 = _a.sent();
                    console.error("Failed to fetch leads:", err_1);
                    return [3 /*break*/, 5];
                case 4:
                    setLoading(false);
                    return [7 /*endfinally*/];
                case 5: return [2 /*return*/];
            }
        });
    }); };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function () {
        fetchLeadData();
    }, []);
    // Debounced loading indicator on date change
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function () {
        setLoading(true);
        var t = setTimeout(function () { return setLoading(false); }, 300);
        return function () { return clearTimeout(t); };
    }, [dateRange]);
    // ── Filter leadData by date range
    // ✅ FIX: Normalise both bounds so entire start-day and end-day are included
    var filtered = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
        var start = new Date(dateRange.startDate);
        start.setHours(0, 0, 0, 0); // beginning of start day
        var end = new Date(dateRange.endDate);
        end.setHours(23, 59, 59, 999); // end of end day — captures full day
        return leadData.filter(function (l) {
            if (!l.date)
                return false;
            return l.date >= start && l.date <= end;
        });
    }, [leadData, dateRange]);
    // ── Aggregate KPIs from filtered leadData
    var kpis = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
        var total = filtered.length;
        var qualified = filtered.filter(function (l) { return l.status.toLowerCase() === "qualified"; }).length;
        var junk = filtered.filter(function (l) { return l.status.toLowerCase() === "junk"; }).length;
        var review = filtered.filter(function (l) { return l.status.toLowerCase() === "review"; }).length;
        var qualRate = total > 0 ? ((qualified / total) * 100).toFixed(1) : "0";
        var junkRate = total > 0 ? ((junk / total) * 100).toFixed(1) : "0";
        return { total: total, qualified: qualified, junk: junk, review: review, qualRate: qualRate, junkRate: junkRate };
    }, [filtered]);
    // ── Per-source counts from filtered leadData
    var sourceCounts = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
        var counts = {
            "Google Ads": 0,
            Organic: 0,
            Email: 0,
            "LinkedIn Ads": 0,
        };
        filtered.forEach(function (l) {
            if (l.source in counts) {
                counts[l.source] += 1;
            }
        });
        return counts;
    }, [filtered]);
    var KPI_CARDS = [
        {
            icon: "📥",
            iconBg: "#e8f0fe",
            accentColor: "#1a6ef5",
            deltaText: "▲ 21%",
            deltaType: "up",
            label: "Total Leads",
            value: String(kpis.total),
            sub: "All sources this period",
        },
        {
            icon: "✅",
            iconBg: "#d1fae5",
            accentColor: "#059669",
            deltaText: "▲ 18%",
            deltaType: "up",
            label: "Qualified Leads",
            value: String(kpis.qualified),
            sub: "".concat(kpis.qualRate, "% qualification rate"),
        },
        {
            icon: "🗑️",
            iconBg: "#ffe4e6",
            accentColor: "#e11d48",
            deltaText: "—",
            deltaType: "flat",
            label: "Junk Leads",
            value: String(kpis.junk),
            sub: "".concat(kpis.junkRate, "% junk rate"),
        },
        {
            icon: "⏳",
            iconBg: "#fef3c7",
            accentColor: "#d97706",
            deltaText: "—",
            deltaType: "flat",
            label: "In Review",
            value: String(kpis.review),
            sub: "Pending qualification",
        },
    ];
    var QUALITY_STATS = [
        { value: kpis.qualified, label: "Qualified", color: "#059669" },
        { value: kpis.junk, label: "Junk", color: "#e11d48" },
        { value: kpis.review, label: "Review", color: "#d97706" },
    ];
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].leadsDashboard },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].secHeader },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].secTitleWrap },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].secTitle }, "Leads Intelligence"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].secSub },
                        "All lead sources \u00B7 qualified vs junk \u00B7 ",
                        dateRange.label))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].secActions },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(_DatePicker_DatePicker__WEBPACK_IMPORTED_MODULE_2__["default"], { value: dateRange, onChange: setDateRange, maxDate: new Date() }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].secondaryBtn }, "Connect Sources"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].primaryBtn, onClick: fetchLeadData }, "\uD83D\uDD04 Refresh"))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].secHeader },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].secTitleWrap },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].secIcon, style: { background: "#ede9fe" } }, "\uD83C\uDFAF"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].secTitle }, "Leads Intelligence"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].secSub },
                        "All lead sources \u00B7 qualified vs junk \u00B7 ",
                        dateRange.label))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "".concat(_LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].sourceBadge, " ").concat(_LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].badgeGreen) }, "\uD83D\uDCCA SharePoint Data")),
        loading && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].loadingBar },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].loadingFill }))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].g4 }, KPI_CARDS.map(function (kpi, i) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpi, key: i },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiTop },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiIcon, style: { background: kpi.iconBg } }, kpi.icon),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "".concat(_LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiDelta, " ").concat(kpi.deltaType === "up" ? _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].deltaUp : _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].deltaFlat) }, kpi.deltaText)),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiLabel }, kpi.label),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiVal }, kpi.value),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiSub }, kpi.sub),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiAccent, style: { background: kpi.accentColor } }))); })),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "".concat(_LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].g2, " ").concat(_LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].mt) },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].card },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardHead },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardTitle }, "Lead Volume by Source"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardSub },
                            "Where leads are coming from \u00B7 ",
                            dateRange.label))),
                filtered.length > 0 ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(LeadSourceChart, { data: sourceCounts })) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].emptyState }, "\uD83D\uDCED No leads found for selected range"))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].card },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardHead },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardTitle }, "Lead Quality Breakdown"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardSub },
                            "Qualified vs Junk vs In Review \u00B7 ",
                            dateRange.label))),
                filtered.length > 0 ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(LeadQualityChart, { qualified: kpis.qualified, review: kpis.review, junk: kpis.junk }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].statRow }, QUALITY_STATS.map(function (s, i) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].statBox, key: i },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].statVal, style: { color: s.color } }, s.value),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].statLbl }, s.label))); })))) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].emptyState }, "\uD83D\uDCED No leads found for selected range")))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "".concat(_LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].g2, " ").concat(_LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].mt) },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].card },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardHead },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardTitle }, "Lead Source Breakdown"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardSub },
                            "Incoming by channel \u00B7 ",
                            dateRange.label))),
                SOURCE_META_LIST.map(function (meta) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].leadStat, key: meta.key },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].leadIcon, style: { background: meta.iconBg } }, meta.icon),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].leadInfo },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].leadName }, meta.key),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].leadMeta }, meta.meta)),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].leadCount, style: { color: meta.countColor } }, sourceCounts[meta.key] > 0 ? sourceCounts[meta.key] : "—"))); })),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].card },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardHead },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardTitle }, "Lead Detail Table"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardSub },
                            filtered.length,
                            " lead",
                            filtered.length !== 1 ? "s" : "",
                            " \u00B7",
                            " ",
                            dateRange.label))),
                filtered.length === 0 ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].emptyState }, "\uD83D\uDCED No leads found for the selected date range.")) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("table", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].tbl },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("thead", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", null,
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", null, "Lead Name"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", null, "Source"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", null, "Service Interest"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", null, "Status"))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("tbody", null, filtered.slice(0, 10).map(function (row, i) {
                            var _a, _b, _c, _d;
                            return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", { key: i },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null,
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("strong", null, row.leadName)),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null,
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "".concat(_LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].pill, " ").concat((_b = (_a = PILL_MAP[row.source]) === null || _a === void 0 ? void 0 : _a.source) !== null && _b !== void 0 ? _b : "") }, row.source)),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, row.enquiry),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null,
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "".concat(_LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].pill, " ").concat((_d = (_c = PILL_MAP[row.status]) === null || _c === void 0 ? void 0 : _c.status) !== null && _d !== void 0 ? _d : "") }, row.status))));
                        }))),
                    filtered.length > 10 && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].uploadNote },
                        "+",
                        filtered.length - 10,
                        " more leads in this period")))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _LeadsIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].uploadNote }, "\uD83D\uDCE4 Data sourced from SharePoint \u00B7 Fields: Name \u00B7 Source \u00B7 Enquiry \u00B7 Status")))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LeadsIntelligenceDashboard);


/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("57685a1440eca2bd6d65")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=marketing-analytics-web-part.a7f53da69f0d515be42a.hot-update.js.map