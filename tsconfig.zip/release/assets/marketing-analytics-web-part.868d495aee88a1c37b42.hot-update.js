"use strict";
self["webpackHotUpdated4faa06d_862f_4712_a355_4e54547f85f3_0_0_1"]("marketing-analytics-web-part",{

/***/ 5440:
/*!***************************************************************************************!*\
  !*** ./lib/webparts/marketingAnalytics/components/SEOIntelligence/SEOIntelligence.js ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 196);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 5959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SEOIntelligence.module.scss */ 7356);
/* harmony import */ var _DatePicker_DatePicker__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../DatePicker/DatePicker */ 8938);
/* harmony import */ var primereact_chart__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! primereact/chart */ 4964);
/* harmony import */ var _pnp_sp__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @pnp/sp */ 2011);







function defaultRange() {
    var today = new Date();
    today.setHours(0, 0, 0, 0);
    return {
        startDate: new Date(today.getFullYear(), today.getMonth(), 1),
        endDate: today,
        label: "This Month",
    };
}
function filterByDateRange(items, range) {
    return items.filter(function (item) {
        if (!item.Date)
            return true;
        var itemDate = new Date(item.Date);
        if (isNaN(itemDate.getTime())) {
            console.warn("Invalid date:", item.Date);
            return true;
        }
        return itemDate >= range.startDate && itemDate <= range.endDate;
    });
}
function aggregateFromSPData(keywords, backlinks, _topPages) {
    if (!keywords.length && !backlinks.length)
        return null;
    var keywordsTop10 = keywords.filter(function (k) { return k.AvgPosition <= 10; }).length;
    var totalBacklinks = backlinks.reduce(function (sum, b) {
        var val = Number((b.Value || "0").replace(/,/g, ""));
        return sum + val;
    }, 0);
    console.log(totalBacklinks, "totalBacklinks");
    var kwImproved = keywords.filter(function (k) { return k.Status === "Improved"; }).length;
    var seoLeads = keywords.reduce(function (sum, k) { return sum + k.Clicks; }, 0);
    var rankDist = {
        top10: keywords.filter(function (k) { return k.AvgPosition <= 10; }).length,
        rank11_50: keywords.filter(function (k) { return k.AvgPosition > 10 && k.AvgPosition <= 50; })
            .length,
        rank51_100: keywords.filter(function (k) { return k.AvgPosition > 50 && k.AvgPosition <= 100; }).length,
        notRanked: keywords.filter(function (k) { return k.AvgPosition > 100; }).length,
    };
    var keywordRows = keywords
        .filter(function (k) { return k.AvgPosition <= 10; })
        .map(function (k) { return ({
        keyword: k.Keyword,
        prevRank: "—",
        currRank: "#".concat(Math.round(k.AvgPosition)),
        change: 0,
        volume: k.Impressions.toLocaleString(),
        status: "Top 10",
    }); });
    var backlinkMetrics = backlinks.map(function (b) { return ({
        label: b.Metric,
        value: b.Value.toLocaleString(),
        isDelta: false,
        deltaUp: false,
    }); });
    var rankDistMonths = [(0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)({ label: "Current" }, rankDist)];
    var backlinkTrend = [
        { label: "Current", backlinks: Number(totalBacklinks), domains: 0 },
    ];
    return {
        keywordsTop10: keywordsTop10,
        totalBacklinks: totalBacklinks,
        kwImproved: kwImproved,
        seoLeads: seoLeads,
        rankDist: rankDist,
        rankDistMonths: rankDistMonths,
        backlinkTrend: backlinkTrend,
        backlinkMetrics: backlinkMetrics,
        kwSummary: {
            improved: kwImproved,
            declined: keywords.filter(function (k) { return k.Status === "Declined"; }).length,
            unchanged: keywords.filter(function (k) { return k.Status === "Unchanged"; }).length,
        },
        keywordRows: keywordRows,
    };
}
var KpiCard = function (p) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpi },
    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiTop },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiIcon, style: { background: p.iconBg } }, p.icon),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "".concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiDelta, " ").concat(p.deltaType === "up"
                ? _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].deltaUp
                : p.deltaType === "dn"
                    ? _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].deltaDn
                    : _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].deltaFlat) }, p.deltaText)),
    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiLabel }, p.label),
    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiVal }, p.value),
    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiSub }, p.sub),
    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiAccent, style: { background: p.accentColor } }))); };
var RankDistChart = function (_a) {
    var data = _a.data;
    var chartData = {
        labels: data.map(function (d) { return d.label; }),
        datasets: [
            {
                label: "Top 1-10",
                data: data.map(function (d) { return d.top10; }),
                backgroundColor: "#059669",
            },
            {
                label: "11-50",
                data: data.map(function (d) { return d.rank11_50; }),
                backgroundColor: "#0891b2",
            },
            {
                label: "51-100",
                data: data.map(function (d) { return d.rank51_100; }),
                backgroundColor: "#d97706",
            },
            {
                label: "Not Ranked",
                data: data.map(function (d) { return d.notRanked; }),
                backgroundColor: "#e11d48",
            },
        ],
    };
    var options = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { position: "bottom" } },
        scales: { x: { stacked: true }, y: { stacked: true } },
    };
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].chartWrapper }, data.length === 0 ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].emptyChart }, "\uD83D\uDCED No data")) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_chart__WEBPACK_IMPORTED_MODULE_5__.Chart, { type: "bar", data: chartData, options: options }))));
};
var BacklinkGrowthChart = function (_a) {
    var data = _a.data;
    var chartData = {
        labels: data.map(function (d) { return d.label; }),
        datasets: [
            {
                label: "Total Backlinks",
                data: data.map(function (d) { return d.backlinks; }),
                borderColor: "#1a6ef5",
                backgroundColor: "rgba(26,110,245,0.1)",
                tension: 0.4,
                fill: true,
            },
            {
                label: "Referring Domains",
                data: data.map(function (d) { return d.domains; }),
                borderColor: "#7c3aed",
                backgroundColor: "rgba(124,58,237,0.1)",
                tension: 0.4,
                fill: true,
            },
        ],
    };
    var options = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { position: "bottom" } },
    };
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].chartWrapper }, data.length === 0 ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].emptyChart }, "\uD83D\uDCED No data")) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_chart__WEBPACK_IMPORTED_MODULE_5__.Chart, { type: "line", data: chartData, options: options }))));
};
// ─── Main Dashboard ───────────────────────────────────────────────────────────
var SeoIntelligenceDashboard = function () {
    var _a = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(defaultRange()), dateRange = _a[0], setDateRange = _a[1];
    var _b = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null), aggregated = _b[0], setAggregated = _b[1];
    var _c = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false), loading = _c[0], setLoading = _c[1];
    var _d = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(""), rangeLabel = _d[0], setRangeLabel = _d[1];
    var _e = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null), error = _e[0], setError = _e[1];
    var _f = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]), keywordData = _f[0], setKeywordData = _f[1];
    var _g = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]), topPageData = _g[0], setTopPageData = _g[1];
    var _h = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]), backlinkData = _h[0], setBacklinkData = _h[1];
    var fetchKeywordData = function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(void 0, void 0, void 0, function () {
        var res, formatted, err_1;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, _pnp_sp__WEBPACK_IMPORTED_MODULE_3__.sp.web.lists
                            .getByTitle("SEOIntelligence-KeywordRankings")
                            .items.select("ID", "Keyword", "Clicks", "Impressions", "CTR", "AvgPosition", "Status", "Date")
                            .orderBy("Date", false)
                            .getAll()];
                case 1:
                    res = _a.sent();
                    formatted = res.map(function (item) { return ({
                        ID: item.ID,
                        Keyword: item.Keyword,
                        Clicks: Number(item.Clicks || 0),
                        Impressions: Number(item.Impressions || 0),
                        CTR: Number(item.CTR || 0),
                        AvgPosition: Number(item.AvgPosition || 0),
                        Status: item.Status,
                        Date: item.Date || null,
                    }); });
                    setKeywordData(formatted);
                    console.log(formatted, "keywordData");
                    return [3 /*break*/, 3];
                case 2:
                    err_1 = _a.sent();
                    console.error("Keyword fetch error:", err_1);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var fetchTopPageData = function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(void 0, void 0, void 0, function () {
        var res, formatted, err_2;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, _pnp_sp__WEBPACK_IMPORTED_MODULE_3__.sp.web.lists
                            .getByTitle("SEOIntelligence-TopPagesDetails(GSC)")
                            .items.select("ID", "PageURL", "Clicks", "Impressions", "CTR", "AvgPosition", "Date")
                            .orderBy("Date", false)
                            .getAll()];
                case 1:
                    res = _a.sent();
                    formatted = res.map(function (item) { return ({
                        ID: item.ID,
                        PageURL: item.PageURL,
                        Clicks: Number(item.Clicks || 0),
                        Impressions: Number(item.Impressions || 0),
                        CTR: Number(item.CTR || 0),
                        AvgPosition: Number(item.AvgPosition || 0),
                        Date: item.Date || null,
                    }); });
                    setTopPageData(formatted);
                    console.log(formatted, "topPageData");
                    return [3 /*break*/, 3];
                case 2:
                    err_2 = _a.sent();
                    console.error("TopPage fetch error:", err_2);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var fetchBacklinkData = function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(void 0, void 0, void 0, function () {
        var res, formatted, err_3;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, _pnp_sp__WEBPACK_IMPORTED_MODULE_3__.sp.web.lists
                            .getByTitle("SEOIntelligence-BacklinkSummary")
                            .items.select("ID", "Metric", "Value", "Notes", "Date")
                            .orderBy("Date", false)
                            .getAll()];
                case 1:
                    res = _a.sent();
                    formatted = res.map(function (item) { return ({
                        ID: item.ID,
                        Metric: item.Metric,
                        Value: item.Value || 0,
                        Notes: item.Notes,
                        Date: item.Date || null,
                    }); });
                    setBacklinkData(formatted);
                    console.log(formatted, "backlinkData");
                    return [3 /*break*/, 3];
                case 2:
                    err_3 = _a.sent();
                    console.error("Backlink fetch error:", err_3);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function () {
        setLoading(true);
        (fetchKeywordData(), fetchTopPageData(), fetchBacklinkData());
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function () {
        setLoading(true);
        var timer = setTimeout(function () {
            var filteredKeywords = filterByDateRange(keywordData, dateRange);
            var filteredBacklinks = filterByDateRange(backlinkData, dateRange);
            var filteredTopPages = filterByDateRange(topPageData, dateRange);
            var agg = aggregateFromSPData(filteredKeywords, filteredBacklinks, filteredTopPages);
            setAggregated(agg);
            setRangeLabel(dateRange.label);
            setLoading(false);
        }, 250);
        return function () { return clearTimeout(timer); };
    }, [dateRange, keywordData, backlinkData, topPageData]);
    var noData = !aggregated;
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].seoDashboard },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].topHeader },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].topTitle }, "SEO Intelligence"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].topSub }, "GSC + Excel \u00B7 Keyword & backlink data")),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].topRight },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].secActions },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(_DatePicker_DatePicker__WEBPACK_IMPORTED_MODULE_2__["default"], { value: dateRange, onChange: setDateRange, maxDate: new Date() }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "".concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].sourceBadge, " ").concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].badgeBlue) }, "\uD83D\uDD17 GSC Connected"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].topBtnPrimary }, "Refresh")))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].secHeader },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].secTitleWrap },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].secIcon, style: { background: "#fef3c7" } }, "\uD83D\uDD0D"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].secTitle }, "SEO Performance"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].secSub },
                        "Google Search Console \u00B7 ",
                        rangeLabel))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "".concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].sourceBadge, " ").concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].badgeGreen) }, "\uD83D\uDCCA Excel")),
        error && react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
            "\u26A0\uFE0F ",
            error),
        loading && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].loadingBar },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].loadingFill }))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].g4 },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(KpiCard, { icon: "\uD83D\uDCC8", iconBg: "#d1fae5", accentColor: "#059669", deltaText: noData ? "—" : "\u25B2 ".concat(aggregated.keywordsTop10, " keywords"), deltaType: noData ? "flat" : "up", label: "Keywords Top-10", value: noData ? "—" : String(aggregated.keywordsTop10), sub: "Ranking page 1" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(KpiCard, { icon: "\uD83D\uDD17", iconBg: "#e8f0fe", accentColor: "#1a6ef5", deltaText: noData
                    ? "—"
                    : "\u25B2 Latest ".concat(aggregated.totalBacklinks.toLocaleString()), deltaType: noData ? "flat" : "up", label: "Total Backlinks", value: noData ? "—" : aggregated.totalBacklinks.toLocaleString(), sub: "Acquired in range" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(KpiCard, { icon: "\u2B06\uFE0F\r\n          ", iconBg: "#fef3c7", accentColor: "#d97706", deltaText: noData ? "—" : "\u25B2 ".concat(aggregated.kwImproved, " improved"), deltaType: noData ? "flat" : "up", label: "Kw Rank Improved", value: noData ? "—" : String(aggregated.kwImproved), sub: "vs previous period" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(KpiCard, { icon: "\uD83C\uDFAF", iconBg: "#e0f5fa", accentColor: "#0891b2", deltaText: noData ? "—" : "\u25B2 ".concat(aggregated.seoLeads, " leads"), deltaType: noData ? "flat" : "up", label: "SEO Leads", value: noData ? "—" : aggregated.seoLeads.toLocaleString(), sub: "Organic conversions" })),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "".concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].g2, " ").concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].mt) },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].card },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardHead },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardTitle }, "Keyword Rank Distribution"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardSub },
                            "How keywords are spread across positions \u00B7 ",
                            dateRange.label))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(RankDistChart, { data: noData ? [] : aggregated.rankDistMonths })),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].card },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardHead },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardTitle }, "Backlink Growth"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardSub },
                            "Total backlinks vs referring domains \u00B7 ",
                            dateRange.label))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(BacklinkGrowthChart, { data: noData ? [] : aggregated.backlinkTrend }))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "".concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].g2, " ").concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].mt) },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].card },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardHead },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardTitle }, "Keyword Rankings Detail"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardSub },
                            "Top commercial-intent keywords \u00B7 ",
                            dateRange.label))),
                noData ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].emptyState }, "\uD83D\uDCED No data found for selected date range.")) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement("table", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].tbl },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("thead", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", null, "Keyword"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", null, "Prev Rank"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", null, "Curr Rank"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", null, "Change"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", null, "Volume"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", null, "Status"))),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("tbody", null, aggregated.keywordRows.map(function (row, idx) {
                        var isUp = row.change > 0;
                        var statusClass = row.status === "Improved"
                            ? _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].pillGreen
                            : row.status === "Declined"
                                ? _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].pillRose
                                : _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].pillGray;
                        return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", { key: idx },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null,
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("strong", null, row.keyword)),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, row.prevRank),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null,
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("strong", null, row.currRank)),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null,
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "".concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].delta, " ").concat(isUp
                                        ? _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].deltaUp
                                        : row.change < 0
                                            ? _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].deltaDn
                                            : _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].deltaFlat) }, isUp
                                    ? "\u25B2+".concat(row.change)
                                    : row.change < 0
                                        ? "\u25BC".concat(row.change)
                                        : "—")),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, row.volume),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null,
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "".concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].pill, " ").concat(statusClass) }, row.status))));
                    }))))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].card },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardHead },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardTitle }, "Backlinks \u2014 Selected Period"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardSub },
                            "Quality & growth metrics \u00B7 ",
                            dateRange.label))),
                noData ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].emptyState }, "\uD83D\uDCED No data found for selected date range.")) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
                    aggregated.backlinkMetrics.map(function (m, i) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].miniM, key: i },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].miniLabel }, m.label),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "".concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].miniVal, " ").concat(m.isDelta
                                ? m.deltaUp
                                    ? _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].deltaUp
                                    : _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].deltaDn
                                : "") }, m.value))); }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].divider }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardHead, style: { marginBottom: 8 } },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardTitle }, "Keywords Improved vs Declined")),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kwSummaryRow },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "".concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kwSummaryBox, " ").concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kwSummaryGreen) },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kwSummaryNum, style: { color: "#059669" } }, aggregated.kwSummary.improved),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kwSummaryLbl, style: { color: "#059669" } }, "Keywords \u25B2 Improved")),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "".concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kwSummaryBox, " ").concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kwSummaryRose) },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kwSummaryNum, style: { color: "#e11d48" } }, aggregated.kwSummary.declined),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kwSummaryLbl, style: { color: "#e11d48" } }, "Keywords \u25BC Declined")),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "".concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kwSummaryBox, " ").concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kwSummaryGray) },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kwSummaryNum, style: { color: "#4a5a7a" } }, aggregated.kwSummary.unchanged),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kwSummaryLbl, style: { color: "#8a9bbf" } }, "Unchanged")))))))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SeoIntelligenceDashboard);


/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("8b2f8175628805534b17")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=marketing-analytics-web-part.868d495aee88a1c37b42.hot-update.js.map