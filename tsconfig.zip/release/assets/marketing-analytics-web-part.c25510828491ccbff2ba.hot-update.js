"use strict";
self["webpackHotUpdated4faa06d_862f_4712_a355_4e54547f85f3_0_0_1"]("marketing-analytics-web-part",{

/***/ 3504:
/*!************************************************************************************!*\
  !*** ./lib/webparts/marketingAnalytics/components/PaidAds/PaidAds.module.scss.css ***!
  \************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_microsoft_sp_css_loader_node_modules_microsoft_load_themed_styles_lib_es6_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../../node_modules/@microsoft/sp-css-loader/node_modules/@microsoft/load-themed-styles/lib-es6/index.js */ 6323);
// Imports


_node_modules_microsoft_sp_css_loader_node_modules_microsoft_load_themed_styles_lib_es6_index_js__WEBPACK_IMPORTED_MODULE_0__.loadStyles(".paidAds_2d3b476c{background:#f8fafc;font-family:Inter,Segoe UI,system-ui,sans-serif;min-height:100vh;opacity:0;transition:opacity .3s ease}.paidAds_2d3b476c *,.paidAds_2d3b476c :after,.paidAds_2d3b476c :before{box-sizing:border-box}.paidAds--mounted_2d3b476c{opacity:1}.topBar_2d3b476c{align-items:center;background:#fff;border-bottom:1px solid #e2e8f0;display:flex;flex-wrap:wrap;gap:12px;height:48px;justify-content:space-between;padding:0 20px}.topBar__left_2d3b476c{align-items:center;display:flex;gap:8px;justify-content:flex-start}.topBar__title_2d3b476c{color:#0f172a;font-size:14px;font-weight:700}.topBar__sep_2d3b476c{color:#e2e8f0;font-size:12px}.topBar__subs_2d3b476c{color:#94a3b8;font-size:12px}.topBar__right_2d3b476c{gap:8px}.datePill_2d3b476c,.topBar__right_2d3b476c{align-items:center;display:flex;justify-content:flex-start}.datePill_2d3b476c{background:#fff;border:1px solid #e2e8f0;border-radius:8px;color:#374151;cursor:pointer;font-size:12px;gap:6px;padding:5px 10px;white-space:nowrap}.datePill__label_2d3b476c{color:#0f172a;font-size:12px;font-weight:600}.datePill__range_2d3b476c{color:#94a3b8;font-size:11px}.datePill__chevron_2d3b476c{color:#94a3b8;font-size:10px}.btnConnect_2d3b476c{align-items:center;background:#fff;border:1px solid #e2e8f0;border-radius:8px;color:#374151;cursor:pointer;display:flex;font-family:Inter,Segoe UI,system-ui,sans-serif;font-size:12px;font-weight:500;gap:5px;justify-content:flex-start;padding:5px 12px}.btnConnect_2d3b476c:hover{background:#f8fafc}.btnRefresh_2d3b476c{align-items:center;background:#1a6ef5;border:none;border-radius:8px;color:#fff;cursor:pointer;display:flex;font-family:Inter,Segoe UI,system-ui,sans-serif;font-size:12px;font-weight:600;gap:5px;justify-content:flex-start;padding:6px 14px}.btnRefresh_2d3b476c:hover{background:#0a5bdd}.innerHeader_2d3b476c{align-items:center;background:#fff;border-bottom:1px solid #f1f5f9;display:flex;justify-content:space-between;padding:12px 20px}.innerHeader__left_2d3b476c{align-items:center;display:flex;gap:10px;justify-content:flex-start}.innerHeader__icon_2d3b476c{align-items:center;background:#fff0f3;border-radius:10px;box-shadow:0 2px 8px rgba(225,29,72,.12);display:flex;flex-shrink:0;font-size:18px;height:36px;justify-content:center;width:36px}.innerHeader__title_2d3b476c{color:#0f172a;font-size:15px;font-weight:700}.innerHeader__sub_2d3b476c{color:#94a3b8;font-size:12px;margin-top:1px}.btnExcel_2d3b476c{align-items:center;background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;color:#059669;cursor:pointer;display:flex;font-family:Inter,Segoe UI,system-ui,sans-serif;font-size:12px;font-weight:600;gap:6px;justify-content:flex-start;padding:5px 12px}.btnExcel_2d3b476c:hover{background:#dcfce7}.kpiStrip_2d3b476c{display:grid;gap:14px;grid-template-columns:repeat(4,1fr);margin-bottom:16px}@media (max-width:1100px){.kpiStrip_2d3b476c{grid-template-columns:repeat(2,1fr)}}@media (max-width:600px){.kpiStrip_2d3b476c{grid-template-columns:1fr}}.kpiCard_2d3b476c{border:1px solid #e2e8f0;box-shadow:0 2px 10px rgba(0,0,0,.05);overflow:hidden;padding:16px 18px 14px;position:relative}.kpiCard__top_2d3b476c{align-items:center;display:flex;justify-content:space-between;margin-bottom:10px}.kpiCard__icon_2d3b476c{align-items:center;border-radius:10px;display:flex;flex-shrink:0;font-size:17px;height:36px;justify-content:center;width:36px}.kpiCard__menu_2d3b476c{color:#94a3b8;cursor:pointer;font-size:16px;line-height:1;-webkit-user-select:none;-ms-user-select:none;user-select:none}.kpiCard__delta_2d3b476c{border-radius:20px;font-size:11px;font-weight:700;padding:3px 8px}.kpiCard__delta--up_2d3b476c{background:#f0fdf4;color:#059669}.kpiCard__delta--flat_2d3b476c{background:#f8fafc;color:#64748b}.kpiCard__label_2d3b476c{color:#94a3b8;font-size:11px;font-weight:500;letter-spacing:.4px;margin-bottom:4px;text-transform:uppercase}.kpiCard__value_2d3b476c{color:#0f172a;font-size:28px;font-weight:800;line-height:1;margin-bottom:4px}.kpiCard__sub_2d3b476c{color:#94a3b8;font-size:11px}.kpiCard__bar_2d3b476c{border-radius:0 0 14px 14px;bottom:0;height:3px;left:0;position:absolute;right:0}.chartsRow_2d3b476c{display:grid;gap:14px;grid-template-columns:1fr 1fr;margin-bottom:16px}@media (max-width:900px){.chartsRow_2d3b476c{grid-template-columns:1fr}}.chartCard_2d3b476c{border:1px solid #e2e8f0;border-radius:14px;box-shadow:0 2px 10px rgba(0,0,0,.05);min-width:0}.chartCard__title_2d3b476c{color:#0f172a;font-size:13px;font-weight:700}.chartCard__sub_2d3b476c{color:#94a3b8;font-size:11px;margin-bottom:14px;margin-top:2px}.chartCard__canvas_2d3b476c{height:220px;position:relative;width:100%}.chartCard__canvas_2d3b476c .p-chart{height:220px;width:100%}.chartCard__canvas_2d3b476c .p-chart canvas{max-height:220px;width:100%!important}.chartCard__empty_2d3b476c{align-items:center;color:#94a3b8;display:flex;font-size:13px;height:220px;justify-content:center}.campaignTable_2d3b476c{background:#fff;border:1px solid #e2e8f0;border-radius:14px;box-shadow:0 2px 10px rgba(0,0,0,.05);margin-bottom:16px;padding:18px}.campaignTable__header_2d3b476c{align-items:center;display:flex;justify-content:space-between;margin-bottom:14px}.campaignTable__title_2d3b476c{color:#0f172a;font-size:13px;font-weight:700}.campaignTable__sub_2d3b476c{color:#94a3b8;font-size:11px;margin-top:2px}.campaignTable__scroll_2d3b476c{overflow-x:auto}.campaignTable__empty_2d3b476c{color:#94a3b8;font-size:14px;padding:40px 0;text-align:center}.tbl_2d3b476c{border-collapse:collapse;font-size:12px;width:100%}.tbl_2d3b476c thead tr{background:#f8fafc}.tbl_2d3b476c th{border-bottom:2px solid #e2e8f0;color:#64748b;font-size:10px;font-weight:700;letter-spacing:.5px;padding:9px 12px;text-align:left;text-transform:uppercase;white-space:nowrap}.tbl_2d3b476c td{padding:11px 12px}.tbl_2d3b476c tbody tr{border-bottom:1px solid #f1f5f9;transition:background .15s}.tbl_2d3b476c tbody tr:last-child{border-bottom:none}.tbl_2d3b476c tbody tr:hover{background:#f8fafc}.cell--name_2d3b476c{color:#0f172a;font-size:13px;font-weight:600}.cell--num_2d3b476c{color:#374151}.cell--leads_2d3b476c{color:#374151;font-size:14px;font-weight:700}.cell--muted_2d3b476c{color:#94a3b8}.uploadFooter_2d3b476c{align-items:center;border-top:1px dashed #e2e8f0;color:#94a3b8;display:flex;font-size:11px;gap:6px;justify-content:flex-start;margin-top:4px;padding-top:10px}.pill_2d3b476c{border-radius:20px;display:inline-block;font-size:11px;font-weight:700;padding:3px 10px;white-space:nowrap}.pill--blue_2d3b476c{background:#eff6ff;color:#1a6ef5}.pill--indigo_2d3b476c{background:#eef2ff;color:#4f46e5}.pill--violet_2d3b476c{background:#f5f3ff;color:#7c3aed}.pill--green_2d3b476c{background:#f0fdf4;color:#059669}.pill--teal_2d3b476c{background:#f0fdfa;color:#0891b2}.pill--amber_2d3b476c{background:#fffbeb;color:#d97706}.pill--gray_2d3b476c{background:#f8fafc;color:#64748b}.dashboard_2d3b476c{background:#f5f7fb;padding:20px}.kpiGrid_2d3b476c{display:grid;gap:16px;grid-template-columns:repeat(4,1fr);margin-bottom:20px}.kpiCard_2d3b476c{background:#fff;border:1px solid #e6eaf2;border-radius:14px;box-shadow:0 4px 14px rgba(0,0,0,.04);gap:12px;padding:16px;transition:.2s}.kpiCard_2d3b476c:hover{transform:translateY(-2px)}.iconWrap_2d3b476c{align-items:center;border-radius:10px;display:flex;font-size:18px;height:42px;justify-content:center;width:42px}.kpiContent_2d3b476c{flex:1}.kpiLabel_2d3b476c{color:#6b7280;font-size:12px}.kpiValue_2d3b476c{color:#111827;font-size:20px;font-weight:600;margin:4px 0}.kpiSub_2d3b476c{color:#9ca3af;font-size:11px}.kpiDelta_2d3b476c{font-size:11px;margin-top:4px}.up_2d3b476c{color:#16a34a}.down_2d3b476c{color:#dc2626}.chartCard_2d3b476c{background:#fff;border:1px solid #e6eaf2;border-radius:16px;box-shadow:0 6px 20px rgba(0,0,0,.05);padding:18px}.chartHeader_2d3b476c{color:#374151;font-size:14px;font-weight:600;margin-bottom:10px}", true);

// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  paidAds: "paidAds_2d3b476c",
  "paidAds--mounted": "paidAds--mounted_2d3b476c",
  topBar: "topBar_2d3b476c",
  topBar__left: "topBar__left_2d3b476c",
  topBar__title: "topBar__title_2d3b476c",
  topBar__sep: "topBar__sep_2d3b476c",
  topBar__subs: "topBar__subs_2d3b476c",
  topBar__right: "topBar__right_2d3b476c",
  datePill: "datePill_2d3b476c",
  datePill__label: "datePill__label_2d3b476c",
  datePill__range: "datePill__range_2d3b476c",
  datePill__chevron: "datePill__chevron_2d3b476c",
  btnConnect: "btnConnect_2d3b476c",
  btnRefresh: "btnRefresh_2d3b476c",
  innerHeader: "innerHeader_2d3b476c",
  innerHeader__left: "innerHeader__left_2d3b476c",
  innerHeader__icon: "innerHeader__icon_2d3b476c",
  innerHeader__title: "innerHeader__title_2d3b476c",
  innerHeader__sub: "innerHeader__sub_2d3b476c",
  btnExcel: "btnExcel_2d3b476c",
  kpiStrip: "kpiStrip_2d3b476c",
  kpiCard: "kpiCard_2d3b476c",
  kpiCard__top: "kpiCard__top_2d3b476c",
  kpiCard__icon: "kpiCard__icon_2d3b476c",
  kpiCard__menu: "kpiCard__menu_2d3b476c",
  kpiCard__delta: "kpiCard__delta_2d3b476c",
  "kpiCard__delta--up": "kpiCard__delta--up_2d3b476c",
  "kpiCard__delta--flat": "kpiCard__delta--flat_2d3b476c",
  kpiCard__label: "kpiCard__label_2d3b476c",
  kpiCard__value: "kpiCard__value_2d3b476c",
  kpiCard__sub: "kpiCard__sub_2d3b476c",
  kpiCard__bar: "kpiCard__bar_2d3b476c",
  chartsRow: "chartsRow_2d3b476c",
  chartCard: "chartCard_2d3b476c",
  chartCard__title: "chartCard__title_2d3b476c",
  chartCard__sub: "chartCard__sub_2d3b476c",
  chartCard__canvas: "chartCard__canvas_2d3b476c",
  chartCard__empty: "chartCard__empty_2d3b476c",
  campaignTable: "campaignTable_2d3b476c",
  campaignTable__header: "campaignTable__header_2d3b476c",
  campaignTable__title: "campaignTable__title_2d3b476c",
  campaignTable__sub: "campaignTable__sub_2d3b476c",
  campaignTable__scroll: "campaignTable__scroll_2d3b476c",
  campaignTable__empty: "campaignTable__empty_2d3b476c",
  tbl: "tbl_2d3b476c",
  "cell--name": "cell--name_2d3b476c",
  "cell--num": "cell--num_2d3b476c",
  "cell--leads": "cell--leads_2d3b476c",
  "cell--muted": "cell--muted_2d3b476c",
  uploadFooter: "uploadFooter_2d3b476c",
  pill: "pill_2d3b476c",
  "pill--blue": "pill--blue_2d3b476c",
  "pill--indigo": "pill--indigo_2d3b476c",
  "pill--violet": "pill--violet_2d3b476c",
  "pill--green": "pill--green_2d3b476c",
  "pill--teal": "pill--teal_2d3b476c",
  "pill--amber": "pill--amber_2d3b476c",
  "pill--gray": "pill--gray_2d3b476c",
  dashboard: "dashboard_2d3b476c",
  kpiGrid: "kpiGrid_2d3b476c",
  iconWrap: "iconWrap_2d3b476c",
  kpiContent: "kpiContent_2d3b476c",
  kpiLabel: "kpiLabel_2d3b476c",
  kpiValue: "kpiValue_2d3b476c",
  kpiSub: "kpiSub_2d3b476c",
  kpiDelta: "kpiDelta_2d3b476c",
  up: "up_2d3b476c",
  down: "down_2d3b476c",
  chartHeader: "chartHeader_2d3b476c"
});


/***/ }),

/***/ 5204:
/*!***********************************************************************!*\
  !*** ./lib/webparts/marketingAnalytics/components/PaidAds/PaidAds.js ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PaidAdsPerformance: () => (/* binding */ PaidAdsPerformance),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 196);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 5959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var primereact_chart__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! primereact/chart */ 4964);
/* harmony import */ var _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./PaidAds.module.scss */ 3504);
/* harmony import */ var _pnp_sp__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @pnp/sp */ 2011);
/* harmony import */ var _DatePicker_DatePicker__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../DatePicker/DatePicker */ 8938);







// ─── Data ─────────────────────────────────────────────────────────────────────
var ALL_CAMPAIGNS = [
    // October
    {
        platform: "Google",
        campaignName: "SharePoint Migration — Search",
        date: new Date(2025, 9, 5),
        spend: 9000,
        impressions: 24000,
        clicks: 840,
        ctr: "3.5%",
        ctrType: "good",
        leads: 42,
        cpl: 214,
        status: "Active",
    },
    {
        platform: "LinkedIn",
        campaignName: "B2B Lead Gen — Power Platform",
        date: new Date(2025, 9, 8),
        spend: 7000,
        impressions: 16000,
        clicks: 350,
        ctr: "2.2%",
        ctrType: "mid",
        leads: 17,
        cpl: 412,
        status: "Active",
    },
    {
        platform: "Facebook",
        campaignName: "Brand Awareness — Enterprise",
        date: new Date(2025, 9, 10),
        spend: 3500,
        impressions: 170000,
        clicks: 610,
        ctr: "0.36%",
        ctrType: "low",
        leads: null,
        cpl: null,
        status: "Paused",
    },
    // November
    {
        platform: "Google",
        campaignName: "SharePoint Migration — Search",
        date: new Date(2025, 10, 4),
        spend: 9500,
        impressions: 25000,
        clicks: 875,
        ctr: "3.5%",
        ctrType: "good",
        leads: 44,
        cpl: 216,
        status: "Active",
    },
    {
        platform: "LinkedIn",
        campaignName: "B2B Lead Gen — Power Platform",
        date: new Date(2025, 10, 7),
        spend: 7500,
        impressions: 17000,
        clicks: 374,
        ctr: "2.2%",
        ctrType: "mid",
        leads: 18,
        cpl: 417,
        status: "Active",
    },
    {
        platform: "Facebook",
        campaignName: "Brand Awareness — Enterprise",
        date: new Date(2025, 10, 9),
        spend: 3500,
        impressions: 172000,
        clicks: 620,
        ctr: "0.36%",
        ctrType: "low",
        leads: null,
        cpl: null,
        status: "Paused",
    },
    // December
    {
        platform: "Google",
        campaignName: "SharePoint Migration — Search",
        date: new Date(2025, 11, 3),
        spend: 9800,
        impressions: 26000,
        clicks: 910,
        ctr: "3.5%",
        ctrType: "good",
        leads: 46,
        cpl: 213,
        status: "Active",
    },
    {
        platform: "LinkedIn",
        campaignName: "B2B Lead Gen — Power Platform",
        date: new Date(2025, 11, 6),
        spend: 7800,
        impressions: 17500,
        clicks: 385,
        ctr: "2.2%",
        ctrType: "mid",
        leads: 19,
        cpl: 411,
        status: "Active",
    },
    {
        platform: "Facebook",
        campaignName: "Brand Awareness — Enterprise",
        date: new Date(2025, 11, 8),
        spend: 3500,
        impressions: 173000,
        clicks: 622,
        ctr: "0.36%",
        ctrType: "low",
        leads: null,
        cpl: null,
        status: "Paused",
    },
    // January
    {
        platform: "Google",
        campaignName: "SharePoint Migration — Search",
        date: new Date(2026, 0, 6),
        spend: 8200,
        impressions: 22000,
        clicks: 770,
        ctr: "3.5%",
        ctrType: "good",
        leads: 38,
        cpl: 216,
        status: "Active",
    },
    {
        platform: "LinkedIn",
        campaignName: "B2B Lead Gen — Power Platform",
        date: new Date(2026, 0, 9),
        spend: 7200,
        impressions: 16500,
        clicks: 363,
        ctr: "2.2%",
        ctrType: "mid",
        leads: 18,
        cpl: 400,
        status: "Active",
    },
    {
        platform: "Facebook",
        campaignName: "Brand Awareness — Enterprise",
        date: new Date(2026, 0, 11),
        spend: 3600,
        impressions: 175000,
        clicks: 630,
        ctr: "0.36%",
        ctrType: "low",
        leads: null,
        cpl: null,
        status: "Paused",
    },
    // February
    {
        platform: "Google",
        campaignName: "SharePoint Migration — Search",
        date: new Date(2026, 1, 3),
        spend: 9200,
        impressions: 24000,
        clicks: 840,
        ctr: "3.5%",
        ctrType: "good",
        leads: 43,
        cpl: 214,
        status: "Active",
    },
    {
        platform: "LinkedIn",
        campaignName: "B2B Lead Gen — Power Platform",
        date: new Date(2026, 1, 6),
        spend: 7900,
        impressions: 17800,
        clicks: 392,
        ctr: "2.2%",
        ctrType: "mid",
        leads: 20,
        cpl: 395,
        status: "Active",
    },
    {
        platform: "Facebook",
        campaignName: "Brand Awareness — Enterprise",
        date: new Date(2026, 1, 8),
        spend: 3700,
        impressions: 178000,
        clicks: 641,
        ctr: "0.36%",
        ctrType: "low",
        leads: null,
        cpl: null,
        status: "Paused",
    },
    // March
    {
        platform: "Google",
        campaignName: "SharePoint Migration — Search",
        date: new Date(2026, 2, 3),
        spend: 8100,
        impressions: 21500,
        clicks: 752,
        ctr: "3.5%",
        ctrType: "good",
        leads: 37,
        cpl: 219,
        status: "Active",
    },
    {
        platform: "LinkedIn",
        campaignName: "B2B Lead Gen — Power Platform",
        date: new Date(2026, 2, 5),
        spend: 7600,
        impressions: 16800,
        clicks: 370,
        ctr: "2.2%",
        ctrType: "mid",
        leads: 19,
        cpl: 400,
        status: "Active",
    },
    {
        platform: "Facebook",
        campaignName: "Brand Awareness — Enterprise",
        date: new Date(2026, 2, 7),
        spend: 3700,
        impressions: 179000,
        clicks: 644,
        ctr: "0.36%",
        ctrType: "low",
        leads: null,
        cpl: null,
        status: "Paused",
    },
];
var PLATFORM_META = {
    Google: { color: "#e11d48", icon: "🔍", pillColor: "blue" },
    LinkedIn: { color: "#1a6ef5", icon: "💼", pillColor: "indigo" },
    Facebook: { color: "#7c3aed", icon: "📘", pillColor: "violet" },
};
var PLATFORMS = ["Google", "LinkedIn", "Facebook"];
// ─── Helpers ──────────────────────────────────────────────────────────────────
function fmt(n) {
    if (n >= 1000000)
        return (n / 1000000).toFixed(1).replace(/\.0$/, "") + "M";
    if (n >= 1000)
        return (n / 1000).toFixed(1).replace(/\.0$/, "") + "K";
    return n.toLocaleString("en-IN");
}
function defaultRange() {
    var today = new Date();
    today.setHours(0, 0, 0, 0);
    return {
        startDate: new Date(today.getFullYear(), today.getMonth(), 1),
        endDate: today,
        label: "This Month",
    };
}
function formatDateLabel(d) {
    return d.toLocaleDateString("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric",
    });
}
// ─── Pill ─────────────────────────────────────────────────────────────────────
var Pill = function (_a) {
    var children = _a.children, color = _a.color;
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "".concat(_PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].pill, " ").concat(_PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]["pill--".concat(color)]) }, children));
};
var KpiCard = function (_a) {
    var icon = _a.icon, label = _a.label, value = _a.value, sub = _a.sub, delta = _a.delta, deltaUp = _a.deltaUp, accentColor = _a.accentColor, iconBg = _a.iconBg;
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiCard },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiCard__top },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiCard__icon, style: { background: iconBg } }, icon),
            delta === null ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiCard__menu }, "\u2014")) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "".concat(_PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiCard__delta, " ").concat(deltaUp ? _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]["kpiCard__delta--up"] : _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]["kpiCard__delta--flat"]) }, delta))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiCard__label }, label),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiCard__value }, value),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiCard__sub }, sub),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiCard__bar, style: { background: accentColor } })));
};
// ─── Main Component ───────────────────────────────────────────────────────────
var PaidAdsPerformance = function () {
    var _a = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(defaultRange), dateRange = _a[0], setDateRange = _a[1];
    var _b = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false), mounted = _b[0], setMounted = _b[1];
    var _c = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]), googleAdsData = _c[0], setGoogleAdsData = _c[1];
    var _d = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]), facebookAdsData = _d[0], setFacebookAdsData = _d[1];
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function () { return setMounted(true); }, []);
    var getCtrType = function (ctr) {
        if (ctr > 3)
            return "good";
        if (ctr > 1)
            return "mid";
        return "low";
    };
    var getStatus = function (status) {
        if ((status === null || status === void 0 ? void 0 : status.toUpperCase()) === "PAUSED")
            return "Paused";
        if ((status === null || status === void 0 ? void 0 : status.toUpperCase()) === "ACTIVE")
            return "Active";
        return "Brand";
    };
    var combinedData = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
        var google = googleAdsData.map(function (item) {
            var _a, _b, _c, _d, _e, _f, _g;
            return ({
                platform: "Google",
                campaignName: item.CampaignName,
                date: new Date(item.Date),
                spend: Number((_a = item.Spend) !== null && _a !== void 0 ? _a : 0),
                impressions: Number((_b = item.Impressions) !== null && _b !== void 0 ? _b : 0),
                clicks: Number((_c = item.Clicks) !== null && _c !== void 0 ? _c : 0),
                ctr: "".concat(Number((_d = item.CTR) !== null && _d !== void 0 ? _d : 0).toFixed(2), "%"),
                ctrType: getCtrType(Number((_e = item.CTR) !== null && _e !== void 0 ? _e : 0)),
                leads: Number((_f = item.Leads) !== null && _f !== void 0 ? _f : 0),
                cpl: Number((_g = item.CPL) !== null && _g !== void 0 ? _g : 0),
                status: getStatus(item.Status),
            });
        });
        var facebook = facebookAdsData.map(function (item) {
            var _a, _b, _c, _d, _e, _f, _g;
            return ({
                platform: "Facebook",
                campaignName: item.CampaignName,
                date: new Date(item.Date),
                spend: Number((_a = item.Spend) !== null && _a !== void 0 ? _a : 0),
                impressions: Number((_b = item.Impressions) !== null && _b !== void 0 ? _b : 0),
                clicks: Number((_c = item.Clicks) !== null && _c !== void 0 ? _c : 0),
                ctr: "".concat(Number((_d = item.CTR) !== null && _d !== void 0 ? _d : 0).toFixed(2), "%"),
                ctrType: getCtrType(Number((_e = item.CTR) !== null && _e !== void 0 ? _e : 0)),
                leads: Number((_f = item.Leads) !== null && _f !== void 0 ? _f : 0),
                cpl: Number((_g = item.CPL) !== null && _g !== void 0 ? _g : 0),
                status: getStatus(item.Status),
            });
        });
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__spreadArray)((0,tslib__WEBPACK_IMPORTED_MODULE_4__.__spreadArray)([], google, true), facebook, true);
    }, [googleAdsData, facebookAdsData]);
    // ── Filtered rows ──
    var filtered = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
        var startDate = dateRange.startDate, endDate = dateRange.endDate;
        var from = new Date(startDate.getFullYear(), startDate.getMonth(), startDate.getDate()).getTime();
        var to = new Date(endDate.getFullYear(), endDate.getMonth(), endDate.getDate()).getTime();
        var _a = from <= to ? [from, to] : [to, from], normalFrom = _a[0], normalTo = _a[1];
        return combinedData.filter(function (c) {
            var itemTime = new Date(c.date.getFullYear(), c.date.getMonth(), c.date.getDate()).getTime();
            return itemTime >= normalFrom && itemTime <= normalTo;
        });
    }, [combinedData, dateRange]);
    // ── KPI totals ──
    var kpis = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
        var totalSpend = filtered.reduce(function (s, c) { return s + c.spend; }, 0);
        var totalImpressions = filtered.reduce(function (s, c) { return s + c.impressions; }, 0);
        var totalLeads = filtered.reduce(function (s, c) { var _a; return s + ((_a = c.leads) !== null && _a !== void 0 ? _a : 0); }, 0);
        var avgCpl = totalLeads > 0 ? Math.round(totalSpend / totalLeads) : 0;
        return { totalSpend: totalSpend, totalImpressions: totalImpressions, totalLeads: totalLeads, avgCpl: avgCpl };
    }, [filtered]);
    // ── Per-platform aggregates ──
    var platformStats = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
        var agg = function (p) { return ({
            spend: filtered
                .filter(function (c) { return c.platform === p; })
                .reduce(function (s, c) { return s + c.spend; }, 0),
            leads: filtered
                .filter(function (c) { return c.platform === p; })
                .reduce(function (s, c) { var _a; return s + ((_a = c.leads) !== null && _a !== void 0 ? _a : 0); }, 0),
        }); };
        return {
            Google: agg("Google"),
            LinkedIn: agg("LinkedIn"),
            Facebook: agg("Facebook"),
        };
    }, [filtered]);
    // ── Deduplicated campaign table rows ──
    var campaignTable = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
        var map = new Map();
        filtered.forEach(function (c) {
            var _a, _b;
            var key = "".concat(c.platform, "__").concat(c.campaignName);
            if (!map.has(key)) {
                map.set(key, (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)({}, c), { _spend: c.spend, _impressions: c.impressions, _clicks: c.clicks, _leads: (_a = c.leads) !== null && _a !== void 0 ? _a : 0 }));
            }
            else {
                var ex = map.get(key);
                ex._spend += c.spend;
                ex._impressions += c.impressions;
                ex._clicks += c.clicks;
                ex._leads += (_b = c.leads) !== null && _b !== void 0 ? _b : 0;
            }
        });
        return Array.from(map.values());
    }, [filtered]);
    // ─── Fetch Functions ───────────────────────────────────────────────────────
    var fetchGoogleAdsData = function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(void 0, void 0, void 0, function () {
        var response, error_1;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, _pnp_sp__WEBPACK_IMPORTED_MODULE_2__.sp.web.lists
                            .getByTitle("GoogleAds")
                            .items.select("Id", "Date", "CampaignName", "CPL", "Impressions", "Clicks", "Spend", "CTR", "Status", "Leads")
                            .orderBy("Date", false)
                            .getAll()];
                case 1:
                    response = _a.sent();
                    console.log(response, "GoogleAds");
                    setGoogleAdsData(response);
                    return [3 /*break*/, 3];
                case 2:
                    error_1 = _a.sent();
                    console.error("Error fetching Google Ads data:", error_1);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var fetchFaceBookData = function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(void 0, void 0, void 0, function () {
        var response, error_2;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, _pnp_sp__WEBPACK_IMPORTED_MODULE_2__.sp.web.lists
                            .getByTitle("FacebookAds")
                            .items.select("Id", "CampaignName", "Spend", "Impressions", "Clicks", "CTR", "Leads", "CPL", "Date", "Status", "Created", "Modified")
                            .orderBy("Date", false)
                            .getAll()];
                case 1:
                    response = _a.sent();
                    console.log(response, "Facebook Ads Data");
                    setFacebookAdsData(response);
                    return [3 /*break*/, 3];
                case 2:
                    error_2 = _a.sent();
                    console.error("Error fetching Facebook Ads data:", error_2);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function () {
        fetchGoogleAdsData();
        fetchFaceBookData();
    }, []);
    // ─── Chart: Grouped Bar — Spend vs Leads by Platform ──────────────────────
    var spendLeadsData = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
        var google = filtered.filter(function (x) { return x.platform === "Google"; });
        var facebook = filtered.filter(function (x) { return x.platform === "Facebook"; });
        var sum = function (arr, key) {
            return arr.reduce(function (a, b) { return a + (Number(b[key]) || 0); }, 0);
        };
        return {
            labels: ["Google Ads", "Facebook Ads"],
            datasets: [
                {
                    label: "Ad Spend (₹)",
                    backgroundColor: ["#e11d48", "#7c3aed"],
                    data: [sum(google, "spend"), sum(facebook, "spend")],
                },
                {
                    label: "Leads",
                    backgroundColor: "#6ee7b7",
                    data: [sum(google, "leads"), sum(facebook, "leads")],
                },
            ],
        };
    }, [filtered]);
    var spendLeadsOptions = {
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: "top",
                labels: {
                    usePointStyle: true,
                    pointStyle: "rect",
                    padding: 20,
                    color: "#64748b",
                    font: { size: 12, weight: 500 },
                },
            },
        },
        scales: {
            x: {
                grid: { display: false },
                ticks: { color: "#64748b", font: { size: 12 } },
            },
            y: {
                position: "left",
                beginAtZero: true,
                grid: { color: "#e2e8f0" },
                ticks: {
                    callback: function (value) { return "\u20B9".concat(value / 1000, "K"); },
                    color: "#64748b",
                },
            },
            y1: {
                position: "right",
                beginAtZero: true,
                grid: { drawOnChartArea: false },
                ticks: { color: "#64748b" },
            },
        },
    };
    // ─── Chart: Line — CPL Trend Monthly ─────────────────────────────────────
    // FIX: use "YYYY-MMM" as the group key to avoid cross-year collisions,
    //      skip cpl <= 0 (API sends 0 instead of null for no-lead rows),
    //      and sort labels by real date before building datasets.
    var cplTrendData = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
        var grouped = {};
        filtered.forEach(function (item) {
            var d = item.date;
            var monthAbbr = d.toLocaleString("en-US", { month: "short" });
            var key = "".concat(d.getFullYear(), "-").concat(monthAbbr);
            if (!grouped[key]) {
                grouped[key] = {
                    date: new Date(d.getFullYear(), d.getMonth(), 1),
                    Google: [],
                    Facebook: [],
                };
            }
            // ✅ FIX: don't convert null to 0
            var cplVal = item.cpl;
            // ✅ Only push valid CPL
            if (cplVal !== null && cplVal > 0) {
                if (item.platform === "Google") {
                    grouped[key].Google.push(cplVal);
                }
                else if (item.platform === "Facebook") {
                    grouped[key].Facebook.push(cplVal);
                }
            }
        });
        var sortedKeys = Object.keys(grouped).sort(function (a, b) { return grouped[a].date.getTime() - grouped[b].date.getTime(); });
        var labels = sortedKeys.map(function (k) {
            return grouped[k].date.toLocaleString("en-US", { month: "short" });
        });
        var avg = function (arr) {
            return arr.length
                ? Math.round(arr.reduce(function (a, b) { return a + b; }, 0) / arr.length)
                : null;
        };
        return {
            labels: labels,
            datasets: [
                {
                    label: "Google CPL (₹)",
                    data: sortedKeys.map(function (k) { return avg(grouped[k].Google); }),
                    borderColor: "#e11d48",
                    backgroundColor: "rgba(225,29,72,0.07)",
                    fill: true,
                    tension: 0.3,
                    borderWidth: 2,
                    spanGaps: true,
                },
                {
                    label: "Facebook CPL (₹)",
                    data: sortedKeys.map(function (k) { return avg(grouped[k].Facebook); }),
                    borderColor: "#7c3aed",
                    backgroundColor: "rgba(124,58,237,0.05)",
                    fill: false,
                    tension: 0.3,
                    borderWidth: 2,
                    spanGaps: true,
                },
            ],
        };
    }, [filtered]);
    var cplTrendOptions = {
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: "top",
                labels: {
                    usePointStyle: true,
                    pointStyle: "circle",
                    padding: 20,
                    color: "#64748b",
                    font: { size: 12, weight: 500 },
                },
            },
            tooltip: {
                callbacks: {
                    label: function (context) {
                        var value = context.raw;
                        if (value === null || value === undefined)
                            return "No data";
                        return "\u20B9".concat(value);
                    },
                },
            },
        },
        scales: {
            x: {
                grid: { display: false },
                ticks: { color: "#64748b" },
            },
            y: {
                beginAtZero: true,
                grid: { color: "#e2e8f0" },
                ticks: {
                    color: "#64748b",
                    callback: function (value) { return "\u20B9".concat(value); },
                },
            },
        },
    };
    // ─── KPI cards config ──────────────────────────────────────────────────────
    var KPI_CARDS = [
        {
            icon: "💸",
            label: "Total Ad Spend",
            value: "\u20B9".concat(fmt(kpis.totalSpend)),
            sub: "All platforms combined",
            delta: null,
            deltaUp: false,
            accentColor: "#e11d48",
            iconBg: "#fff0f3",
        },
        {
            icon: "👁",
            label: "Total Impressions",
            value: fmt(kpis.totalImpressions),
            sub: "All campaigns",
            delta: "▲ 14%",
            deltaUp: true,
            accentColor: "#1a6ef5",
            iconBg: "#e8f0fe",
        },
        {
            icon: "🎯",
            label: "Leads from Ads",
            value: String(kpis.totalLeads),
            sub: "Google + LinkedIn + FB",
            delta: "▲ 18%",
            deltaUp: true,
            accentColor: "#059669",
            iconBg: "#d1fae5",
        },
        {
            icon: "📉",
            label: "Avg Cost Per Lead",
            value: kpis.avgCpl > 0 ? "\u20B9".concat(kpis.avgCpl) : "—",
            sub: "Blended across platforms",
            delta: "▼ improving",
            deltaUp: true,
            accentColor: "#d97706",
            iconBg: "#fef3c7",
        },
    ];
    var rangeLabel = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
        var startDate = dateRange.startDate, endDate = dateRange.endDate;
        if (!startDate || !endDate)
            return "All time";
        var fmt2 = function (d) {
            return d.toLocaleDateString("en-IN", {
                day: "numeric",
                month: "short",
                year: "numeric",
            });
        };
        return "".concat(fmt2(startDate), " \u2013 ").concat(fmt2(endDate));
    }, [dateRange]);
    // ─────────────────────────────────────────────────────────────────────────────
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "".concat(_PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].paidAds, " ").concat(mounted ? _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]["paidAds--mounted"] : "") },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].topBar },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].topBar__left },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].topBar__title }, "Paid Ads Performance"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].topBar__sep }, "\u00B7"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].topBar__subs }, "Google \u00B7 LinkedIn \u00B7 Facebook \u00B7 Excel data")),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(_DatePicker_DatePicker__WEBPACK_IMPORTED_MODULE_3__["default"], { value: dateRange, onChange: function (range) { return setDateRange(range); }, maxDate: new Date() })),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].innerHeader },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].innerHeader__left },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].innerHeader__icon }, "\uD83D\uDCB0"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].innerHeader__title }, "Paid Ads Performance"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].innerHeader__sub },
                        "Google Ads \u00B7 LinkedIn Ads \u00B7 Facebook Ads \u00B7 Data from Excel \u00B7",
                        " ",
                        rangeLabel))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].btnExcel }, "\uD83D\uDCCA Excel Data")),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("section", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiStrip }, KPI_CARDS.map(function (c, i) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement(KpiCard, (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)({ key: i }, c))); })),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("section", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].chartsRow },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].chartCard },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].chartCard__title }, "Spend vs Leads by Platform"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].chartCard__sub }, rangeLabel),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].chartCard__canvas }, filtered.length > 0 ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_chart__WEBPACK_IMPORTED_MODULE_5__.Chart, { type: "bar", data: spendLeadsData, options: spendLeadsOptions, style: { height: "220px" } })) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].chartCard__empty }, "No data for selected range")))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].chartCard },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].chartCard__title }, "CPL Trend \u2014 Monthly"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].chartCard__sub }, "Cost Per Lead improving over time"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].chartCard__canvas },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_chart__WEBPACK_IMPORTED_MODULE_5__.Chart, { type: "line", data: cplTrendData, options: cplTrendOptions, style: { height: "220px" } })))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("section", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].campaignTable },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].campaignTable__header },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].campaignTable__title }, "Campaign-Level Breakdown"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].campaignTable__sub },
                            "All active campaigns \u00B7 ",
                            rangeLabel,
                            " \u00B7 upload Excel to update"))),
                campaignTable.length === 0 ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].campaignTable__empty }, "\uD83D\uDCED No campaigns found for the selected date range.")) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].campaignTable__scroll },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("table", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].tbl },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("thead", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", null, [
                                "Platform",
                                "Campaign Name",
                                "Spend (₹)",
                                "Impressions",
                                "Clicks",
                                "CTR",
                                "Leads",
                                "CPL (₹)",
                                "Status",
                            ].map(function (h) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", { key: h }, h)); }))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("tbody", null, campaignTable.map(function (r, i) {
                            var row = r;
                            var cpl = row._leads > 0
                                ? Math.round(row._spend / row._leads)
                                : null;
                            return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", { key: i },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null,
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(Pill, { color: PLATFORM_META[r.platform].pillColor }, r.platform)),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]["cell--name"] }, r.campaignName),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]["cell--num"] },
                                    "\u20B9",
                                    fmt(row._spend)),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]["cell--num"] }, fmt(row._impressions)),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]["cell--num"] }, fmt(row._clicks)),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null,
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(Pill, { color: r.ctrType === "good"
                                            ? "teal"
                                            : r.ctrType === "mid"
                                                ? "amber"
                                                : "gray" }, r.ctr)),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]["cell--leads"] }, row._leads > 0 ? (row._leads) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]["cell--muted"] }, "\u2014"))),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, cpl ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(Pill, { color: cpl < 300
                                        ? "green"
                                        : cpl < 450
                                            ? "amber"
                                            : "gray" },
                                    "\u20B9",
                                    cpl)) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]["cell--muted"] }, "\u2014"))),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null,
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(Pill, { color: r.status === "Active"
                                            ? "green"
                                            : r.status === "Paused"
                                                ? "amber"
                                                : "gray" }, r.status))));
                        }))))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].uploadFooter },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "\uD83D\uDCCE"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "Upload ads Excel to add/update campaigns \u00B7 Fields: Platform \u00B7 Campaign \u00B7 Spend \u00B7 Impressions \u00B7 Clicks \u00B7 Leads"))))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PaidAdsPerformance);


/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("2b575733158c3030e3c5")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=marketing-analytics-web-part.c25510828491ccbff2ba.hot-update.js.map