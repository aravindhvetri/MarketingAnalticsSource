"use strict";
self["webpackHotUpdated4faa06d_862f_4712_a355_4e54547f85f3_0_0_1"]("marketing-analytics-web-part",{

/***/ 2312:
/*!*****************************************************************************************!*\
  !*** ./lib/webparts/marketingAnalytics/components/WebsiteAnalytics/WebsiteAnalytics.js ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   filterByDateRange: () => (/* binding */ filterByDateRange)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 196);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 5959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var primereact_chart__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! primereact/chart */ 4964);
/* harmony import */ var primereact_datatable__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! primereact/datatable */ 164);
/* harmony import */ var primereact_column__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! primereact/column */ 1182);
/* harmony import */ var primereact_card__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! primereact/card */ 8874);
/* harmony import */ var primereact_progressbar__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! primereact/progressbar */ 4892);
/* harmony import */ var primereact_skeleton__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! primereact/skeleton */ 1356);
/* harmony import */ var _DatePicker_DatePicker__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../DatePicker/DatePicker */ 8938);
/* harmony import */ var _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./WebsiteAnalytics.module.scss */ 5420);
/* harmony import */ var _pnp_sp__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @pnp/sp */ 2011);












function fmtNum(n) {
    if (n === undefined || n === null || isNaN(n))
        return "0";
    if (n >= 1000000)
        return (n / 1000000).toFixed(1).replace(/\.0$/, "") + "M";
    if (n >= 1000)
        return (n / 1000).toFixed(1).replace(/\.0$/, "") + "K";
    return n.toLocaleString("en-IN");
}
/** Normalize a Date to midnight (strips time component) */
function toMidnight(d) {
    var copy = new Date(d);
    copy.setHours(0, 0, 0, 0);
    return copy;
}
/** Parse "1m 44s" duration strings into total seconds */
function parseDurationToSeconds(duration) {
    var match = duration === null || duration === void 0 ? void 0 : duration.match(/(\d+)m\s*(\d+)s/);
    if (!match)
        return 0;
    return parseInt(match[1], 10) * 60 + parseInt(match[2], 10);
}
/** Format seconds into "Xm Ys" string */
function formatDuration(seconds) {
    return "".concat(Math.floor(seconds / 60), "m ").concat(Math.round(seconds % 60), "s");
}
function defaultRange() {
    var today = toMidnight(new Date());
    return {
        startDate: new Date(today.getFullYear(), today.getMonth(), 1),
        endDate: today,
        label: "This Month",
    };
}
/** Generic date-range filter for items with a Date field */
function filterByDateRange(items, startDate, endDate) {
    // Normalize start and end to midnight, no timezone shift
    var from = new Date(startDate.getFullYear(), startDate.getMonth(), startDate.getDate()).getTime();
    var to = new Date(endDate.getFullYear(), endDate.getMonth(), endDate.getDate()).getTime();
    var _a = from <= to ? [from, to] : [to, from], normalFrom = _a[0], normalTo = _a[1];
    return items.filter(function (item) {
        if (!item.Date)
            return false;
        var itemTime;
        if (item.Date instanceof Date) {
            // Already a Date object
            itemTime = new Date(item.Date.getFullYear(), item.Date.getMonth(), item.Date.getDate()).getTime();
        }
        else {
            var raw = item.Date;
            var datePart = raw.split("T")[0]; // → "2026-03-20"
            var _a = datePart.split("-").map(Number), y = _a[0], m = _a[1], d = _a[2];
            if (!y || !m || !d)
                return false;
            // ✅ Use local Date constructor — no UTC shift
            itemTime = new Date(y, m - 1, d).getTime();
        }
        return itemTime >= normalFrom && itemTime <= normalTo;
    });
}
/** Shared doughnut chart options; unit appended to tooltip if provided */
var doughnutOpts = function (unit) {
    if (unit === void 0) { unit = ""; }
    return ({
        responsive: true,
        maintainAspectRatio: false,
        cutout: "45%",
        plugins: {
            legend: {
                position: "right",
                labels: { usePointStyle: true, font: { size: 11 } },
            },
            tooltip: {
                callbacks: {
                    label: function (ctx) {
                        var _a;
                        var value = Number((_a = ctx.raw) !== null && _a !== void 0 ? _a : 0); // ✅ SAFE
                        return " ".concat(ctx.label, ": ").concat(unit ? value + unit : fmtNum(value));
                    },
                },
            },
        },
    });
};
/** Line chart options for Sessions & Users Trend */
var trendChartOpts = {
    responsive: true,
    maintainAspectRatio: false,
    spanGaps: true,
    elements: {
        line: { tension: 0.4 },
        point: { radius: 4, hoverRadius: 6 },
    },
    plugins: {
        legend: { position: "bottom" },
        tooltip: { mode: "index", intersect: false },
    },
    scales: {
        x: {
            grid: { display: false },
            ticks: { color: "#4d8ef8" },
        },
        y: {
            beginAtZero: true,
            ticks: { color: "#0891b2" },
            grid: { color: "#E5E7EB" },
        },
    },
};
// =============================================================================
// NO DATA PLACEHOLDER
// =============================================================================
var NoData = function () { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { style: {
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        height: "100%",
        minHeight: "120px",
        color: "#9CA3AF",
        gap: "8px",
    } },
    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { style: { fontSize: "28px" } }, "\uD83D\uDCED"),
    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { style: { fontSize: "13px", fontWeight: 500 } }, "No data found"))); };
// MAIN COMPONENT
var WebsiteAnalytics = function () {
    var _a = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(defaultRange), dateRange = _a[0], setDateRange = _a[1];
    var _b = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true), loading = _b[0], setLoading = _b[1];
    // Raw SharePoint data
    var _c = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]), dailySummaryData = _c[0], setDailySummaryData = _c[1];
    var _d = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]), monthlyTrendData = _d[0], setMonthlyTrendData = _d[1];
    var _e = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]), trafficSources = _e[0], setTrafficSources = _e[1];
    var _f = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]), pageDetails = _f[0], setPageDetails = _f[1];
    var _g = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]), countryDetails = _g[0], setCountryDetails = _g[1];
    var _h = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]), deviceSessionMetrics = _h[0], setDeviceSessionMetrics = _h[1];
    var _j = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(1), currentPage = _j[0], setCurrentPage = _j[1];
    var rowsPerPage = 5; // change to 10 if needed
    var fetchDailySummary = function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(void 0, void 0, void 0, function () {
        var response, error_1;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, _pnp_sp__WEBPACK_IMPORTED_MODULE_3__.sp.web.lists
                            .getByTitle("WebsiteAnalyticsDailySummary")
                            .items.select("*")
                            .orderBy("Date", false)
                            .getAll()];
                case 1:
                    response = _a.sent();
                    console.log(response, "dailySummaryData");
                    setDailySummaryData(response.map(function (item) { return ({
                        ID: item.ID,
                        Date: item.Date || null,
                        Users: Number(item.Users || 0),
                        Sessions: Number(item.Sessions || 0),
                        Bounce: Number(item.Bounce || 0),
                        Conversion: Number(item.Conversion || 0),
                        NewUsers: Number(item.NewUsers || 0),
                    }); }));
                    return [3 /*break*/, 3];
                case 2:
                    error_1 = _a.sent();
                    console.error("Error fetching data:", error_1);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var fetchMonthlyTrend = function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(void 0, void 0, void 0, function () {
        var now, sixMonthsAgo, fromISO, response, error_2;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    now = new Date();
                    sixMonthsAgo = new Date(now.getFullYear(), now.getMonth() - 5, 1);
                    fromISO = new Date(sixMonthsAgo.getFullYear(), sixMonthsAgo.getMonth(), sixMonthsAgo.getDate(), 0, 0, 0).toISOString();
                    return [4 /*yield*/, _pnp_sp__WEBPACK_IMPORTED_MODULE_3__.sp.web.lists
                            .getByTitle("WebsiteAnalyticsMonthlyTrend")
                            .items.select("*")
                            .filter("Date ge datetime'".concat(fromISO, "'"))
                            .orderBy("Date", true)
                            .getAll()];
                case 1:
                    response = _a.sent();
                    console.log(response, "monthlyTrendData");
                    setMonthlyTrendData(response.map(function (item) { return ({
                        ID: item.ID,
                        Date: item.Date || null,
                        Sessions: Number(item.Sessions || 0),
                        Users: Number(item.Users || 0),
                    }); }));
                    return [3 /*break*/, 3];
                case 2:
                    error_2 = _a.sent();
                    console.error("Error fetching monthly trend:", error_2);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var fetchTrafficSources = function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(void 0, void 0, void 0, function () {
        var response, error_3;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, _pnp_sp__WEBPACK_IMPORTED_MODULE_3__.sp.web.lists
                            .getByTitle("WebsiteAnalyticsTrafficSources")
                            .items.select("*")
                            .orderBy("Date", false)
                            .getAll()];
                case 1:
                    response = _a.sent();
                    console.log(response, "Traffic");
                    setTrafficSources(response.map(function (item) { return ({
                        ID: item.ID,
                        Date: item.Date || null,
                        TotalUser: Number(item.Sessions || 0),
                        Source: item.Source || "Unknown",
                    }); }));
                    return [3 /*break*/, 3];
                case 2:
                    error_3 = _a.sent();
                    console.error("Error fetching traffic sources:", error_3);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var fetchPageDetails = function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(void 0, void 0, void 0, function () {
        var response, formattedData, error_4;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, _pnp_sp__WEBPACK_IMPORTED_MODULE_3__.sp.web.lists
                            .getByTitle("WebsiteAnalyticsPagesDetails")
                            .items.select("ID", "Date", "Page", "Sessions", "Bounce", "AvgTime", "TotalUser") // ✅ better than *
                            .orderBy("Date", false)
                            .getAll()];
                case 1:
                    response = _a.sent();
                    console.log(response, "pageDetails");
                    formattedData = response.map(function (item) {
                        var _a, _b, _c, _d;
                        return ({
                            ID: item.ID,
                            Date: item.Date ? new Date(item.Date) : null,
                            Page: item.Page || "",
                            Session: Number((_a = item.Sessions) !== null && _a !== void 0 ? _a : 0),
                            Bounce: Number((_b = item.Bounce) !== null && _b !== void 0 ? _b : 0),
                            AvgTime: Number((_c = item.AvgTime) !== null && _c !== void 0 ? _c : 0),
                            totalUsers: Number((_d = item.TotalUser) !== null && _d !== void 0 ? _d : 0),
                        });
                    });
                    setPageDetails(formattedData);
                    return [3 /*break*/, 3];
                case 2:
                    error_4 = _a.sent();
                    console.error("Error fetching page details:", error_4);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var fetchCountryDetails = function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(void 0, void 0, void 0, function () {
        var response, formattedData, error_5;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, _pnp_sp__WEBPACK_IMPORTED_MODULE_3__.sp.web.lists
                            .getByTitle("WebsiteAnalyticsCountry")
                            .items.select("ID", "Date", "Country", "CountryCode", "TotalUsers")
                            .orderBy("Date", false)
                            .getAll()];
                case 1:
                    response = _a.sent();
                    console.log(response, "countryDetails");
                    formattedData = response.map(function (item) {
                        var _a, _b, _c;
                        return ({
                            ID: item.ID,
                            Date: item.Date ? new Date(item.Date) : null,
                            Country: (_a = item.Country) !== null && _a !== void 0 ? _a : "",
                            CountryCode: (_b = item.CountryCode) !== null && _b !== void 0 ? _b : "",
                            TotalUser: Number((_c = item.TotalUsers) !== null && _c !== void 0 ? _c : 0),
                        });
                    });
                    setCountryDetails(formattedData);
                    return [3 /*break*/, 3];
                case 2:
                    error_5 = _a.sent();
                    console.error("Error fetching country details:", error_5);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var fetchDeviceSessionMetrics = function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(void 0, void 0, void 0, function () {
        var response, formattedData, error_6;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, _pnp_sp__WEBPACK_IMPORTED_MODULE_3__.sp.web.lists
                            .getByTitle("WebsiteAnalyticsDeviceSessionMetrics")
                            .items.select("ID", "Date", "Device", "ReturningUsers", "NewUsers", "TotalUsers")
                            .orderBy("Date", false)
                            .getAll()];
                case 1:
                    response = _a.sent();
                    console.log(response, "deviceSessionMetrics");
                    formattedData = response.map(function (item) {
                        var _a, _b, _c;
                        var rawDevice = (item.Device || "").toLowerCase();
                        var validDevices = ["desktop", "mobile", "tablet"];
                        var device = validDevices.indexOf(rawDevice) !== -1
                            ? rawDevice.charAt(0).toUpperCase() + rawDevice.slice(1)
                            : "Desktop";
                        return {
                            ID: item.ID,
                            Date: item.Date ? new Date(item.Date) : null,
                            Device: device,
                            ReturningUsers: Number((_a = item.ReturningUsers) !== null && _a !== void 0 ? _a : 0),
                            NewUsers: Number((_b = item.NewUsers) !== null && _b !== void 0 ? _b : 0),
                            TotalUsers: Number((_c = item.TotalUsers) !== null && _c !== void 0 ? _c : 0),
                        };
                    });
                    setDeviceSessionMetrics(formattedData);
                    return [3 /*break*/, 3];
                case 2:
                    error_6 = _a.sent();
                    console.error("Error fetching device metrics:", error_6);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var fetchAllData = function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(void 0, void 0, void 0, function () {
        var err_1;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0:
                    setLoading(true);
                    setDateRange(defaultRange());
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 3, 4, 5]);
                    return [4 /*yield*/, Promise.all([
                            fetchDailySummary(),
                            fetchMonthlyTrend(),
                            fetchTrafficSources(),
                            fetchPageDetails(),
                            fetchCountryDetails(),
                            fetchDeviceSessionMetrics(),
                        ])];
                case 2:
                    _a.sent();
                    return [3 /*break*/, 5];
                case 3:
                    err_1 = _a.sent();
                    console.error("WebsiteAnalytics fetch error:", err_1);
                    return [3 /*break*/, 5];
                case 4:
                    setLoading(false);
                    return [7 /*endfinally*/];
                case 5: return [2 /*return*/];
            }
        });
    }); };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function () {
        void fetchAllData();
    }, []);
    var startDate = dateRange.startDate, endDate = dateRange.endDate;
    var filteredDaily = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
        if (!startDate || !endDate || !dailySummaryData.length)
            return dailySummaryData;
        return filterByDateRange(dailySummaryData, startDate, endDate);
    }, [dateRange, dailySummaryData]);
    // const filteredMonthly = useMemo(() => {
    //   if (!startDate || !endDate || !monthlyTrendData.length)
    //     return monthlyTrendData;
    //   return monthlyTrendData.filter((item) => {
    //     const d = new Date(item.Date);
    //     return d >= startDate && d <= endDate;
    //   });
    // }, [dateRange, monthlyTrendData]);
    var filteredTrafficSources = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
        if (!startDate || !endDate || !trafficSources.length)
            return trafficSources;
        return filterByDateRange(trafficSources, startDate, endDate);
    }, [dateRange, trafficSources]);
    var filteredPageDetails = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
        if (!startDate || !endDate || !pageDetails.length)
            return pageDetails;
        return filterByDateRange(pageDetails, startDate, endDate);
    }, [dateRange, pageDetails]);
    var filteredCountryDetails = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
        if (!startDate || !endDate || !countryDetails.length)
            return countryDetails;
        return filterByDateRange(countryDetails, startDate, endDate);
    }, [dateRange, countryDetails]);
    var filteredDeviceMetrics = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
        if (!startDate || !endDate || !deviceSessionMetrics.length)
            return deviceSessionMetrics;
        return filterByDateRange(deviceSessionMetrics, startDate, endDate);
    }, [dateRange, deviceSessionMetrics]);
    var totalUsers = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () { return filteredDaily.reduce(function (s, i) { return s + i.Users; }, 0); }, [filteredDaily]);
    var totalSessions = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () { return filteredDaily.reduce(function (s, i) { return s + i.Sessions; }, 0); }, [filteredDaily]);
    var bounceTotal = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
        var total = filteredDaily.reduce(function (sum, item) { return sum + Number(item.Bounce || 0); }, 0);
        return total.toFixed(2) + "%";
    }, [filteredDaily]);
    var convRate = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
        if (!filteredDaily.length)
            return "—";
        var total = filteredDaily.reduce(function (s, i) { return s + Number(i.Conversion || 0); }, 0);
        return total.toFixed(2) + "%";
    }, [filteredDaily]);
    /** Traffic source session totals grouped by source category */
    var sourceTotals = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
        var totals = { Organic: 0, Direct: 0, Social: 0, Referral: 0, Paid: 0 };
        console.log(filteredTrafficSources, "Filtered Traffic Sources");
        filteredTrafficSources.forEach(function (_a) {
            var _b;
            var Source = _a.Source, TotalUser = _a.TotalUser;
            var src = (_b = Source === null || Source === void 0 ? void 0 : Source.toLowerCase()) !== null && _b !== void 0 ? _b : "";
            console.log(src, "sourceess");
            if (src.includes("organic search"))
                totals.Organic += TotalUser;
            else if (src.includes("organic social"))
                totals.Social += TotalUser;
            else if (src.includes("direct"))
                totals.Direct += TotalUser;
            else if (src.includes("referral"))
                totals.Referral += TotalUser;
            else if (src.includes("paid"))
                totals.Paid += TotalUser;
        });
        console.log(totals, "Source Totals");
        return totals;
    }, [filteredTrafficSources]);
    /** Device session counts grouped by device type */
    var deviceStats = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
        var grouped = { Desktop: 0, Mobile: 0, Tablet: 0 };
        filteredDeviceMetrics.forEach(function (_a) {
            var Device = _a.Device, TotalUsers = _a.TotalUsers;
            grouped[Device] =
                (grouped[Device] || 0) + TotalUsers;
        });
        return grouped;
    }, [filteredDeviceMetrics]);
    /** Weighted average session duration across all devices */
    // const avgDuration = useMemo(() => {
    //   if (!filteredDeviceMetrics.length) return 0;
    //   const totalSess = filteredDeviceMetrics.reduce(
    //     (s, i) => s + i.TotalUsers,
    //     0,
    //   );
    //   const totalDur = filteredDeviceMetrics.reduce(
    //     (s, i) => s + i.AvgDuration * i.TotalUsers,
    //     0,
    //   );
    //   return totalSess ? totalDur / totalSess : 0;
    // }, [filteredDeviceMetrics]);
    /** Weighted average pages-per-session across all devices */
    // const avgPages = useMemo(() => {
    //   if (!filteredDeviceMetrics.length) return 0;
    //   const totalSess = filteredDeviceMetrics.reduce(
    //     (s, i) => s + i.TotalUsers,
    //     0,
    //   );
    //   const totalPgs = filteredDeviceMetrics.reduce(
    //     (s, i) => s + i.PagesPerSession * i.TotalUsers,
    //     0,
    //   );
    //   return totalSess ? totalPgs / totalSess : 0;
    // }, [filteredDeviceMetrics]);
    /** New vs returning user split percentage */
    var newVsReturning = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
        if (!filteredDeviceMetrics.length)
            return "— / —";
        var totalNew = filteredDeviceMetrics.reduce(function (s, i) { return s + i.NewUsers; }, 0);
        var totalReturning = filteredDeviceMetrics.reduce(function (s, i) { return s + i.ReturningUsers; }, 0);
        var totalAllUsers = filteredDeviceMetrics.reduce(function (s, i) { return s + i.TotalUsers; }, 0);
        var newPct = totalAllUsers
            ? Math.round((totalNew / totalAllUsers) * 100)
            : 0;
        var returningPct = totalAllUsers
            ? Math.round((totalReturning / totalAllUsers) * 100)
            : 0;
        return "".concat(newPct, "% / ").concat(returningPct, "%");
    }, [filteredDeviceMetrics]);
    var countryStats = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
        if (!filteredCountryDetails.length)
            return [];
        var grouped = {};
        filteredCountryDetails.forEach(function (_a) {
            var Country = _a.Country, CountryCode = _a.CountryCode, TotalUser = _a.TotalUser;
            var key = (Country === null || Country === void 0 ? void 0 : Country.trim()) || "Unknown";
            if (!grouped[key]) {
                grouped[key] = {
                    name: key,
                    code: CountryCode || "XX",
                    totaluser: 0,
                };
            }
            grouped[key].totaluser += Number(TotalUser) || 0;
        });
        var result = Object.keys(grouped).map(function (key) { return grouped[key]; });
        var total = result.reduce(function (s, r) { return s + r.totaluser; }, 0);
        var max = Math.max.apply(Math, (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__spreadArray)((0,tslib__WEBPACK_IMPORTED_MODULE_4__.__spreadArray)([], result.map(function (r) { return r.totaluser; }), false), [1], false));
        return result
            .map(function (r) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)({}, r), { pct: total > 0 ? Math.round((r.totaluser / total) * 100) : 0, progress: Math.round((r.totaluser / max) * 100) })); })
            .sort(function (a, b) { return b.totaluser - a.totaluser; }); // ❌ no slice
    }, [filteredCountryDetails]);
    var totalPages = Math.ceil(countryStats.length / rowsPerPage);
    var groupedPages = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
        var map = {};
        filteredPageDetails.forEach(function (item) {
            var key = item.Page || "Unknown";
            if (!map[key]) {
                map[key] = {
                    page: key,
                    sessions: 0,
                    totalBounce: 0,
                    totalTime: 0,
                    totalUsers: 0,
                    count: 0,
                };
            }
            map[key].sessions += item.Session || 0;
            map[key].totalBounce += item.Bounce || 0;
            map[key].totalTime += item.AvgTime || 0;
            map[key].count += 1;
            map[key].totalUsers += item.totalUsers || 0;
        });
        // SAFE return
        return Object.keys(map).map(function (key) { return map[key]; });
    }, [filteredPageDetails]);
    var topPagesData = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
        return groupedPages
            .map(function (item) {
            var avgBounce = item.totalBounce / item.count;
            var avgTime = item.totalTime / item.count;
            return {
                page: item.page,
                sessions: item.sessions,
                totalUsers: item.totalUsers,
                bounce: "".concat(avgBounce.toFixed(1), "%"),
                avgTime: formatDuration(avgTime),
            };
        })
            .sort(function (a, b) { return b.sessions - a.sessions; });
    }, [groupedPages]);
    var trendChartData = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
        var _a, _b;
        var grouped = {};
        (monthlyTrendData || []).forEach(function (item) {
            var d = new Date(item.Date);
            var month = d.getMonth() + 1;
            var key = "".concat(d.getFullYear(), "-").concat(month < 10 ? "0" : "").concat(month);
            if (!grouped[key]) {
                grouped[key] = {
                    Sessions: 0,
                    Users: 0,
                    label: "",
                };
            }
            grouped[key].Sessions += item.Sessions;
            grouped[key].Users += item.Users;
        });
        var months = [];
        var today = new Date();
        for (var i = 5; i >= 0; i--) {
            var d = new Date(today.getFullYear(), today.getMonth() - i, 1);
            var month = d.getMonth() + 1;
            var key = "".concat(d.getFullYear(), "-").concat(month < 10 ? "0" : "").concat(month);
            var label = d.toLocaleDateString("en-IN", {
                month: "short",
                year: "2-digit",
            });
            months.push({
                label: label,
                Sessions: ((_a = grouped[key]) === null || _a === void 0 ? void 0 : _a.Sessions) || 0,
                Users: ((_b = grouped[key]) === null || _b === void 0 ? void 0 : _b.Users) || 0,
            });
        }
        console.log("Trend Chart Data:", months);
        return {
            labels: months.map(function (m) { return m.label; }),
            datasets: [
                {
                    label: "Sessions",
                    data: months.map(function (m) { return m.Sessions; }),
                    borderColor: "#4F46E5",
                    backgroundColor: "rgba(79,70,229,0.15)",
                    tension: 0.4,
                    fill: true,
                },
                {
                    label: "Users",
                    data: months.map(function (m) { return m.Users; }),
                    borderColor: "#06B6D4",
                    backgroundColor: "rgba(6,182,212,0.15)",
                    tension: 0.4,
                    fill: true,
                },
            ],
        };
    }, [monthlyTrendData]);
    var sourceChartData = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () { return ({
        labels: ["Organic Search", "Direct", "Social", "Referral", "Paid"],
        datasets: [
            {
                data: [
                    sourceTotals.Organic,
                    sourceTotals.Direct,
                    sourceTotals.Social,
                    sourceTotals.Referral,
                    sourceTotals.Paid,
                ],
                backgroundColor: [
                    "#1a6ef5",
                    "#0891b2",
                    "#7c3aed",
                    "#d97706",
                    "#e11d48",
                ],
                hoverOffset: 6,
                borderWidth: 2,
                borderColor: "#fff",
            },
        ],
    }); }, [sourceTotals]);
    var deviceChartData = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
        var total = deviceStats.Desktop + deviceStats.Mobile + deviceStats.Tablet;
        return {
            labels: ["Desktop", "Mobile", "Tablet"],
            datasets: [
                {
                    data: [deviceStats.Desktop, deviceStats.Mobile, deviceStats.Tablet],
                    backgroundColor: ["#1e3a5f", "#1a6ef5", "#0891b2"],
                    borderWidth: 2,
                    borderColor: "#fff",
                },
            ],
        };
    }, [deviceStats]);
    var kpis = [
        {
            iconBg: "#e8f0fe",
            icon: "👤",
            label: "Total Users",
            value: filteredDaily.length === 0 ? "—" : fmtNum(totalUsers),
            sub: "Unique visitors",
            accent: "#1a6ef5",
        },
        {
            iconBg: "#e0f5fa",
            icon: "📊",
            label: "Sessions",
            value: filteredDaily.length === 0 ? "—" : fmtNum(totalSessions),
            sub: "Total sessions",
            accent: "#0891b2",
        },
        {
            iconBg: "#ffe4e6",
            icon: "↩",
            label: "Bounce Rate",
            value: String(bounceTotal),
            sub: "Lower is better",
            accent: "#e11d48",
        },
        {
            iconBg: "#d1fae5",
            icon: "🎯",
            label: "Conversion Rate",
            value: convRate,
            sub: "Goal completions",
            accent: "#059669",
        },
    ];
    var miniMetrics = [
        // {
        //   label: "Avg Session Duration",
        //   value:
        //     filteredDeviceMetrics.length === 0 ? "—" : formatDuration(avgDuration),
        // },
        // {
        //   label: "Pages per Users",
        //   value: filteredDeviceMetrics.length === 0 ? "—" : avgPages.toFixed(1),
        // },
        { label: "New vs Returning", value: newVsReturning },
    ];
    var rangeLabel = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
        if (!startDate || !endDate)
            return "All time";
        var fmt = function (d) {
            return d.toLocaleDateString("en-IN", {
                day: "numeric",
                month: "short",
                year: "numeric",
            });
        };
        return "".concat(fmt(startDate), " \u2013 ").concat(fmt(endDate));
    }, [dateRange]);
    var pageTemplate = function (rowData) { return react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, rowData.page); };
    var sessionsTemplate = function (rowData) { return rowData.sessions.toLocaleString(); };
    var TotalUserTemplate = function (rowData) {
        return rowData.totalUsers.toLocaleString();
    };
    var bounceTemplate = function (rowData) {
        var value = parseFloat(rowData.bounce || "0");
        var severity = value > 60 ? "high" : value > 40 ? "medium" : "low";
        return react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "badge ".concat(severity) }, rowData.bounce);
    };
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].root },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].wrapper },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].topHeader },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].topLeft },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].mainTitle }, "Website Analytics"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].mainSub }, "GA4 Connected \u00B7 technorucs.com")),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { style: { display: "flex", alignItems: "center", gap: "8px" } },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(_DatePicker_DatePicker__WEBPACK_IMPORTED_MODULE_1__["default"], { value: dateRange, onChange: function (range) { return setDateRange(range); }, maxDate: new Date() }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].connectBtn }, "\uD83D\uDD17 Connect Sources"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].refreshBtn, onClick: fetchAllData }, "\u21BB Refresh"))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].secHeader },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].secLeft },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].secIcon }, "\uD83C\uDF10"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].secTitle }, "Website Analytics"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].secSub },
                            "Connected via Google Analytics 4 \u00B7 ",
                            rangeLabel))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].secRight },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].sourceBadge }, "\uD83D\uDD17 GA4 Connected")))),
        loading && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].loadingBar },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_progressbar__WEBPACK_IMPORTED_MODULE_5__.ProgressBar, { mode: "indeterminate", style: { height: "4px" } }))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].g4 }, kpis.map(function (k, i) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { key: i, className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].kpiCard },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].kpiTop },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].kpiIconBox, style: { background: k.iconBg } }, k.icon)),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].kpiLabel }, k.label),
            loading ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_skeleton__WEBPACK_IMPORTED_MODULE_6__.Skeleton, { height: "28px", className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].kpiVal })) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].kpiVal }, k.value)),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].kpiSub }, k.sub),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].kpiAccent, style: { background: k.accent } }))); })),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].gridTwo },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_card__WEBPACK_IMPORTED_MODULE_7__.Card, { header: react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].cardHdr },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].cardTitle }, "Sessions & Users Trend")), className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].card },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { style: { height: "260px" } }, loading ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_skeleton__WEBPACK_IMPORTED_MODULE_6__.Skeleton, { height: "260px" })) : monthlyTrendData.length === 0 ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(NoData, null)) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_chart__WEBPACK_IMPORTED_MODULE_8__.Chart, { type: "line", data: trendChartData, options: trendChartOpts, style: { height: "100%" } })))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_card__WEBPACK_IMPORTED_MODULE_7__.Card, { header: react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].cardHdr },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].cardTitle }, "Traffic Sources"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].cardSub }, rangeLabel)), className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].card },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { style: { height: "200px" } }, loading ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_skeleton__WEBPACK_IMPORTED_MODULE_6__.Skeleton, { height: "200px" })) : filteredTrafficSources.length === 0 ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(NoData, null)) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_chart__WEBPACK_IMPORTED_MODULE_8__.Chart, { type: "doughnut", data: sourceChartData, options: doughnutOpts(), style: { height: "100%" } }))))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].gW3 },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_card__WEBPACK_IMPORTED_MODULE_7__.Card, { header: react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].cardHdr },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].cardTitle }, "Top Pages"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].cardSub },
                        "By sessions \u00B7 ",
                        rangeLabel)), className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].card }, loading ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_skeleton__WEBPACK_IMPORTED_MODULE_6__.Skeleton, { height: "200px" })) : topPagesData.length === 0 ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(NoData, null)) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_datatable__WEBPACK_IMPORTED_MODULE_9__.DataTable, { value: topPagesData, size: "small", className: "top-pages-table", stripedRows: true, paginator: topPagesData && topPagesData.length > 0, rows: 6 },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_column__WEBPACK_IMPORTED_MODULE_10__.Column, { field: "page", header: "PAGE", style: { width: "44%" }, body: pageTemplate }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_column__WEBPACK_IMPORTED_MODULE_10__.Column, { field: "TotalUser", style: { width: "14%" }, header: "USERS", body: TotalUserTemplate, headerClassName: "left", bodyClassName: "left" }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_column__WEBPACK_IMPORTED_MODULE_10__.Column, { field: "sessions", style: { width: "14%" }, header: "SESSIONS", body: sessionsTemplate, headerClassName: "left", bodyClassName: "left" }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_column__WEBPACK_IMPORTED_MODULE_10__.Column, { field: "bounce", style: { width: "14%" }, header: "BOUNCE", body: bounceTemplate, headerClassName: "left", bodyClassName: "left" }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_column__WEBPACK_IMPORTED_MODULE_10__.Column, { field: "avgTime", style: { width: "14%" }, header: "AVG TIME", headerClassName: "left", bodyClassName: "left" })))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_card__WEBPACK_IMPORTED_MODULE_7__.Card, { header: react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].cardHdr },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].cardTitle }, "Visitors by Country"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].cardSub }, "Session share")), className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].card },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].geoPadding }, loading ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_skeleton__WEBPACK_IMPORTED_MODULE_6__.Skeleton, { height: "200px" })) : countryStats.length === 0 ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(NoData, null)) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_datatable__WEBPACK_IMPORTED_MODULE_9__.DataTable, { value: countryStats, paginator: countryStats && countryStats.length > 0, rows: 5, showGridlines: false, className: "custom-country-table" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_column__WEBPACK_IMPORTED_MODULE_10__.Column, { body: function (rowData) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].geoRow },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].geoLeft },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].geoCode }, rowData.code),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].geoName }, rowData.name)),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].geoBarWrap },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].geoBar },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].geoFill, style: { width: "".concat(rowData.progress, "%") } }))),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].geoRight },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].geoSess }, fmtNum(rowData.totaluser)),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].geoPct },
                                    rowData.pct,
                                    "%")))); } }))))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_card__WEBPACK_IMPORTED_MODULE_7__.Card, { header: react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].cardHdr },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].cardTitle }, "Device & Session Metrics")), className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].card },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].chartWrapSm }, loading ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_skeleton__WEBPACK_IMPORTED_MODULE_6__.Skeleton, { height: "180px" })) : filteredDeviceMetrics.length === 0 ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(NoData, null)) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_chart__WEBPACK_IMPORTED_MODULE_8__.Chart, { type: "doughnut", data: deviceChartData, options: doughnutOpts(), style: { height: "100%" } }))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].divider }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].miniSection }, miniMetrics.map(function (m, i) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { key: i, className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].miniM },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].miniLabel }, m.label),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: _WebsiteAnalytics_module_scss__WEBPACK_IMPORTED_MODULE_2__["default"].miniVal }, m.value))); }))))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (WebsiteAnalytics);


/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("29eca5c7303c317e0702")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=marketing-analytics-web-part.59fd344785b5d8b4ec69.hot-update.js.map