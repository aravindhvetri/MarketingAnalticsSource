"use strict";
self["webpackHotUpdated4faa06d_862f_4712_a355_4e54547f85f3_0_0_1"]("marketing-analytics-web-part",{

/***/ 5420:
/*!******************************************************************************************************!*\
  !*** ./lib/webparts/marketingAnalytics/components/WebsiteAnalytics/WebsiteAnalytics.module.scss.css ***!
  \******************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_microsoft_sp_css_loader_node_modules_microsoft_load_themed_styles_lib_es6_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../../../node_modules/@microsoft/sp-css-loader/node_modules/@microsoft/load-themed-styles/lib-es6/index.js */ 6323);
// Imports


_node_modules_microsoft_sp_css_loader_node_modules_microsoft_load_themed_styles_lib_es6_index_js__WEBPACK_IMPORTED_MODULE_0__.loadStyles(".geoPadding_4b449b2a{display:flex;flex-direction:column;gap:14px}.geoRow_4b449b2a{display:grid;gap:12px;grid-template-columns:140px 1fr 90px}.geoLeft_4b449b2a{align-items:center;display:flex;gap:8px}.geoCode_4b449b2a{color:#6b7280;font-size:12px;font-weight:600;width:24px}.geoName_4b449b2a{color:#111827;font-weight:500}.geoBarWrap_4b449b2a{width:100%}.geoBar_4b449b2a{background:#e5e7eb;border-radius:999px;position:relative}.geoFill_4b449b2a{background:#3b82f6}.geoRight_4b449b2a{display:flex;gap:10px;justify-content:flex-end;min-width:80px}.geoSess_4b449b2a{color:#374151;font-size:12px;font-weight:500}.geoPct_4b449b2a{color:#6b7280;font-weight:600}.card_4b449b2a{border-radius:14px;box-shadow:0 1px 2px rgba(16,24,40,.05),0 1px 3px rgba(16,24,40,.1)}.header_4b449b2a{margin-bottom:14px}.title_4b449b2a{color:#111827;font-size:15px;font-weight:600}.sub_4b449b2a{color:#6b7280;font-size:12px;margin-top:2px}.table_4b449b2a{border-collapse:collapse;width:100%}th{border-bottom:1px solid #e5e7eb;color:#9ca3af;font-size:11px;font-weight:600;letter-spacing:.04em;padding:10px 0;text-align:left}td{border-bottom:1px solid #f1f5f9;color:#374151;font-size:13px;padding:14px 0}tr:last-child td{border-bottom:none}.page_4b449b2a{color:#1f2937;font-weight:500}.pill_4b449b2a{border-radius:999px;display:inline-block;font-size:11px;font-weight:600;padding:4px 10px}.green_4b449b2a{background-color:#dcfce7;color:#15803d}.orange_4b449b2a{background-color:#fef3c7;color:#b45309}.red_4b449b2a{background-color:#fee2e2;color:#b91c1c}tbody tr:hover{background-color:#f9fafb;transition:.2s ease}.root_4b449b2a{background:#f4f7fb;color:#0f1c35;font-family:Segoe UI,Arial,sans-serif;min-height:100vh}.root_4b449b2a,.root_4b449b2a *,.root_4b449b2a :after,.root_4b449b2a :before{box-sizing:border-box}.gridTwo_4b449b2a{display:grid;gap:16px;grid-template-columns:2fr 1fr;margin-top:16px}.card_4b449b2a{box-shadow:0 2px 8px rgba(0,0,0,.06)}.cardTitle_4b449b2a{color:#111827;font-size:14px;font-weight:600}.cardSub_4b449b2a{color:#6b7280;margin-top:-13px!important}.wrapper_4b449b2a{background:#f4f7fb;border:1px solid #e2e8f2;border-radius:12px;box-shadow:0 2px 8px rgba(30,58,95,.08);margin-bottom:20px}.topHeader_4b449b2a{align-items:center;background:#f1f4f9;border-bottom:1px solid #e2e8f2;display:flex;flex-wrap:wrap;gap:10px;justify-content:space-between;padding:14px 20px}.topLeft_4b449b2a{display:flex;flex-direction:column}.mainTitle_4b449b2a{color:#1e3a5f;font-size:16px;font-weight:700}.mainSub_4b449b2a{color:#8a9bbf;font-size:12px;margin-top:2px}.connectBtn_4b449b2a{background:#eef2ff;border:1px solid #dbe3ff;border-radius:6px;color:#1e3a5f;cursor:pointer;font-size:12px;font-weight:500;padding:6px 12px;transition:background .2s}.connectBtn_4b449b2a:hover{background:#dbe3ff}.refreshBtn_4b449b2a{background:#1a6ef5;border:none;border-radius:6px;color:#fff;cursor:pointer;font-size:12px;font-weight:600;padding:6px 14px;transition:background .2s}.refreshBtn_4b449b2a:hover{background:#1558d0}.secHeader_4b449b2a{align-items:center;background:#fff;border-bottom:1px solid #e2e8f2;display:flex;flex-wrap:wrap;gap:10px;justify-content:space-between;padding:14px 20px}.secLeft_4b449b2a{align-items:center;display:flex;gap:12px}.secIcon_4b449b2a{align-items:center;background:#e8f0fe;border-radius:10px;display:flex;flex-shrink:0;font-size:18px;height:36px;justify-content:center;width:36px}.secTitle_4b449b2a{color:#1e3a5f;font-size:16px;font-weight:700}.secSub_4b449b2a{color:#8a9bbf;font-size:12px;margin-top:2px}.secRight_4b449b2a{align-items:center;display:flex}.sourceBadge_4b449b2a{background:#fef3c7;border:1px solid #fde8b3;border-radius:20px;color:#d97706;font-size:11px;font-weight:600;padding:5px 12px;white-space:nowrap}.loadingBar_4b449b2a{margin-bottom:16px}.g4_4b449b2a{display:grid;gap:16px;grid-template-columns:repeat(4,1fr);margin-bottom:20px}@media (max-width:1100px){.g4_4b449b2a{grid-template-columns:repeat(2,1fr)}}@media (max-width:600px){.g4_4b449b2a{grid-template-columns:1fr}}.kpiCard_4b449b2a{background:#fff;border:none;border-radius:14px;box-shadow:0 4px 16px rgba(0,0,0,.06);overflow:hidden;padding:18px;position:relative;transition:all .2s ease}.kpiCard_4b449b2a:hover{box-shadow:0 8px 22px rgba(0,0,0,.08);transform:translateY(-3px)}.kpiTop_4b449b2a{align-items:flex-start;display:flex;justify-content:space-between;margin-bottom:10px}.kpiIconBox_4b449b2a{align-items:center;border-radius:12px;box-shadow:inset 0 0 0 1px hsla(0,0%,100%,.4);display:flex;font-size:18px;height:42px;justify-content:center;width:42px}.kpiDelta_4b449b2a{background:#d1fae5;border-radius:20px;color:#059669;font-size:11px;font-weight:700;padding:2px 8px}.kpiLabel_4b449b2a{color:#8a9bbf;font-size:11px;font-weight:600;letter-spacing:1px;margin-bottom:4px;text-transform:uppercase}.kpiVal_4b449b2a{color:#1e3a5f;font-size:26px;font-weight:800;letter-spacing:-.5px;line-height:1}.kpiSub_4b449b2a{color:#8a9bbf;font-size:11px;margin-top:4px}.kpiAccent_4b449b2a{bottom:0;height:3px;left:0;position:absolute;right:0}.gWide_4b449b2a{display:grid;gap:16px;grid-template-columns:3fr 2fr;margin-bottom:20px}@media (max-width:900px){.gWide_4b449b2a{grid-template-columns:1fr}}.gW3_4b449b2a{display:grid;gap:16px;grid-template-columns:2fr 1fr 1fr;margin:10px}@media (max-width:1050px){.gW3_4b449b2a{grid-template-columns:1fr 1fr}}@media (max-width:680px){.gW3_4b449b2a{grid-template-columns:1fr}}.card_4b449b2a{animation:cardIn_4b449b2a .4s ease both;background:#fff;border:1px solid #e2e8f2;border-radius:12px;box-shadow:0 2px 8px rgba(30,58,95,.08);overflow:hidden}.cardHdr_4b449b2a{padding:16px 16px 0}.cardTitle_4b449b2a{color:#1e3a5f;font-size:15px;font-weight:700;margin-bottom:20px}.cardSub_4b449b2a{color:#8a9bbf;font-size:12px;margin-top:2px}.chartWrap_4b449b2a{height:220px;padding:12px 16px 16px}.chartWrapSm_4b449b2a{height:200px}.geoRow_4b449b2a{align-items:center;border-bottom:1px solid #eef1f8;display:flex;gap:10px;padding:9px 0}.geoRow_4b449b2a:last-child{border-bottom:none}.geoFlag_4b449b2a{flex-shrink:0;font-size:20px;text-align:center;width:28px}.geoName_4b449b2a{color:#0f1c35;font-size:13px;font-weight:600;width:80px}.geoBarWrap_4b449b2a{flex:1}.geoBar_4b449b2a{background:#eef1f8;border-radius:4px;height:6px;overflow:hidden}.geoFill_4b449b2a{background:linear-gradient(90deg,#1a6ef5,#4d8ef8);border-radius:4px;height:100%;transition:width .6s ease}.geoSess_4b449b2a{color:#1e3a5f;font-size:13px;font-weight:600;width:52px}.geoPct_4b449b2a,.geoSess_4b449b2a{font-family:JetBrains Mono,Courier New,monospace;text-align:right}.geoPct_4b449b2a{color:#8a9bbf;font-size:12px;width:34px}.miniSection_4b449b2a{padding:0 16px 12px}.divider_4b449b2a{background:#e2e8f2;height:1px;margin:60px 0 5px}.miniM_4b449b2a{align-items:center;border-bottom:1px solid #eef1f8;display:flex;justify-content:space-between;padding:8px 0}.miniM_4b449b2a:last-child{border-bottom:none}.miniLabel_4b449b2a{color:#8a9bbf;font-size:12px;font-weight:500}.miniVal_4b449b2a{color:#1e3a5f;font-family:JetBrains Mono,Courier New,monospace;font-size:13px;font-weight:700}.emptyState_4b449b2a{color:#8a9bbf;font-size:13px;font-weight:500;padding:40px 0;text-align:center}@keyframes cardIn_4b449b2a{0%{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}", true);

// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({
  geoPadding: "geoPadding_4b449b2a",
  geoRow: "geoRow_4b449b2a",
  geoLeft: "geoLeft_4b449b2a",
  geoCode: "geoCode_4b449b2a",
  geoName: "geoName_4b449b2a",
  geoBarWrap: "geoBarWrap_4b449b2a",
  geoBar: "geoBar_4b449b2a",
  geoFill: "geoFill_4b449b2a",
  geoRight: "geoRight_4b449b2a",
  geoSess: "geoSess_4b449b2a",
  geoPct: "geoPct_4b449b2a",
  card: "card_4b449b2a",
  header: "header_4b449b2a",
  title: "title_4b449b2a",
  sub: "sub_4b449b2a",
  table: "table_4b449b2a",
  pill: "pill_4b449b2a",
  green: "green_4b449b2a",
  orange: "orange_4b449b2a",
  red: "red_4b449b2a",
  root: "root_4b449b2a",
  gridTwo: "gridTwo_4b449b2a",
  cardTitle: "cardTitle_4b449b2a",
  cardSub: "cardSub_4b449b2a",
  wrapper: "wrapper_4b449b2a",
  topHeader: "topHeader_4b449b2a",
  topLeft: "topLeft_4b449b2a",
  mainTitle: "mainTitle_4b449b2a",
  mainSub: "mainSub_4b449b2a",
  connectBtn: "connectBtn_4b449b2a",
  refreshBtn: "refreshBtn_4b449b2a",
  secHeader: "secHeader_4b449b2a",
  secLeft: "secLeft_4b449b2a",
  secIcon: "secIcon_4b449b2a",
  secTitle: "secTitle_4b449b2a",
  secSub: "secSub_4b449b2a",
  secRight: "secRight_4b449b2a",
  sourceBadge: "sourceBadge_4b449b2a",
  loadingBar: "loadingBar_4b449b2a",
  g4: "g4_4b449b2a",
  kpiCard: "kpiCard_4b449b2a",
  kpiTop: "kpiTop_4b449b2a",
  kpiIconBox: "kpiIconBox_4b449b2a",
  kpiDelta: "kpiDelta_4b449b2a",
  kpiLabel: "kpiLabel_4b449b2a",
  kpiVal: "kpiVal_4b449b2a",
  kpiSub: "kpiSub_4b449b2a",
  kpiAccent: "kpiAccent_4b449b2a",
  gWide: "gWide_4b449b2a",
  gW3: "gW3_4b449b2a",
  cardIn: "cardIn_4b449b2a",
  cardHdr: "cardHdr_4b449b2a",
  chartWrap: "chartWrap_4b449b2a",
  chartWrapSm: "chartWrapSm_4b449b2a",
  geoFlag: "geoFlag_4b449b2a",
  miniSection: "miniSection_4b449b2a",
  divider: "divider_4b449b2a",
  miniM: "miniM_4b449b2a",
  miniLabel: "miniLabel_4b449b2a",
  miniVal: "miniVal_4b449b2a",
  emptyState: "emptyState_4b449b2a",
  page: "page_4b449b2a"
});


/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("2e2e964804696d1e7c50")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=marketing-analytics-web-part.4eee2597960ab8d94482.hot-update.js.map