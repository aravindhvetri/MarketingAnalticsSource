"use strict";
self["webpackHotUpdated4faa06d_862f_4712_a355_4e54547f85f3_0_0_1"]("marketing-analytics-web-part",{

/***/ 5440:
/*!***************************************************************************************!*\
  !*** ./lib/webparts/marketingAnalytics/components/SEOIntelligence/SEOIntelligence.js ***!
  \***************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 196);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 5959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./SEOIntelligence.module.scss */ 7356);
/* harmony import */ var _DatePicker_DatePicker__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../DatePicker/DatePicker */ 8938);
/* harmony import */ var primereact_chart__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! primereact/chart */ 4964);
/* harmony import */ var _pnp_sp__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @pnp/sp */ 2011);







var ALL_SEO_DATA = [
    {
        month: new Date(2025, 9, 1),
        keywordsTop10: 12,
        totalBacklinks: 1200,
        kwImproved: 8,
        seoLeads: 98,
        rankDist: { top10: 12, rank11_50: 28, rank51_100: 36, notRanked: 10 },
        backlinkMetrics: [
            { label: "New Backlinks Inserted", value: "25" },
            { label: "Referring Domains (Total)", value: "185" },
            { label: "Dofollow Links", value: "82" },
            { label: "Nofollow Links", value: "1,118" },
            { label: "Domain Authority (Moz)", value: "29" },
            {
                label: "Backlinks vs Prev Month",
                value: "▲ +25 (+2.1%)",
                isDelta: true,
                deltaUp: true,
            },
        ],
        kwSummary: { improved: 8, declined: 5, unchanged: 9 },
        keywordRows: [
            {
                keyword: "sharepoint migration services",
                prevRank: "#18",
                currRank: "#14",
                change: 4,
                volume: "1,600",
                status: "Improved",
            },
            {
                keyword: "power platform consulting india",
                prevRank: "#24",
                currRank: "#19",
                change: 5,
                volume: "1,200",
                status: "Improved",
            },
            {
                keyword: "microsoft copilot studio partner",
                prevRank: "#30",
                currRank: "#25",
                change: 5,
                volume: "900",
                status: "Improved",
            },
            {
                keyword: "sharepoint intranet development",
                prevRank: "#9",
                currRank: "#12",
                change: -3,
                volume: "1,300",
                status: "Declined",
            },
            {
                keyword: "dynamics 365 implementation",
                prevRank: "#20",
                currRank: "#18",
                change: 2,
                volume: "800",
                status: "Improved",
            },
            {
                keyword: "salesforce crm migration",
                prevRank: "#26",
                currRank: "#22",
                change: 4,
                volume: "1,100",
                status: "Improved",
            },
        ],
    },
    {
        month: new Date(2025, 10, 1),
        keywordsTop10: 14,
        totalBacklinks: 1320,
        kwImproved: 10,
        seoLeads: 115,
        rankDist: { top10: 14, rank11_50: 29, rank51_100: 34, notRanked: 9 },
        backlinkMetrics: [
            { label: "New Backlinks Inserted", value: "30" },
            { label: "Referring Domains (Total)", value: "210" },
            { label: "Dofollow Links", value: "90" },
            { label: "Nofollow Links", value: "1,230" },
            { label: "Domain Authority (Moz)", value: "31" },
            {
                label: "Backlinks vs Prev Month",
                value: "▲ +30 (+2.5%)",
                isDelta: true,
                deltaUp: true,
            },
        ],
        kwSummary: { improved: 10, declined: 4, unchanged: 8 },
        keywordRows: [
            {
                keyword: "sharepoint migration services",
                prevRank: "#14",
                currRank: "#10",
                change: 4,
                volume: "1,600",
                status: "Improved",
            },
            {
                keyword: "power platform consulting india",
                prevRank: "#19",
                currRank: "#15",
                change: 4,
                volume: "1,200",
                status: "Improved",
            },
            {
                keyword: "microsoft copilot studio partner",
                prevRank: "#25",
                currRank: "#20",
                change: 5,
                volume: "900",
                status: "Improved",
            },
            {
                keyword: "sharepoint intranet development",
                prevRank: "#12",
                currRank: "#10",
                change: 2,
                volume: "1,300",
                status: "Improved",
            },
            {
                keyword: "dynamics 365 implementation",
                prevRank: "#18",
                currRank: "#16",
                change: 2,
                volume: "800",
                status: "Improved",
            },
            {
                keyword: "salesforce crm migration",
                prevRank: "#22",
                currRank: "#19",
                change: 3,
                volume: "1,100",
                status: "Improved",
            },
        ],
    },
    {
        month: new Date(2025, 11, 1),
        keywordsTop10: 15,
        totalBacklinks: 1420,
        kwImproved: 11,
        seoLeads: 128,
        rankDist: { top10: 15, rank11_50: 30, rank51_100: 32, notRanked: 9 },
        backlinkMetrics: [
            { label: "New Backlinks Inserted", value: "28" },
            { label: "Referring Domains (Total)", value: "230" },
            { label: "Dofollow Links", value: "95" },
            { label: "Nofollow Links", value: "1,325" },
            { label: "Domain Authority (Moz)", value: "32" },
            {
                label: "Backlinks vs Prev Month",
                value: "▲ +28 (+2.1%)",
                isDelta: true,
                deltaUp: true,
            },
        ],
        kwSummary: { improved: 11, declined: 3, unchanged: 8 },
        keywordRows: [
            {
                keyword: "sharepoint migration services",
                prevRank: "#10",
                currRank: "#7",
                change: 3,
                volume: "1,600",
                status: "Improved",
            },
            {
                keyword: "power platform consulting india",
                prevRank: "#15",
                currRank: "#12",
                change: 3,
                volume: "1,200",
                status: "Improved",
            },
            {
                keyword: "microsoft copilot studio partner",
                prevRank: "#20",
                currRank: "#16",
                change: 4,
                volume: "900",
                status: "Improved",
            },
            {
                keyword: "sharepoint intranet development",
                prevRank: "#10",
                currRank: "#11",
                change: -1,
                volume: "1,300",
                status: "Declined",
            },
            {
                keyword: "dynamics 365 implementation",
                prevRank: "#16",
                currRank: "#14",
                change: 2,
                volume: "800",
                status: "Improved",
            },
            {
                keyword: "salesforce crm migration",
                prevRank: "#19",
                currRank: "#16",
                change: 3,
                volume: "1,100",
                status: "Improved",
            },
        ],
    },
    {
        month: new Date(2026, 0, 1),
        keywordsTop10: 16,
        totalBacklinks: 1550,
        kwImproved: 12,
        seoLeads: 140,
        rankDist: { top10: 8, rank11_50: 26, rank51_100: 40, notRanked: 12 },
        backlinkMetrics: [
            { label: "New Backlinks Inserted", value: "35" },
            { label: "Referring Domains (Total)", value: "255" },
            { label: "Dofollow Links", value: "100" },
            { label: "Nofollow Links", value: "1,450" },
            { label: "Domain Authority (Moz)", value: "33" },
            {
                label: "Backlinks vs Prev Month",
                value: "▲ +35 (+2.5%)",
                isDelta: true,
                deltaUp: true,
            },
        ],
        kwSummary: { improved: 12, declined: 4, unchanged: 6 },
        keywordRows: [
            {
                keyword: "sharepoint migration services",
                prevRank: "#7",
                currRank: "#5",
                change: 2,
                volume: "1,600",
                status: "Improved",
            },
            {
                keyword: "power platform consulting india",
                prevRank: "#12",
                currRank: "#9",
                change: 3,
                volume: "1,200",
                status: "Improved",
            },
            {
                keyword: "microsoft copilot studio partner",
                prevRank: "#16",
                currRank: "#13",
                change: 3,
                volume: "900",
                status: "Improved",
            },
            {
                keyword: "sharepoint intranet development",
                prevRank: "#11",
                currRank: "#9",
                change: 2,
                volume: "1,300",
                status: "Improved",
            },
            {
                keyword: "dynamics 365 implementation",
                prevRank: "#14",
                currRank: "#13",
                change: 1,
                volume: "800",
                status: "Improved",
            },
            {
                keyword: "salesforce crm migration",
                prevRank: "#16",
                currRank: "#14",
                change: 2,
                volume: "1,100",
                status: "Improved",
            },
        ],
    },
    {
        month: new Date(2026, 1, 1),
        keywordsTop10: 19,
        totalBacklinks: 1750,
        kwImproved: 14,
        seoLeads: 165,
        rankDist: { top10: 11, rank11_50: 30, rank51_100: 28, notRanked: 9 },
        backlinkMetrics: [
            { label: "New Backlinks Inserted", value: "40" },
            { label: "Referring Domains (Total)", value: "305" },
            { label: "Dofollow Links", value: "110" },
            { label: "Nofollow Links", value: "1,640" },
            { label: "Domain Authority (Moz)", value: "34" },
            {
                label: "Backlinks vs Prev Month",
                value: "▲ +40 (+2.3%)",
                isDelta: true,
                deltaUp: true,
            },
        ],
        kwSummary: { improved: 14, declined: 3, unchanged: 5 },
        keywordRows: [
            {
                keyword: "sharepoint migration services",
                prevRank: "#5",
                currRank: "#3",
                change: 2,
                volume: "1,600",
                status: "Improved",
            },
            {
                keyword: "power platform consulting india",
                prevRank: "#9",
                currRank: "#7",
                change: 2,
                volume: "1,200",
                status: "Improved",
            },
            {
                keyword: "microsoft copilot studio partner",
                prevRank: "#13",
                currRank: "#9",
                change: 4,
                volume: "900",
                status: "Improved",
            },
            {
                keyword: "sharepoint intranet development",
                prevRank: "#9",
                currRank: "#11",
                change: -2,
                volume: "1,300",
                status: "Declined",
            },
            {
                keyword: "dynamics 365 implementation",
                prevRank: "#13",
                currRank: "#12",
                change: 1,
                volume: "800",
                status: "Improved",
            },
            {
                keyword: "salesforce crm migration",
                prevRank: "#14",
                currRank: "#14",
                change: 0,
                volume: "1,100",
                status: "Unchanged",
            },
        ],
    },
    {
        month: new Date(2026, 2, 1),
        keywordsTop10: 21,
        totalBacklinks: 1890,
        kwImproved: 16,
        seoLeads: 182,
        rankDist: { top10: 13, rank11_50: 32, rank51_100: 24, notRanked: 8 },
        backlinkMetrics: [
            { label: "New Backlinks Inserted", value: "45" },
            { label: "Referring Domains (Total)", value: "340" },
            { label: "Dofollow Links", value: "118" },
            { label: "Nofollow Links", value: "1,772" },
            { label: "Domain Authority (Moz)", value: "35" },
            {
                label: "Backlinks vs Prev Month",
                value: "▲ +45 (+2.6%)",
                isDelta: true,
                deltaUp: true,
            },
        ],
        kwSummary: { improved: 16, declined: 2, unchanged: 4 },
        keywordRows: [
            {
                keyword: "sharepoint migration services",
                prevRank: "#3",
                currRank: "#2",
                change: 1,
                volume: "1,600",
                status: "Improved",
            },
            {
                keyword: "power platform consulting india",
                prevRank: "#7",
                currRank: "#5",
                change: 2,
                volume: "1,200",
                status: "Improved",
            },
            {
                keyword: "microsoft copilot studio partner",
                prevRank: "#9",
                currRank: "#7",
                change: 2,
                volume: "900",
                status: "Improved",
            },
            {
                keyword: "sharepoint intranet development",
                prevRank: "#11",
                currRank: "#8",
                change: 3,
                volume: "1,300",
                status: "Improved",
            },
            {
                keyword: "dynamics 365 implementation",
                prevRank: "#12",
                currRank: "#10",
                change: 2,
                volume: "800",
                status: "Improved",
            },
            {
                keyword: "salesforce crm migration",
                prevRank: "#14",
                currRank: "#12",
                change: 2,
                volume: "1,100",
                status: "Improved",
            },
        ],
    },
];
function defaultRange() {
    var today = new Date();
    today.setHours(0, 0, 0, 0);
    return {
        startDate: new Date(today.getFullYear(), today.getMonth(), 1),
        endDate: today,
        label: "This Month",
    };
}
function filterSnapshots(range) {
    return ALL_SEO_DATA.filter(function (s) {
        var monthEnd = new Date(s.month.getFullYear(), s.month.getMonth() + 1, 0);
        return s.month <= range.endDate && monthEnd >= range.startDate;
    });
}
function aggregateSnapshots(snapshots) {
    if (snapshots.length === 0)
        return null;
    var last = snapshots[snapshots.length - 1];
    return {
        keywordsTop10: last.keywordsTop10,
        totalBacklinks: last.totalBacklinks,
        kwImproved: snapshots.reduce(function (s, x) { return s + x.kwImproved; }, 0),
        seoLeads: snapshots.reduce(function (s, x) { return s + x.seoLeads; }, 0),
        rankDist: last.rankDist,
        keywordRows: last.keywordRows,
        backlinkMetrics: last.backlinkMetrics,
        kwSummary: last.kwSummary,
        backlinkTrend: snapshots.map(function (s) { return ({
            label: s.month.toLocaleString("default", {
                month: "short",
                year: "2-digit",
            }),
            backlinks: s.totalBacklinks,
            domains: (function () {
                var m = s.backlinkMetrics.find(function (m) { return m.label === "Referring Domains (Total)"; });
                return m ? parseInt(m.value.replace(",", "")) : 0;
            })(),
        }); }),
        rankDistMonths: snapshots.map(function (s) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_4__.__assign)({ label: s.month.toLocaleString("default", {
                month: "short",
                year: "2-digit",
            }) }, s.rankDist)); }),
    };
}
var KpiCard = function (p) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpi },
    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiTop },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiIcon, style: { background: p.iconBg } }, p.icon),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "".concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiDelta, " ").concat(p.deltaType === "up" ? _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].deltaUp : p.deltaType === "dn" ? _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].deltaDn : _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].deltaFlat) }, p.deltaText)),
    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiLabel }, p.label),
    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiVal }, p.value),
    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiSub }, p.sub),
    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiAccent, style: { background: p.accentColor } }))); };
var RankDistChart = function (_a) {
    var data = _a.data;
    var chartData = {
        labels: data.map(function (d) { return d.label; }),
        datasets: [
            {
                label: "Top 1-10",
                data: data.map(function (d) { return d.top10; }),
                backgroundColor: "#059669",
            },
            {
                label: "11-50",
                data: data.map(function (d) { return d.rank11_50; }),
                backgroundColor: "#0891b2",
            },
            {
                label: "51-100",
                data: data.map(function (d) { return d.rank51_100; }),
                backgroundColor: "#d97706",
            },
            {
                label: "Not Ranked",
                data: data.map(function (d) { return d.notRanked; }),
                backgroundColor: "#e11d48",
            },
        ],
    };
    var options = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: "bottom",
            },
        },
        scales: {
            x: { stacked: true },
            y: { stacked: true },
        },
    };
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].chartWrapper }, data.length === 0 ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].emptyChart }, "\uD83D\uDCED No data")) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_chart__WEBPACK_IMPORTED_MODULE_5__.Chart, { type: "bar", data: chartData, options: options }))));
};
var BacklinkGrowthChart = function (_a) {
    var data = _a.data;
    var chartData = {
        labels: data.map(function (d) { return d.label; }),
        datasets: [
            {
                label: "Total Backlinks",
                data: data.map(function (d) { return d.backlinks; }),
                borderColor: "#1a6ef5",
                backgroundColor: "rgba(26,110,245,0.1)",
                tension: 0.4,
                fill: true,
            },
            {
                label: "Referring Domains",
                data: data.map(function (d) { return d.domains; }),
                borderColor: "#7c3aed",
                backgroundColor: "rgba(124,58,237,0.1)",
                tension: 0.4,
                fill: true,
            },
        ],
    };
    var options = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: "bottom",
            },
        },
    };
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].chartWrapper }, data.length === 0 ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].emptyChart }, "\uD83D\uDCED No data")) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_chart__WEBPACK_IMPORTED_MODULE_5__.Chart, { type: "line", data: chartData, options: options }))));
};
var SeoIntelligenceDashboard = function () {
    var _a = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(defaultRange()), dateRange = _a[0], setDateRange = _a[1];
    var _b = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(null), aggregated = _b[0], setAggregated = _b[1];
    var _c = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false), loading = _c[0], setLoading = _c[1];
    var _d = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(""), rangeLabel = _d[0], setRangeLabel = _d[1];
    var _e = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]), keywordData = _e[0], setKeywordData = _e[1];
    var _f = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]), topPageData = _f[0], setTopPageData = _f[1];
    var _g = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]), backlinkData = _g[0], setBacklinkData = _g[1];
    var fetchAllSEOData = function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(void 0, void 0, void 0, function () {
        var _a, keywordRes, topPageRes, backlinkRes, keywordFormatted, topPageFormatted, backlinkFormatted, error_1;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__generator)(this, function (_b) {
            switch (_b.label) {
                case 0:
                    _b.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, Promise.all([
                            // 1️⃣ Keywords List
                            _pnp_sp__WEBPACK_IMPORTED_MODULE_3__.sp.web.lists
                                .getByTitle("Keywords")
                                .items
                                .select("ID", "Keyword", "Clicks", "Impressions", "CTR", "AvgPosition", "Status", "Date")
                                .orderBy("Date", false)
                                .getAll(),
                            // 2️⃣ Top Page List
                            _pnp_sp__WEBPACK_IMPORTED_MODULE_3__.sp.web.lists
                                .getByTitle("TopPage")
                                .items
                                .select("ID", "PageURL", "Clicks", "Impressions", "CTR", "AvgPosition", "Date")
                                .orderBy("Date", false)
                                .getAll(),
                            // 3️⃣ Backlink Summary List
                            _pnp_sp__WEBPACK_IMPORTED_MODULE_3__.sp.web.lists
                                .getByTitle("BacklinkSummary")
                                .items
                                .select("ID", "Metric", "Value", "Notes", "Date")
                                .orderBy("Date", false)
                                .getAll()
                        ])];
                case 1:
                    _a = _b.sent(), keywordRes = _a[0], topPageRes = _a[1], backlinkRes = _a[2];
                    keywordFormatted = keywordRes.map(function (item) { return ({
                        ID: item.ID,
                        Keyword: item.Keyword,
                        Clicks: Number(item.Clicks || 0),
                        Impressions: Number(item.Impressions || 0),
                        CTR: Number(item.CTR || 0),
                        AvgPosition: Number(item.AvgPosition || 0),
                        Status: item.Status,
                        Date: item.Date || null,
                    }); });
                    topPageFormatted = topPageRes.map(function (item) { return ({
                        ID: item.ID,
                        PageURL: item.PageURL,
                        Clicks: Number(item.Clicks || 0),
                        Impressions: Number(item.Impressions || 0),
                        CTR: Number(item.CTR || 0),
                        AvgPosition: Number(item.AvgPosition || 0),
                        Date: item.Date || null,
                    }); });
                    backlinkFormatted = backlinkRes.map(function (item) { return ({
                        ID: item.ID,
                        Metric: item.Metric,
                        Value: Number(item.Value || 0),
                        Notes: item.Notes,
                        Date: item.Date || null,
                    }); });
                    // 🔥 SET STATE
                    setKeywordData(keywordFormatted);
                    setTopPageData(topPageFormatted);
                    setBacklinkData(backlinkFormatted);
                    return [3 /*break*/, 3];
                case 2:
                    error_1 = _b.sent();
                    console.error("Error fetching SEO data:", error_1);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function () {
        setLoading(true);
        var timer = setTimeout(function () {
            var snapshots = filterSnapshots(dateRange);
            var agg = aggregateSnapshots(snapshots);
            setAggregated(agg);
            setRangeLabel("".concat(snapshots.length, " month").concat(snapshots.length !== 1 ? "s" : "", " \u00B7 ").concat(dateRange.label));
            setLoading(false);
        }, 250);
        return function () { return clearTimeout(timer); };
    }, [dateRange]);
    var noData = !aggregated;
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].seoDashboard },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].topHeader },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].topTitle }, "SEO Intelligence"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].topSub }, "GSC + Excel \u00B7 Keyword & backlink data")),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].topRight },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].secActions },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(_DatePicker_DatePicker__WEBPACK_IMPORTED_MODULE_2__["default"], { value: dateRange, onChange: setDateRange, maxDate: new Date() }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "".concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].sourceBadge, " ").concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].badgeBlue) }, "\uD83D\uDD17 GSC Connected"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].topBtnPrimary }, "Refresh")))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].secHeader },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].secTitleWrap },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].secIcon, style: { background: "#fef3c7" } }, "\uD83D\uDD0D"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].secTitle }, "SEO Performance"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].secSub },
                        "Google Search Console \u00B7 ",
                        rangeLabel))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "".concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].sourceBadge, " ").concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].badgeGreen) }, "\uD83D\uDCCA Excel")),
        loading && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].loadingBar },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].loadingFill }))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].g4 },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(KpiCard, { icon: "\uD83D\uDCC8", iconBg: "#d1fae5", accentColor: "#059669", deltaText: noData ? "—" : "\u25B2 ".concat(aggregated.keywordsTop10, " keywords"), deltaType: noData ? "flat" : "up", label: "Keywords Top-10", value: noData ? "—" : String(aggregated.keywordsTop10), sub: "Ranking page 1" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(KpiCard, { icon: "\uD83D\uDD17", iconBg: "#e8f0fe", accentColor: "#1a6ef5", deltaText: noData
                    ? "—"
                    : "\u25B2 Latest ".concat(aggregated.totalBacklinks.toLocaleString()), deltaType: noData ? "flat" : "up", label: "Total Backlinks", value: noData ? "—" : aggregated.totalBacklinks.toLocaleString(), sub: "Acquired in range" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(KpiCard, { icon: "\u2B06\uFE0F", iconBg: "#fef3c7", accentColor: "#d97706", deltaText: noData ? "—" : "\u25B2 ".concat(aggregated.kwImproved, " improved"), deltaType: noData ? "flat" : "up", label: "Kw Rank Improved", value: noData ? "—" : String(aggregated.kwImproved), sub: "vs previous period" }),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(KpiCard, { icon: "\uD83C\uDFAF", iconBg: "#e0f5fa", accentColor: "#0891b2", deltaText: noData ? "—" : "\u25B2 ".concat(aggregated.seoLeads, " leads"), deltaType: noData ? "flat" : "up", label: "SEO Leads", value: noData ? "—" : aggregated.seoLeads.toLocaleString(), sub: "Organic conversions" })),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "".concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].g2, " ").concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].mt) },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].card },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardHead },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardTitle }, "Keyword Rank Distribution"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardSub },
                            "How keywords are spread across positions \u00B7 ",
                            dateRange.label))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(RankDistChart, { data: noData ? [] : aggregated.rankDistMonths })),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].card },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardHead },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardTitle }, "Backlink Growth"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardSub },
                            "Total backlinks vs referring domains \u00B7 ",
                            dateRange.label))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(BacklinkGrowthChart, { data: noData ? [] : aggregated.backlinkTrend }))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "".concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].g2, " ").concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].mt) },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].card },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardHead },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardTitle }, "Keyword Rankings Detail"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardSub },
                            "Top commercial-intent keywords \u00B7 ",
                            dateRange.label))),
                noData ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].emptyState }, "\uD83D\uDCED No data found for selected date range.")) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement("table", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].tbl },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("thead", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", null, "Keyword"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", null, "Prev Rank"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", null, "Curr Rank"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", null, "Change"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", null, "Volume"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", null, "Status"))),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("tbody", null, aggregated.keywordRows.map(function (row, idx) {
                        var isUp = row.change > 0;
                        var statusClass = row.status === "Improved"
                            ? _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].pillGreen
                            : row.status === "Declined"
                                ? _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].pillRose
                                : _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].pillGray;
                        return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", { key: idx },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null,
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("strong", null, row.keyword)),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, row.prevRank),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null,
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("strong", null, row.currRank)),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null,
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "".concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].delta, " ").concat(isUp ? _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].deltaUp : row.change < 0 ? _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].deltaDn : _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].deltaFlat) }, isUp
                                    ? "\u25B2+".concat(row.change)
                                    : row.change < 0
                                        ? "\u25BC".concat(row.change)
                                        : "—")),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, row.volume),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null,
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "".concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].pill, " ").concat(statusClass) }, row.status))));
                    }))))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].card },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardHead },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardTitle }, "Backlinks \u2014 Selected Period"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardSub },
                            "Quality & growth metrics \u00B7 ",
                            dateRange.label))),
                noData ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].emptyState }, "\uD83D\uDCED No data found for selected date range.")) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
                    aggregated.backlinkMetrics.map(function (m, i) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].miniM, key: i },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].miniLabel }, m.label),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "".concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].miniVal, " ").concat(m.isDelta ? (m.deltaUp ? _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].deltaUp : _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].deltaDn) : "") }, m.value))); }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].divider }),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardHead, style: { marginBottom: 8 } },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardTitle }, "Keywords Improved vs Declined")),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kwSummaryRow },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "".concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kwSummaryBox, " ").concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kwSummaryGreen) },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kwSummaryNum, style: { color: "#059669" } }, aggregated.kwSummary.improved),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kwSummaryLbl, style: { color: "#059669" } }, "Keywords \u25B2 Improved")),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "".concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kwSummaryBox, " ").concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kwSummaryRose) },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kwSummaryNum, style: { color: "#e11d48" } }, aggregated.kwSummary.declined),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kwSummaryLbl, style: { color: "#e11d48" } }, "Keywords \u25BC Declined")),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "".concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kwSummaryBox, " ").concat(_SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kwSummaryGray) },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kwSummaryNum, style: { color: "#4a5a7a" } }, aggregated.kwSummary.unchanged),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _SEOIntelligence_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kwSummaryLbl, style: { color: "#8a9bbf" } }, "Unchanged")))))))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SeoIntelligenceDashboard);


/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("bcd05955e2891d6cbe9a")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=marketing-analytics-web-part.3bd1ca313bdb0816c0ce.hot-update.js.map