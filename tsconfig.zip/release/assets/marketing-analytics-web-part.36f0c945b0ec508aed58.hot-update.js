"use strict";
self["webpackHotUpdated4faa06d_862f_4712_a355_4e54547f85f3_0_0_1"]("marketing-analytics-web-part",{

/***/ 5204:
/*!***********************************************************************!*\
  !*** ./lib/webparts/marketingAnalytics/components/PaidAds/PaidAds.js ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PaidAdsPerformance: () => (/* binding */ PaidAdsPerformance),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 196);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 5959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var primereact_chart__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! primereact/chart */ 4964);
/* harmony import */ var _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./PaidAds.module.scss */ 3504);
/* harmony import */ var _pnp_sp__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @pnp/sp */ 2011);






// ─── Data ─────────────────────────────────────────────────────────────────────
var ALL_CAMPAIGNS = [
    // October
    { platform: 'Google', campaignName: 'SharePoint Migration — Search', date: new Date(2025, 9, 5), spend: 9000, impressions: 24000, clicks: 840, ctr: '3.5%', ctrType: 'good', leads: 42, cpl: 214, status: 'Active' },
    { platform: 'LinkedIn', campaignName: 'B2B Lead Gen — Power Platform', date: new Date(2025, 9, 8), spend: 7000, impressions: 16000, clicks: 350, ctr: '2.2%', ctrType: 'mid', leads: 17, cpl: 412, status: 'Active' },
    { platform: 'Facebook', campaignName: 'Brand Awareness — Enterprise', date: new Date(2025, 9, 10), spend: 3500, impressions: 170000, clicks: 610, ctr: '0.36%', ctrType: 'low', leads: null, cpl: null, status: 'Paused' },
    // November
    { platform: 'Google', campaignName: 'SharePoint Migration — Search', date: new Date(2025, 10, 4), spend: 9500, impressions: 25000, clicks: 875, ctr: '3.5%', ctrType: 'good', leads: 44, cpl: 216, status: 'Active' },
    { platform: 'LinkedIn', campaignName: 'B2B Lead Gen — Power Platform', date: new Date(2025, 10, 7), spend: 7500, impressions: 17000, clicks: 374, ctr: '2.2%', ctrType: 'mid', leads: 18, cpl: 417, status: 'Active' },
    { platform: 'Facebook', campaignName: 'Brand Awareness — Enterprise', date: new Date(2025, 10, 9), spend: 3500, impressions: 172000, clicks: 620, ctr: '0.36%', ctrType: 'low', leads: null, cpl: null, status: 'Paused' },
    // December
    { platform: 'Google', campaignName: 'SharePoint Migration — Search', date: new Date(2025, 11, 3), spend: 9800, impressions: 26000, clicks: 910, ctr: '3.5%', ctrType: 'good', leads: 46, cpl: 213, status: 'Active' },
    { platform: 'LinkedIn', campaignName: 'B2B Lead Gen — Power Platform', date: new Date(2025, 11, 6), spend: 7800, impressions: 17500, clicks: 385, ctr: '2.2%', ctrType: 'mid', leads: 19, cpl: 411, status: 'Active' },
    { platform: 'Facebook', campaignName: 'Brand Awareness — Enterprise', date: new Date(2025, 11, 8), spend: 3500, impressions: 173000, clicks: 622, ctr: '0.36%', ctrType: 'low', leads: null, cpl: null, status: 'Paused' },
    // January
    { platform: 'Google', campaignName: 'SharePoint Migration — Search', date: new Date(2026, 0, 6), spend: 8200, impressions: 22000, clicks: 770, ctr: '3.5%', ctrType: 'good', leads: 38, cpl: 216, status: 'Active' },
    { platform: 'LinkedIn', campaignName: 'B2B Lead Gen — Power Platform', date: new Date(2026, 0, 9), spend: 7200, impressions: 16500, clicks: 363, ctr: '2.2%', ctrType: 'mid', leads: 18, cpl: 400, status: 'Active' },
    { platform: 'Facebook', campaignName: 'Brand Awareness — Enterprise', date: new Date(2026, 0, 11), spend: 3600, impressions: 175000, clicks: 630, ctr: '0.36%', ctrType: 'low', leads: null, cpl: null, status: 'Paused' },
    // February
    { platform: 'Google', campaignName: 'SharePoint Migration — Search', date: new Date(2026, 1, 3), spend: 9200, impressions: 24000, clicks: 840, ctr: '3.5%', ctrType: 'good', leads: 43, cpl: 214, status: 'Active' },
    { platform: 'LinkedIn', campaignName: 'B2B Lead Gen — Power Platform', date: new Date(2026, 1, 6), spend: 7900, impressions: 17800, clicks: 392, ctr: '2.2%', ctrType: 'mid', leads: 20, cpl: 395, status: 'Active' },
    { platform: 'Facebook', campaignName: 'Brand Awareness — Enterprise', date: new Date(2026, 1, 8), spend: 3700, impressions: 178000, clicks: 641, ctr: '0.36%', ctrType: 'low', leads: null, cpl: null, status: 'Paused' },
    // March
    { platform: 'Google', campaignName: 'SharePoint Migration — Search', date: new Date(2026, 2, 3), spend: 8100, impressions: 21500, clicks: 752, ctr: '3.5%', ctrType: 'good', leads: 37, cpl: 219, status: 'Active' },
    { platform: 'LinkedIn', campaignName: 'B2B Lead Gen — Power Platform', date: new Date(2026, 2, 5), spend: 7600, impressions: 16800, clicks: 370, ctr: '2.2%', ctrType: 'mid', leads: 19, cpl: 400, status: 'Active' },
    { platform: 'Facebook', campaignName: 'Brand Awareness — Enterprise', date: new Date(2026, 2, 7), spend: 3700, impressions: 179000, clicks: 644, ctr: '0.36%', ctrType: 'low', leads: null, cpl: null, status: 'Paused' },
];
var PLATFORM_META = {
    Google: { color: '#e11d48', icon: '🔍', pillColor: 'blue' },
    LinkedIn: { color: '#1a6ef5', icon: '💼', pillColor: 'indigo' },
    Facebook: { color: '#7c3aed', icon: '📘', pillColor: 'violet' },
};
var PLATFORMS = ['Google', 'LinkedIn', 'Facebook'];
// Monthly CPL data for trend line chart (Oct–Mar)
var CPL_MONTHS = ['Oct', 'Nov', 'Dec', 'Jan', 'Feb', 'Mar'];
var GOOGLE_CPL_BY_MONTH = [214, 216, 213, 216, 214, 219];
var LINKEDIN_CPL_BY_MONTH = [412, 417, 411, 400, 395, 400];
// ─── Helpers ──────────────────────────────────────────────────────────────────
function fmt(n) {
    if (n >= 1000000)
        return (n / 1000000).toFixed(1).replace(/\.0$/, '') + 'M';
    if (n >= 1000)
        return (n / 1000).toFixed(1).replace(/\.0$/, '') + 'K';
    return n.toLocaleString('en-IN');
}
function defaultRange() {
    var today = new Date();
    today.setHours(0, 0, 0, 0);
    return {
        startDate: new Date(today.getFullYear(), today.getMonth(), 1),
        endDate: today,
        label: 'This Month',
    };
}
function formatDateLabel(d) {
    return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
}
// ─── Pill ─────────────────────────────────────────────────────────────────────
var Pill = function (_a) {
    var children = _a.children, color = _a.color;
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "".concat(_PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].pill, " ").concat(_PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]["pill--".concat(color)]) }, children));
};
var KpiCard = function (_a) {
    var icon = _a.icon, label = _a.label, value = _a.value, sub = _a.sub, delta = _a.delta, deltaUp = _a.deltaUp, accentColor = _a.accentColor, iconBg = _a.iconBg;
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiCard },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiCard__top },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiCard__icon, style: { background: iconBg } }, icon),
            delta === null
                ? react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiCard__menu }, "\u2014")
                : (react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "".concat(_PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiCard__delta, " ").concat(deltaUp ? _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]['kpiCard__delta--up'] : _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]['kpiCard__delta--flat']) }, delta))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiCard__label }, label),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiCard__value }, value),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiCard__sub }, sub),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiCard__bar, style: { background: accentColor } })));
};
// ─── Main Component ───────────────────────────────────────────────────────────
var PaidAdsPerformance = function () {
    var _a = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(defaultRange), dateRange = _a[0], setDateRange = _a[1];
    var _b = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false), mounted = _b[0], setMounted = _b[1];
    var _c = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]), googleAdsData = _c[0], setGoogleAdsData = _c[1];
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function () { return setMounted(true); }, []);
    // ── Filtered rows ──
    var filtered = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () { return ALL_CAMPAIGNS.filter(function (c) { return c.date >= dateRange.startDate && c.date <= dateRange.endDate; }); }, [dateRange]);
    // ── KPI totals ──
    var kpis = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
        var totalSpend = filtered.reduce(function (s, c) { return s + c.spend; }, 0);
        var totalImpressions = filtered.reduce(function (s, c) { return s + c.impressions; }, 0);
        var totalLeads = filtered.reduce(function (s, c) { var _a; return s + ((_a = c.leads) !== null && _a !== void 0 ? _a : 0); }, 0);
        var avgCpl = totalLeads > 0 ? Math.round(totalSpend / totalLeads) : 0;
        return { totalSpend: totalSpend, totalImpressions: totalImpressions, totalLeads: totalLeads, avgCpl: avgCpl };
    }, [filtered]);
    // ── Per-platform aggregates ──
    var platformStats = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
        var agg = function (p) { return ({
            spend: filtered.filter(function (c) { return c.platform === p; }).reduce(function (s, c) { return s + c.spend; }, 0),
            leads: filtered.filter(function (c) { return c.platform === p; }).reduce(function (s, c) { var _a; return s + ((_a = c.leads) !== null && _a !== void 0 ? _a : 0); }, 0),
        }); };
        return {
            Google: agg('Google'),
            LinkedIn: agg('LinkedIn'),
            Facebook: agg('Facebook'),
        };
    }, [filtered]);
    // ── Deduplicated campaign table rows ──
    var campaignTable = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
        var map = new Map();
        filtered.forEach(function (c) {
            var _a, _b;
            var key = "".concat(c.platform, "__").concat(c.campaignName);
            if (!map.has(key)) {
                map.set(key, (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_3__.__assign)({}, c), { _spend: c.spend, _impressions: c.impressions, _clicks: c.clicks, _leads: (_a = c.leads) !== null && _a !== void 0 ? _a : 0 }));
            }
            else {
                var ex = map.get(key);
                ex._spend += c.spend;
                ex._impressions += c.impressions;
                ex._clicks += c.clicks;
                ex._leads += (_b = c.leads) !== null && _b !== void 0 ? _b : 0;
            }
        });
        return Array.from(map.values());
    }, [filtered]);
    // ─────────────────────────────────────────────────────────────────────────────
    // PrimeReact Chart 1: Grouped Bar — Spend vs Leads by Platform
    // ─────────────────────────────────────────────────────────────────────────────
    var fetchDeviceSessionMetrics = function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(void 0, void 0, void 0, function () {
        var response, error_1;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, _pnp_sp__WEBPACK_IMPORTED_MODULE_2__.sp.web.lists
                            .getByTitle("GoogleAds")
                            .items
                            .select("Id", "Date", "CampaignName", "impressions", "clicks", "spend", "ctr")
                            .orderBy("Date", false)
                            .getAll()];
                case 1:
                    response = _a.sent();
                    console.log(response, "GoogleAds");
                    setGoogleAdsData(response);
                    return [3 /*break*/, 3];
                case 2:
                    error_1 = _a.sent();
                    console.error("Error fetching device metrics:", error_1);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function () { return void fetchDeviceSessionMetrics(); }, []);
    var spendLeadsData = {
        labels: ['Google Ads', 'LinkedIn Ads', 'Facebook Ads'],
        datasets: [
            {
                label: 'Ad Spend (₹)',
                backgroundColor: ['#e11d48', '#2563eb', '#7c3aed'],
                borderRadius: 8,
                barPercentage: 0.5,
                categoryPercentage: 0.5,
                data: [45000, 38000, 18000],
                yAxisID: 'y',
            },
            {
                label: 'Leads',
                backgroundColor: '#6ee7b7',
                borderRadius: 8,
                barPercentage: 0.5,
                categoryPercentage: 0.5,
                data: [200, 120, 0],
                yAxisID: 'y1',
            },
        ],
    };
    var spendLeadsOptions = {
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'top',
                labels: {
                    usePointStyle: true,
                    pointStyle: 'rect',
                    padding: 20,
                    color: '#64748b',
                    font: {
                        size: 12,
                        weight: 500,
                    },
                },
            },
        },
        scales: {
            x: {
                grid: {
                    display: false,
                },
                ticks: {
                    color: '#64748b',
                    font: {
                        size: 12,
                    },
                },
            },
            y: {
                position: 'left',
                beginAtZero: true,
                grid: {
                    color: '#e2e8f0',
                },
                ticks: {
                    callback: function (value) { return "\u20B9".concat(value / 1000, "K"); },
                    color: '#64748b',
                },
            },
            y1: {
                position: 'right',
                beginAtZero: true,
                grid: {
                    drawOnChartArea: false,
                },
                ticks: {
                    color: '#64748b',
                },
            },
        },
    };
    // ─────────────────────────────────────────────────────────────────────────────
    // PrimeReact Chart 2: Line — CPL Trend Monthly (Oct → Mar)
    // ─────────────────────────────────────────────────────────────────────────────
    var cplTrendData = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () { return ({
        labels: CPL_MONTHS,
        datasets: [
            {
                label: 'Google CPL (₹)',
                data: GOOGLE_CPL_BY_MONTH,
                borderColor: '#e11d48',
                backgroundColor: 'rgba(225,29,72,0.07)',
                fill: true,
                tension: 0.3,
                borderWidth: 2,
                pointRadius: 4,
                pointBackgroundColor: '#ffffff',
                pointBorderColor: '#e11d48',
                pointBorderWidth: 2,
                pointHoverRadius: 6,
            },
            {
                label: 'LinkedIn CPL (₹)',
                data: LINKEDIN_CPL_BY_MONTH,
                borderColor: '#1a6ef5',
                backgroundColor: 'rgba(26,110,245,0.0)',
                fill: false,
                tension: 0.3,
                borderWidth: 2,
                pointRadius: 4,
                pointBackgroundColor: '#ffffff',
                pointBorderColor: '#1a6ef5',
                pointBorderWidth: 2,
                pointHoverRadius: 6,
            },
        ],
    }); }, []);
    var cplTrendOptions = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () { return ({
        responsive: true,
        maintainAspectRatio: false,
        interaction: { mode: 'index', intersect: false },
        plugins: {
            legend: {
                position: 'top',
                labels: {
                    usePointStyle: true,
                    pointStyle: 'rectRounded',
                    font: { size: 11 },
                    color: '#64748b',
                    padding: 16,
                },
            },
            tooltip: {
                backgroundColor: '#ffffff',
                borderColor: '#e2e8f0',
                borderWidth: 1,
                titleColor: '#0f172a',
                bodyColor: '#374151',
                padding: 10,
                callbacks: {
                    label: function (ctx) { return "  \u20B9".concat(ctx.parsed.y); },
                },
            },
        },
        scales: {
            x: {
                grid: { display: false },
                ticks: { color: '#94a3b8', font: { size: 11 } },
                border: { display: false },
            },
            y: {
                min: 150,
                grid: { color: '#f1f5f9' },
                border: { display: false },
                ticks: {
                    color: '#94a3b8',
                    font: { size: 10 },
                    callback: function (v) { return "\u20B9".concat(v); },
                },
            },
        },
    }); }, []);
    // ─────────────────────────────────────────────────────────────────────────────
    // KPI cards config
    // ─────────────────────────────────────────────────────────────────────────────
    var KPI_CARDS = [
        {
            icon: '💸',
            label: 'Total Ad Spend',
            value: "\u20B9".concat(fmt(kpis.totalSpend)),
            sub: 'All platforms combined',
            delta: null,
            deltaUp: false,
            accentColor: '#e11d48',
            iconBg: '#fff0f3',
        },
        {
            icon: '👁',
            label: 'Total Impressions',
            value: fmt(kpis.totalImpressions),
            sub: 'All campaigns',
            delta: '▲ 14%',
            deltaUp: true,
            accentColor: '#1a6ef5',
            iconBg: '#e8f0fe',
        },
        {
            icon: '🎯',
            label: 'Leads from Ads',
            value: String(kpis.totalLeads),
            sub: 'Google + LinkedIn + FB',
            delta: '▲ 18%',
            deltaUp: true,
            accentColor: '#059669',
            iconBg: '#d1fae5',
        },
        {
            icon: '📉',
            label: 'Avg Cost Per Lead',
            value: kpis.avgCpl > 0 ? "\u20B9".concat(kpis.avgCpl) : '—',
            sub: 'Blended across platforms',
            delta: '▼ improving',
            deltaUp: true,
            accentColor: '#d97706',
            iconBg: '#fef3c7',
        },
    ];
    // ─────────────────────────────────────────────────────────────────────────────
    var dateLabel = "".concat(formatDateLabel(dateRange.startDate), " \u2013 ").concat(formatDateLabel(dateRange.endDate));
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "".concat(_PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].paidAds, " ").concat(mounted ? _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]['paidAds--mounted'] : '') },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].topBar },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].topBar__left },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].topBar__title }, "Paid Ads Performance"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].topBar__sep }, "\u00B7"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].topBar__subs }, "Google \u00B7 LinkedIn \u00B7 Facebook \u00B7 Excel data")),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].topBar__right },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].datePill },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "\uD83D\uDCC5"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].datePill__label }, dateRange.label),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].datePill__range }, dateLabel)),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].datePill__chevron }, "\u25BC")),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].btnConnect }, "\uD83D\uDD17 Connect Sources"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].btnRefresh }, "\u21BA Refresh"))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].innerHeader },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].innerHeader__left },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].innerHeader__icon }, "\uD83D\uDCB0"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].innerHeader__title }, "Paid Ads Performance"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].innerHeader__sub }, "Google Ads \u00B7 LinkedIn Ads \u00B7 Facebook Ads \u00B7 Data from Excel"))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].btnExcel }, "\uD83D\uDCCA Excel Data")),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("section", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiStrip }, KPI_CARDS.map(function (c, i) { return react__WEBPACK_IMPORTED_MODULE_0__.createElement(KpiCard, (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__assign)({ key: i }, c)); })),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("section", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].chartsRow },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].chartCard },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].chartCard__title }, "Spend vs Leads by Platform"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].chartCard__sub }, dateRange.label),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].chartCard__canvas }, filtered.length > 0 ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_chart__WEBPACK_IMPORTED_MODULE_4__.Chart, { type: "bar", data: spendLeadsData, options: spendLeadsOptions, style: { height: '220px' } })) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].chartCard__empty }, "No data for selected range")))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].chartCard },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].chartCard__title }, "CPL Trend \u2014 Monthly"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].chartCard__sub }, "Cost Per Lead improving over time"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].chartCard__canvas },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_chart__WEBPACK_IMPORTED_MODULE_4__.Chart, { type: "line", data: cplTrendData, options: cplTrendOptions, style: { height: '220px' } })))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("section", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].campaignTable },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].campaignTable__header },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].campaignTable__title }, "Campaign-Level Breakdown"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].campaignTable__sub }, "All active campaigns \u00B7 upload Excel to update"))),
                campaignTable.length === 0 ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].campaignTable__empty }, "\uD83D\uDCED No campaigns found for the selected date range.")) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].campaignTable__scroll },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("table", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].tbl },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("thead", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", null, [
                                'Platform', 'Campaign Name', 'Spend (₹)',
                                'Impressions', 'Clicks', 'CTR',
                                'Leads', 'CPL (₹)', 'Status',
                            ].map(function (h) { return react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", { key: h }, h); }))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("tbody", null, campaignTable.map(function (r, i) {
                            var cpl = r._leads > 0
                                ? Math.round(r._spend / r._leads)
                                : null;
                            var row = r;
                            return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", { key: i },
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null,
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(Pill, { color: PLATFORM_META[r.platform].pillColor }, r.platform)),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]['cell--name'] }, r.campaignName),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]['cell--num'] },
                                    "\u20B9",
                                    fmt(row._spend)),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]['cell--num'] }, fmt(row._impressions)),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]['cell--num'] }, fmt(row._clicks)),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null,
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(Pill, { color: r.ctrType === 'good' ? 'teal'
                                            : r.ctrType === 'mid' ? 'amber'
                                                : 'gray' }, r.ctr)),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]['cell--leads'] }, row._leads > 0 ? row._leads : react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]['cell--muted'] }, "\u2014")),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, cpl ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(Pill, { color: cpl < 300 ? 'green' : cpl < 450 ? 'amber' : 'gray' },
                                    "\u20B9",
                                    cpl)) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]['cell--muted'] }, "\u2014"))),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null,
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement(Pill, { color: r.status === 'Active' ? 'green'
                                            : r.status === 'Paused' ? 'amber'
                                                : 'gray' }, r.status))));
                        }))))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _PaidAds_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].uploadFooter },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "\uD83D\uDCCE"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "Upload ads Excel to add/update campaigns \u00B7 Fields: Platform \u00B7 Campaign \u00B7 Spend \u00B7 Impressions \u00B7 Clicks \u00B7 Leads"))))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PaidAdsPerformance);


/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("6e007eaed022a90570aa")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=marketing-analytics-web-part.36f0c945b0ec508aed58.hot-update.js.map