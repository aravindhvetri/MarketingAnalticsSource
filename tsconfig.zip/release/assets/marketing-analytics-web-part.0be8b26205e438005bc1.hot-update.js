"use strict";
self["webpackHotUpdated4faa06d_862f_4712_a355_4e54547f85f3_0_0_1"]("marketing-analytics-web-part",{

/***/ 8944:
/*!*************************************************************************************!*\
  !*** ./lib/webparts/marketingAnalytics/components/EmailCampaigns/EmailCampaigns.js ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 196);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 5959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./EmailCampaigns.module.scss */ 2612);
/* harmony import */ var _DatePicker_DatePicker__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../DatePicker/DatePicker */ 8938);
/* harmony import */ var primereact_chart__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! primereact/chart */ 4964);
/* harmony import */ var _pnp_sp__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @pnp/sp */ 2011);







/* ---------------- HELPERS ---------------- */
var pct = function (n, d) {
    return d === 0 ? "0%" : "".concat(((n / d) * 100).toFixed(1), "%");
};
var fmt = function (n) {
    return n >= 1000 ? (n / 1000).toFixed(1) + "K" : n.toString();
};
function defaultRange() {
    var today = new Date();
    return {
        startDate: new Date(today.getFullYear(), today.getMonth(), 1),
        endDate: today,
        label: "This Month",
    };
}
/* ---------------- MAIN ---------------- */
var EmailCampaignsDashboard = function () {
    var _a = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(defaultRange()), dateRange = _a[0], setDateRange = _a[1];
    var _b = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]), campaignData = _b[0], setCampaignData = _b[1];
    var fetchCampaignData = function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(void 0, void 0, void 0, function () {
        var response, formattedData, err_1;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, _pnp_sp__WEBPACK_IMPORTED_MODULE_3__.sp.web.lists
                            .getByTitle("WebsiteAnalyticsEmailCampaign")
                            .items.select("ID", "CampaignName", "CampaignId", "ReportDate", "Date", "Sent", "Opened", "Clicked", "Bounced", "UnSubscribed", "Leads", "OpenRate", "CTR")
                            .orderBy("Date", false)
                            .getAll()];
                case 1:
                    response = _a.sent();
                    formattedData = response.map(function (item) {
                        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m;
                        return ({
                            ID: item.ID,
                            CampaignName: (_a = item.CampaignName) !== null && _a !== void 0 ? _a : "",
                            CampaignId: (_b = item.CampaignId) !== null && _b !== void 0 ? _b : "",
                            ReportDate: (_c = item.ReportDate) !== null && _c !== void 0 ? _c : null,
                            Date: (_d = item.Date) !== null && _d !== void 0 ? _d : null,
                            Sent: Number((_e = item.Sent) !== null && _e !== void 0 ? _e : 0),
                            Opened: Number((_f = item.Opened) !== null && _f !== void 0 ? _f : 0),
                            Clicked: Number((_g = item.Clicked) !== null && _g !== void 0 ? _g : 0),
                            Bounced: Number((_h = item.Bounced) !== null && _h !== void 0 ? _h : 0),
                            UnSubscribed: Number((_j = item.UnSubscribed) !== null && _j !== void 0 ? _j : 0),
                            Leads: Number((_k = item.Leads) !== null && _k !== void 0 ? _k : 0),
                            OpenRate: Number((_l = item.OpenRate) !== null && _l !== void 0 ? _l : 0),
                            CTR: Number((_m = item.CTR) !== null && _m !== void 0 ? _m : 0),
                        });
                    });
                    setCampaignData(formattedData);
                    return [3 /*break*/, 3];
                case 2:
                    err_1 = _a.sent();
                    console.error("Error fetching campaign data:", err_1);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var filtered = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
        return campaignData
            .map(function (item) { return ({
            id: item.ID,
            name: item.CampaignName,
            date: item.Date ? new Date(item.Date) : new Date(),
            sent: item.Sent,
            opened: item.Opened,
            clicked: item.Clicked,
            bounced: item.Bounced,
            unsubscribed: item.UnSubscribed,
            leads: item.Leads,
        }); })
            .filter(function (c) {
            return c.date >= dateRange.startDate &&
                c.date <= dateRange.endDate;
        });
    }, [campaignData, dateRange]);
    var totals = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
        return {
            sent: filtered.reduce(function (a, b) { return a + b.sent; }, 0),
            opened: filtered.reduce(function (a, b) { return a + b.opened; }, 0),
            clicked: filtered.reduce(function (a, b) { return a + b.clicked; }, 0),
            leads: filtered.reduce(function (a, b) { return a + b.leads; }, 0),
        };
    }, [filtered]);
    var openRate = pct(totals.opened, totals.sent);
    var ctr = pct(totals.clicked, totals.sent);
    var chartOptions = {
        responsive: true,
        maintainAspectRatio: false,
        layout: {
            padding: {
                top: 10,
                right: 10,
                bottom: 0,
                left: 0,
            },
        },
        plugins: {
            legend: {
                display: true,
                position: "top",
                align: "center",
                labels: {
                    color: "#64748b",
                    font: {
                        size: 11,
                        weight: "500",
                    },
                    usePointStyle: true,
                    pointStyle: "rect",
                    boxWidth: 8,
                    padding: 16,
                },
            },
        },
        scales: {
            x: {
                grid: {
                    display: false,
                },
                ticks: {
                    color: "#94a3b8",
                    font: { size: 10 },
                },
            },
            y: {
                beginAtZero: true,
                grid: {
                    color: "#eef2f7",
                    drawBorder: false,
                },
                ticks: {
                    color: "#94a3b8",
                    font: { size: 10 },
                    stepSize: 10, // for % chart (important)
                },
            },
        },
    };
    var rateChart = {
        labels: filtered.map(function (c) { return c.name.split("—")[0]; }),
        datasets: [
            {
                label: "Open Rate %",
                data: filtered.map(function (c) { return (c.opened / c.sent) * 100; }),
                backgroundColor: "#059669",
                borderRadius: 8,
                barThickness: 22,
                categoryPercentage: 0.5,
            },
            {
                label: "CTR %",
                data: filtered.map(function (c) { return (c.clicked / c.sent) * 100; }),
                backgroundColor: "#0891b2",
                borderRadius: 8,
                barThickness: 22,
                categoryPercentage: 0.5,
            },
        ],
    };
    var funnelChart = {
        labels: filtered.map(function (c) { return c.name.split("—")[0]; }),
        datasets: [
            {
                label: "Sent",
                data: filtered.map(function (c) { return c.sent; }),
                backgroundColor: "#e5e7eb",
                borderRadius: 8,
                barThickness: 18,
            },
            {
                label: "Opened",
                data: filtered.map(function (c) { return c.opened; }),
                backgroundColor: "#2563eb",
                borderRadius: 8,
                barThickness: 18,
            },
            {
                label: "Clicked",
                data: filtered.map(function (c) { return c.clicked; }),
                backgroundColor: "#0891b2",
                borderRadius: 8,
                barThickness: 18,
            },
            {
                label: "Leads",
                data: filtered.map(function (c) { return c.leads; }),
                backgroundColor: "#059669",
                borderRadius: 8,
                barThickness: 18,
            },
        ],
    };
    react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
        fetchCampaignData();
    }, []);
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].root },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].globalHeader },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].globalTitle }, "Email Campaigns"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].globalSub }, "Campaign metrics \u00B7 Excel data")),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].headerActions },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(_DatePicker_DatePicker__WEBPACK_IMPORTED_MODULE_2__["default"], { value: dateRange, onChange: setDateRange, maxDate: new Date() }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"]['li-connect-btn'] }, "\uD83D\uDD17 Connect Sources"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].primaryBtn }, "\uD83D\uDD04 Refresh"))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].topHeaderBar },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].headerContainer },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].leftSection },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].iconBox }, "\uD83D\uDCE7"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].title }, "Email Campaigns"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].subText }, "Data from Excel upload \u00B7 Manual entry"))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].tag },
                        " ",
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null, "\uD83D\uDCCA"),
                        "Excel Data")))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiGrid },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpi },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiTop },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "".concat(_EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiIcon, " ").concat(_EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].blueBg) }, "\uD83D\uDCE4")),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiLabel }, "TOTAL EMAILS SENT"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiVal }, fmt(totals.sent)),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiSub }, "Across campaigns"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiAccent, style: { background: "#2563eb" } })),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpi },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiTop },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "".concat(_EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiIcon, " ").concat(_EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].greenBg) }, "\uD83D\uDCCA"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiBadge }, "\u25B2 2x avg")),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiLabel }, "AVG OPEN RATE"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiVal }, openRate),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiSub }, "Industry avg 21.5%"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiAccent, style: { background: "#059669" } })),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpi },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiTop },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "".concat(_EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiIcon, " ").concat(_EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].blueSoft) }, "\uD83D\uDCC8"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiBadge }, "\u25B2 Excellent")),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiLabel }, "AVG CTR"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiVal }, ctr),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiSub }, "Clicks / Sent"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiAccent, style: { background: "#0891b2" } })),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpi },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiTop },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "".concat(_EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiIcon, " ").concat(_EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].orangeBg) }, "\uD83C\uDFAF"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiBadge }, "\u25B2 16%")),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiLabel }, "LEADS FROM EMAIL"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiVal }, totals.leads),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiSub }, "MQLs generated"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].kpiAccent, style: { background: "#f59e0b" } }))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].chartsGrid },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].card },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardHeader },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardTitle }, "Open Rate vs CTR by Campaign"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardSub }, "Performance comparison")),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_chart__WEBPACK_IMPORTED_MODULE_5__.Chart, { type: "bar", data: rateChart, options: chartOptions })),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].card },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardHeader },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardTitle }, "Email Funnel"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].cardSub }, "Sent \u2192 Opened \u2192 Clicked \u2192 Leads")),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_chart__WEBPACK_IMPORTED_MODULE_5__.Chart, { type: "bar", data: funnelChart, options: chartOptions }))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].tableCard },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].tableTitle }, "Campaign Detail"),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("table", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].table },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("thead", null,
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", null, "#"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", null, "Campaign"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", null, "Sent"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", null, "Opened"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", null, "Open Rate"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", null, "Clicked"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", null, "CTR"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", null, "Bounced"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", null, "Unsub"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", null, "Leads"))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("tbody", null, filtered.map(function (c, i) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", { key: c.id },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, i + 1),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, c.name),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, fmt(c.sent)),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, fmt(c.opened)),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "".concat(_EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].pill, " ").concat(_EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].pillGreen) }, pct(c.opened, c.sent))),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, fmt(c.clicked)),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "".concat(_EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].pill, " ").concat(_EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].pillBlue) }, pct(c.clicked, c.sent))),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "".concat(_EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].pill, " ").concat(_EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].pillAmber) }, c.bounced)),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "".concat(_EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].pill, " ").concat(_EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].pillRed) }, c.unsubscribed)),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, c.leads))); }))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: _EmailCampaigns_module_scss__WEBPACK_IMPORTED_MODULE_1__["default"].uploadHint }, "\uD83D\uDCE4 Add New Campaign Data"))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EmailCampaignsDashboard);


/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("0f96260191353c509f63")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=marketing-analytics-web-part.0be8b26205e438005bc1.hot-update.js.map