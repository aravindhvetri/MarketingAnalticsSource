"use strict";
self["webpackHotUpdated4faa06d_862f_4712_a355_4e54547f85f3_0_0_1"]("marketing-analytics-web-part",{

/***/ 5204:
/*!***********************************************************************!*\
  !*** ./lib/webparts/marketingAnalytics/components/PaidAds/PaidAds.js ***!
  \***********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PaidAdsPerformance: () => (/* binding */ PaidAdsPerformance),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 196);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 5959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var primereact_chart__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! primereact/chart */ 4964);
/* harmony import */ var _pnp_sp__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @pnp/sp */ 2011);
/* harmony import */ var _DatePicker_DatePicker__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../DatePicker/DatePicker */ 8938);






// ─── Helpers ───────────────────────────────────────────────────
function defaultRange() {
    var today = new Date();
    return {
        startDate: new Date(today.getFullYear(), today.getMonth(), 1),
        endDate: today,
        label: "This Month",
    };
}
// ─── Main Component ────────────────────────────────────────────
var PaidAdsPerformance = function () {
    var _a = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(defaultRange), dateRange = _a[0], setDateRange = _a[1];
    var _b = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]), googleAdsData = _b[0], setGoogleAdsData = _b[1];
    var _c = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]), facebookAdsData = _c[0], setFacebookAdsData = _c[1];
    var getCtrType = function (ctr) {
        if (ctr > 3)
            return "good";
        if (ctr > 1)
            return "mid";
        return "low";
    };
    var getStatus = function (status) {
        if ((status === null || status === void 0 ? void 0 : status.toUpperCase()) === "PAUSED")
            return "Paused";
        if ((status === null || status === void 0 ? void 0 : status.toUpperCase()) === "ACTIVE")
            return "Active";
        return "Brand";
    };
    // ─── Combine Data ───────────────────────────────────────────
    var combinedData = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
        var google = googleAdsData.map(function (item) {
            var _a, _b, _c, _d, _e;
            return ({
                platform: "Google",
                campaignName: item.CampaignName,
                date: item.Date ? new Date(item.Date) : new Date(),
                spend: Number((_a = item.Spend) !== null && _a !== void 0 ? _a : 0),
                impressions: Number((_b = item.Impressions) !== null && _b !== void 0 ? _b : 0),
                clicks: Number((_c = item.Clicks) !== null && _c !== void 0 ? _c : 0),
                ctr: "".concat(Number((_d = item.CTR) !== null && _d !== void 0 ? _d : 0).toFixed(2), "%"),
                ctrType: getCtrType(Number((_e = item.CTR) !== null && _e !== void 0 ? _e : 0)),
                leads: item.Leads ? Number(item.Leads) : null,
                cpl: item.CPL && item.CPL > 0 ? Number(item.CPL) : null,
                status: getStatus(item.Status),
            });
        });
        var facebook = facebookAdsData.map(function (item) {
            var _a, _b, _c, _d, _e;
            return ({
                platform: "Facebook",
                campaignName: item.CampaignName,
                date: item.Date ? new Date(item.Date) : new Date(),
                spend: Number((_a = item.Spend) !== null && _a !== void 0 ? _a : 0),
                impressions: Number((_b = item.Impressions) !== null && _b !== void 0 ? _b : 0),
                clicks: Number((_c = item.Clicks) !== null && _c !== void 0 ? _c : 0),
                ctr: "".concat(Number((_d = item.CTR) !== null && _d !== void 0 ? _d : 0).toFixed(2), "%"),
                ctrType: getCtrType(Number((_e = item.CTR) !== null && _e !== void 0 ? _e : 0)),
                leads: item.Leads ? Number(item.Leads) : null,
                cpl: item.CPL && item.CPL > 0 ? Number(item.CPL) : null,
                status: getStatus(item.Status),
            });
        });
        return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__spreadArray)((0,tslib__WEBPACK_IMPORTED_MODULE_3__.__spreadArray)([], google, true), facebook, true);
    }, [googleAdsData, facebookAdsData]);
    // ─── Filter ────────────────────────────────────────────────
    var filtered = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
        var startDate = dateRange.startDate, endDate = dateRange.endDate;
        return combinedData.filter(function (c) {
            var time = new Date(c.date).setHours(0, 0, 0, 0);
            return (time >= startDate.setHours(0, 0, 0, 0) &&
                time <= endDate.setHours(0, 0, 0, 0));
        });
    }, [combinedData, dateRange]);
    // ─── KPI ───────────────────────────────────────────────────
    var kpis = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
        var totalSpend = filtered.reduce(function (s, c) { return s + c.spend; }, 0);
        var totalLeads = filtered.reduce(function (s, c) { var _a; return s + ((_a = c.leads) !== null && _a !== void 0 ? _a : 0); }, 0);
        var avgCpl = totalLeads > 0 ? totalSpend / totalLeads : 0;
        return { totalSpend: totalSpend, totalLeads: totalLeads, avgCpl: avgCpl };
    }, [filtered]);
    // ─── Chart: Spend vs Leads ─────────────────────────────────
    var spendLeadsData = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
        var sum = function (arr, key) {
            return arr.reduce(function (a, b) { var _a; return a + Number((_a = b[key]) !== null && _a !== void 0 ? _a : 0); }, 0);
        };
        var google = filtered.filter(function (x) { return x.platform === "Google"; });
        var facebook = filtered.filter(function (x) { return x.platform === "Facebook"; });
        return {
            labels: ["Google", "Facebook"],
            datasets: [
                {
                    label: "Spend",
                    data: [sum(google, "spend"), sum(facebook, "spend")],
                },
                {
                    label: "Leads",
                    data: [sum(google, "leads"), sum(facebook, "leads")],
                },
            ],
        };
    }, [filtered]);
    // ─── CPL Trend ─────────────────────────────────────────────
    var cplTrendData = (0,react__WEBPACK_IMPORTED_MODULE_0__.useMemo)(function () {
        var grouped = {};
        filtered.forEach(function (item) {
            var _a;
            var d = item.date;
            var key = "".concat(d.getFullYear(), "-").concat(d.getMonth());
            if (!grouped[key]) {
                grouped[key] = {
                    date: new Date(d.getFullYear(), d.getMonth(), 1),
                    Google: [],
                    Facebook: [],
                };
            }
            var cplVal = (_a = item.cpl) !== null && _a !== void 0 ? _a : 0;
            if (item.platform === "Google" && cplVal > 0) {
                grouped[key].Google.push(cplVal);
            }
            if (item.platform === "Facebook" && cplVal > 0) {
                grouped[key].Facebook.push(cplVal);
            }
        });
        var keys = Object.keys(grouped).sort(function (a, b) { return grouped[a].date.getTime() - grouped[b].date.getTime(); });
        var avg = function (arr) {
            return arr.length ? arr.reduce(function (a, b) { return a + b; }, 0) / arr.length : null;
        };
        return {
            labels: keys.map(function (k) {
                return grouped[k].date.toLocaleString("en-US", { month: "short" });
            }),
            datasets: [
                {
                    label: "Google CPL",
                    data: keys.map(function (k) { return avg(grouped[k].Google); }),
                },
                {
                    label: "Facebook CPL",
                    data: keys.map(function (k) { return avg(grouped[k].Facebook); }),
                },
            ],
        };
    }, [filtered]);
    // ─── Fetch ────────────────────────────────────────────────
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function () {
        var fetchData = function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(void 0, void 0, void 0, function () {
            var google, fb;
            return (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__generator)(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, _pnp_sp__WEBPACK_IMPORTED_MODULE_1__.sp.web.lists
                            .getByTitle("GoogleAds")
                            .items.getAll()];
                    case 1:
                        google = _a.sent();
                        return [4 /*yield*/, _pnp_sp__WEBPACK_IMPORTED_MODULE_1__.sp.web.lists
                                .getByTitle("FacebookAds")
                                .items.getAll()];
                    case 2:
                        fb = _a.sent();
                        setGoogleAdsData(google);
                        setFacebookAdsData(fb);
                        return [2 /*return*/];
                }
            });
        }); };
        fetchData();
    }, []);
    // ─── UI ───────────────────────────────────────────────────
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
        react__WEBPACK_IMPORTED_MODULE_0__.createElement(_DatePicker_DatePicker__WEBPACK_IMPORTED_MODULE_2__["default"], { value: dateRange, onChange: setDateRange }),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_chart__WEBPACK_IMPORTED_MODULE_4__.Chart, { type: "bar", data: spendLeadsData }),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement(primereact_chart__WEBPACK_IMPORTED_MODULE_4__.Chart, { type: "line", data: cplTrendData }),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
            "Total Spend: \u20B9",
            kpis.totalSpend),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
            "Total Leads: ",
            kpis.totalLeads),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
            "Avg CPL: \u20B9",
            kpis.avgCpl.toFixed(0))));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PaidAdsPerformance);


/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("2677934c4ae7f3d895c5")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=marketing-analytics-web-part.2622ed9090f2eced2919.hot-update.js.map