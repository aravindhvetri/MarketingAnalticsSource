import * as React from "react";
import { useEffect, useRef } from "react";
import {
  Chart,
  BarController,
  LineController,
  DoughnutController,
  BarElement,
  LineElement,
  ArcElement,
  PointElement,
  LinearScale,
  CategoryScale,
  Legend,
  Tooltip,
  Filler,
} from "chart.js";


import styles from "./OverViewDashboard.module.scss";

Chart.register(
  BarController,
  LineController,
  DoughnutController,
  BarElement,
  LineElement,
  ArcElement,
  PointElement,
  LinearScale,
  CategoryScale,
  Legend,
  Tooltip,
  Filler
);


Chart.defaults.font.family = "'Plus Jakarta Sans', 'Segoe UI', sans-serif";
Chart.defaults.font.size = 11;
Chart.defaults.color = "#8a9bbf";



interface ISummaryBandItem {
  id: string;
  value: string;
  label: string;
}

interface IKpiCard {
  icon: string;
  iconBg: string;
  accentColor: string;
  deltaText: string;
  deltaType: "up" | "dn" | "flat";
  label: string;
  value: string;
  sub: string;
}

interface IChannelScore {
  icon: string;
  label: string;
  score: number;
  color: string;
}

interface ITopCampaign {
  icon: string;
  label: string;
  value: number;
}

interface ILeadSourceStat {
  value: string;
  label: string;
  color: string;
}


const SUMMARY_BAND: ISummaryBandItem[] = [
  { id: "totalLeads", value: "628",   label: "Total Leads"     },
  { id: "sessions",   value: "41.3K", label: "Website Users"   },
  { id: "adSpend",    value: "₹83K",  label: "Ad Spend"        },
  { id: "convRate",   value: "1.36%", label: "Conv. Rate"      },
  { id: "cpl",        value: "₹312",  label: "Avg CPL"         },
  { id: "qualLeads",  value: "184",   label: "Qualified Leads" },
];

const KPI_CARDS: IKpiCard[] = [
  {
    icon: "💼", iconBg: "#e8f0fe", accentColor: "#1a6ef5",
    deltaText: "▲ 28%", deltaType: "up",
    label: "LinkedIn Followers", value: "12,840", sub: "+820 gained this month",
  },
  {
    icon: "📧", iconBg: "#d1fae5", accentColor: "#059669",
    deltaText: "▲ 41.9%", deltaType: "up",
    label: "Email Open Rate", value: "42%", sub: "Industry avg 21.5%",
  },
  {
    icon: "🌐", iconBg: "#e0f5fa", accentColor: "#0891b2",
    deltaText: "▲ 23%", deltaType: "up",
    label: "Total Website Users", value: "41.3K", sub: "Unique visitors · GA4",
  },
  {
    icon: "💰", iconBg: "#ffe4e6", accentColor: "#e11d48",
    deltaText: "▼ CPL ₹312", deltaType: "dn",
    label: "Ads Leads", value: "305", sub: "Google + LinkedIn Ads",
  },
];

const CHANNEL_SCORES: IChannelScore[] = [
  { icon: "💼", label: "LinkedIn Organic", score: 87, color: "#1a6ef5" },
  { icon: "🔍", label: "SEO / GSC",        score: 74, color: "#0891b2" },
  { icon: "📧", label: "Email Campaigns",  score: 81, color: "#059669" },
  { icon: "💰", label: "Google Ads",       score: 69, color: "#d97706" },
  { icon: "💰", label: "LinkedIn Ads",     score: 58, color: "#ea580c" },
];

const TOP_CAMPAIGNS: ITopCampaign[] = [
  { icon: "🗂",  label: "SharePoint Migration EOL", value: 184 },
  { icon: "🤖", label: "Copilot Studio Awareness",  value: 112 },
  { icon: "⚡", label: "Power Platform — Mfg",       value: 96  },
  { icon: "☁️", label: "Azure Migration Bundle",     value: 84  },
  { icon: "📋", label: "Dynamics 365 Webinar",       value: 80  },
  { icon: "📊", label: "Salesforce CRM Promo",       value: 72  },
];

const LEAD_SOURCE_STATS: ILeadSourceStat[] = [
  { value: "305", label: "Ads",     color: "#1a6ef5" },
  { value: "158", label: "Email",   color: "#059669" },
  { value: "165", label: "Organic", color: "#0891b2" },
];


const LeadsTrendChart: React.FC = () => {
  const canvasRef  = useRef<HTMLCanvasElement>(null);
  const chartRef   = useRef<Chart | null>(null);
  const wrapperRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!canvasRef.current) return;
    if (chartRef.current) { chartRef.current.destroy(); chartRef.current = null; }

    const canvas = canvasRef.current;
    canvas.width  = wrapperRef.current ? wrapperRef.current.clientWidth : 600;
    canvas.height = 220;

    chartRef.current = new Chart(canvas, {
      type: "line",
      data: {
        labels: ["Oct", "Nov", "Dec", "Jan", "Feb", "Mar"],
        datasets: [
          {
            label: "Google Ads",
            data: [140, 165, 155, 175, 180, 210],
            borderColor: "#e11d48",
            backgroundColor: "rgba(225,29,72,.06)",
            fill: true, tension: 0.4, pointRadius: 4, borderWidth: 2,
          },
          {
            label: "LinkedIn Ads",
            data: [40, 55, 62, 70, 78, 95],
            borderColor: "#7c3aed",
            backgroundColor: "rgba(124,58,237,.04)",
            fill: true, tension: 0.4, pointRadius: 4, borderWidth: 2,
          },
          {
            label: "Email",
            data: [60, 72, 68, 80, 85, 73],
            borderColor: "#059669",
            backgroundColor: "rgba(5,150,105,.04)",
            fill: true, tension: 0.4, pointRadius: 4, borderWidth: 2,
          },
          {
            label: "Organic SEO",
            data: [80, 95, 105, 120, 140, 165],
            borderColor: "#0891b2",
            backgroundColor: "rgba(8,145,178,.04)",
            fill: true, tension: 0.4, pointRadius: 4, borderWidth: 2,
          },
        ],
      },
      options: {
        responsive: false,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: "bottom",
            labels: { boxWidth: 10, padding: 14, font: { size: 11 } },
          },
        },
        scales: {
          y: { grid: { color: "rgba(226,232,242,.8)" }, beginAtZero: true },
          x: { grid: { color: "rgba(226,232,242,.4)" } },
        },
      },
    });

    return () => { if (chartRef.current) { chartRef.current.destroy(); chartRef.current = null; } };
  }, []);

  return (
    <div ref={wrapperRef} className={styles.chartWrapper}>
      <canvas ref={canvasRef} />
    </div>
  );
};

const LeadSourcePieChart: React.FC = () => {
  const canvasRef  = useRef<HTMLCanvasElement>(null);
  const chartRef   = useRef<Chart | null>(null);
  const wrapperRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!canvasRef.current) return;
    if (chartRef.current) { chartRef.current.destroy(); chartRef.current = null; }

    const canvas = canvasRef.current;
    canvas.width  = wrapperRef.current ? wrapperRef.current.clientWidth : 300;
    canvas.height = 190;

    chartRef.current = new Chart(canvas, {
      type: "doughnut",
      data: {
        labels: ["Paid Ads", "Email", "Organic SEO"],
        datasets: [{
          data: [305, 158, 165],
          backgroundColor: ["#e11d48", "#059669", "#0891b2"],
          borderWidth: 0,
          hoverOffset: 8,
        }],
      },
      options: {
        responsive: false,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: "bottom",
            labels: { boxWidth: 10, padding: 12, font: { size: 10 } },
          },
        },
      },
    });

    return () => { if (chartRef.current) { chartRef.current.destroy(); chartRef.current = null; } };
  }, []);

  return (
    <div ref={wrapperRef} className={styles.chartWrapperSm}>
      <canvas ref={canvasRef} />
    </div>
  );
};

const TrafficDonutChart: React.FC = () => {
  const canvasRef  = useRef<HTMLCanvasElement>(null);
  const chartRef   = useRef<Chart | null>(null);
  const wrapperRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!canvasRef.current) return;
    if (chartRef.current) { chartRef.current.destroy(); chartRef.current = null; }

    const canvas = canvasRef.current;
    canvas.width  = wrapperRef.current ? wrapperRef.current.clientWidth : 300;
    canvas.height = 220;

    chartRef.current = new Chart(canvas, {
      type: "doughnut",
      data: {
        labels: ["Organic", "Direct", "Social", "Referral", "Paid"],
        datasets: [{
          data: [9200, 4200, 2800, 2300, 1400],
          backgroundColor: ["#1a6ef5", "#0891b2", "#7c3aed", "#d97706", "#e11d48"],
          borderWidth: 0,
          hoverOffset: 6,
        }],
      },
      options: {
        responsive: false,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: "right",
            labels: { boxWidth: 10, font: { size: 10 } },
          },
        },
      },
    });

    return () => { if (chartRef.current) { chartRef.current.destroy(); chartRef.current = null; } };
  }, []);

  return (
    <div ref={wrapperRef} className={styles.chartWrapper}>
      <canvas ref={canvasRef} />
    </div>
  );
};



const KpiCard: React.FC<IKpiCard> = (props) => {
  const deltaClass =
    props.deltaType === "up" ? styles.deltaUp :
    props.deltaType === "dn" ? styles.deltaDn :
    styles.deltaFlat;

  return (
    <div className={styles.kpi}>
      <div className={styles.kpiTop}>
        <div className={styles.kpiIcon} style={{ background: props.iconBg }}>
          {props.icon}
        </div>
        <div className={`${styles.kpiDelta} ${deltaClass}`}>{props.deltaText}</div>
      </div>
      <div className={styles.kpiLabel}>{props.label}</div>
      <div className={styles.kpiVal}>{props.value}</div>
      <div className={styles.kpiSub}>{props.sub}</div>
      <div className={styles.kpiAccent} style={{ background: props.accentColor }} />
    </div>
  );
};

const SummaryBand: React.FC = () => (
  <div className={styles.summaryBand}>
    {SUMMARY_BAND.map((item, i) => (
      <React.Fragment key={item.id}>
        {i > 0 && <div className={styles.sbDiv} />}
        <div className={styles.sbItem}>
          <div className={styles.sbNum}>{item.value}</div>
          <div className={styles.sbLbl}>{item.label}</div>
        </div>
      </React.Fragment>
    ))}
  </div>
);

const ChannelPerformance: React.FC = () => (
  <div className={styles.progList}>
    {CHANNEL_SCORES.map((ch, i) => (
      <div className={styles.progWrap} key={i}>
        <div className={styles.progRow}>
          <span className={styles.progLabel}>{ch.icon} {ch.label}</span>
          <span className={styles.progVal}>{ch.score}/100</span>
        </div>
        <div className={styles.progBar}>
          <div
            className={styles.progFill}
            style={{ width: `${ch.score}%`, background: ch.color }}
          />
        </div>
      </div>
    ))}
  </div>
);

const TopCampaigns: React.FC = () => (
  <>
    {TOP_CAMPAIGNS.map((c, i) => (
      <div className={styles.miniM} key={i}>
        <span className={styles.miniLabel}>{c.icon} {c.label}</span>
        <span className={styles.miniVal}>{c.value}</span>
      </div>
    ))}
  </>
);


const OverViewDashboard: React.FC = () => {
  return (
    <div className={styles.overviewDashboard}>

      {/* ── Section Header ── */}
      <div className={styles.secHeader}>
        <div className={styles.secTitleWrap}>
          <div className={styles.secIcon} style={{ background: "#e8f0fe" }}>⬛</div>
          <div>
            <div className={styles.secTitle}>Marketing Overview</div>
            <div className={styles.secSub}>All channels · TechnoRUCS</div>
          </div>
        </div>
        <div className={styles.secActions}>
          <span className={`${styles.sourceBadge} ${styles.badgeGreen}`}>
            🟢 Live Dashboard
          </span>
        </div>
      </div>

      {/* ── Summary Band ── */}
      <SummaryBand />

      {/* ── KPI Strip ── */}
      <div className={`${styles.g4} ${styles.mt}`}>
        {KPI_CARDS.map((kpi, i) => <KpiCard key={i} {...kpi} />)}
      </div>

      {/* ── Lead Trend + Source Pie ── */}
      <div className={`${styles.gWide} ${styles.mt}`}>
        <div className={styles.card}>
          <div className={styles.cardHead}>
            <div>
              <div className={styles.cardTitle}>Lead Generation — All Channels</div>
              <div className={styles.cardSub}>Monthly trend across all marketing sources</div>
            </div>
            <span className={`${styles.cardBadge} ${styles.pillBlue}`}>Last 6 Months</span>
          </div>
          <LeadsTrendChart />
        </div>

        <div className={styles.card}>
          <div className={styles.cardHead}>
            <div>
              <div className={styles.cardTitle}>Lead Source Mix</div>
              <div className={styles.cardSub}>This period</div>
            </div>
          </div>
          <LeadSourcePieChart />
          <div className={styles.statRow}>
            {LEAD_SOURCE_STATS.map((s, i) => (
              <div className={styles.statBox} key={i}>
                <div className={styles.statVal} style={{ color: s.color }}>{s.value}</div>
                <div className={styles.statLbl}>{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── Channel Score + Traffic Donut + Top Campaigns ── */}
      <div className={`${styles.g3} ${styles.mt}`}>
        <div className={styles.card}>
          <div className={styles.cardHead}>
            <div>
              <div className={styles.cardTitle}>Channel Performance Score</div>
              <div className={styles.cardSub}>Relative effectiveness</div>
            </div>
          </div>
          <ChannelPerformance />
        </div>

        <div className={styles.card}>
          <div className={styles.cardHead}>
            <div>
              <div className={styles.cardTitle}>Website Traffic Sources</div>
              <div className={styles.cardSub}>Session share this period</div>
            </div>
          </div>
          <TrafficDonutChart />
          
        </div>

        <div className={styles.card}>
          <div className={styles.cardHead}>
            <div>
              <div className={styles.cardTitle}>Top Performing Campaigns</div>
              <div className={styles.cardSub}>By leads generated</div>
            </div>
          </div>
          <TopCampaigns />
        </div>
      </div>

    </div>
  );
};

export default OverViewDashboard;