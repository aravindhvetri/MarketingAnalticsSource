import * as React from "react";
import { useState } from "react";
import Sidebar from "../SidNavComponets/SidNavComponets";
import "../../../ExternalRef/CSS/ReportsStyle.css";
import LinkedInAnalytics from "../LinkedIn/LinkedIn";
import EmailCampaignsDashboard from "../EmailCampaigns/EmailCampaigns";
import WebsiteAnalytics from "../WebsiteAnalytics/WebsiteAnalytics";

import SEOIntelligence from "../SEOIntelligence/SEOIntelligence";
import LeadsIntelligence from "../LeadsIntelligence/LeadsIntelligence";
import MarketingOverviewDashboard from "../OverViewDashboard/OverViewDashboard";
import PaidAdsPerformance from "../PaidAds/PaidAds";

const MainComponent = (props: any) => {
  const [activeSection, setActiveSection] = useState("overview");
  const [pageTitle, setPageTitle] = useState("Marketing Overview");
  const [pageSub, setPageSub] = useState("All channels · TechnoRUCS");

  const handleNav = (id: string, title: string, sub: string) => {
    setActiveSection(id);
    setPageTitle(title);
    setPageSub(sub);
  };

  const renderSection = () => {
    switch (activeSection) {
      case "overview":
        return (
          <div style={{ padding: "24px 28px" }}>
            <MarketingOverviewDashboard />
            <p style={{ color: "#8a9bbf", fontSize: 13 }}>
              Overview — Coming soon
            </p>
          </div>
        );

      case "linkedin":
        return <LinkedInAnalytics />;

      case "email":
        return (
          <div>
            <EmailCampaignsDashboard />
          </div>
        );

      case "website":
        return (
          <div style={{ padding: "24px 28px" }}>
            <WebsiteAnalytics />
            <p style={{ color: "#8a9bbf", fontSize: 13 }}>
              Website Analytics — Coming soon
            </p>
          </div>
        );

      case "ads":
        return (
          <div style={{ padding: "24px 28px" }}>
            {<PaidAdsPerformance />}
            <p style={{ color: "#8a9bbf", fontSize: 13 }}>
              Paid Ads — Coming soon
            </p>
          </div>
        );

      case "seo":
        return (
          <div style={{ padding: "24px 28px" }}>
            <SEOIntelligence />
            <p style={{ color: "#8a9bbf", fontSize: 13 }}>
              SEO Intelligence — Coming soon
            </p>
          </div>
        );

      case "leads":
        return (
          <div style={{ padding: "24px 28px" }}>
            <LeadsIntelligence />
            <p style={{ color: "#8a9bbf", fontSize: 13 }}>
              Leads Intelligence — Coming soon
            </p>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div style={{ display: "flex", minHeight: "100vh", background: "#f4f6fb" }}>
      <Sidebar activeSection={activeSection} onNav={handleNav} />

      {/* Main content area */}
      <div
        style={{
          flex: 1,
          display: "flex",
          flexDirection: "column",
          overflow: "hidden",
        }}
      >
        {/* Section Content */}
        <div style={{ flex: 1, overflowY: "auto" }}>{renderSection()}</div>
      </div>
    </div>
  );
};

export default MainComponent;
