import * as React from "react";
import { useState, useMemo } from "react";
import styles from "./EmailCampaigns.module.scss";
import DateRangePicker, { DateRange } from "../DatePicker/DatePicker";
import { Chart } from "primereact/chart";
import { sp } from "@pnp/sp";

/* ---------------- TYPES ---------------- */
export interface ICampaign {
  id: number;
  name: string;
  date: Date;
  sent: number;
  opened: number;
  clicked: number;
  bounced: number;
  unsubscribed: number;
  leads: number;
}

export interface IEmailCampaign {
  ID: number;
  CampaignName: string;
  CampaignId: string;
  ReportDate: string | null;
  Date: string | null;

  Sent: number;
  Opened: number;
  Clicked: number;
  Bounced: number;
  UnSubscribed: number;
  Leads: number;

  OpenRate: number;
  CTR: number;
}

const pct = (n: number, d: number) =>
  d === 0 ? "0%" : `${((n / d) * 100).toFixed(1)}%`;

const fmt = (n: number) =>
  n >= 1000 ? (n / 1000).toFixed(1) + "K" : n.toString();

function defaultRange(): DateRange {
  const today = new Date();
  return {
    startDate: new Date(today.getFullYear(), today.getMonth(), 1),
    endDate: today,
    label: "This Month",
  };
}

const EmailCampaignsDashboard: React.FC = () => {
  const [dateRange, setDateRange] = useState<DateRange>(defaultRange());
  const [campaignData, setCampaignData] = useState<ICampaign[]>([]);

  const fetchCampaignData = async () => {
    try {
      const response = await sp.web.lists
        .getByTitle("WebsiteAnalyticsEmailCampaign")
        .items.select(
          "ID",
          "CampaignName",
          "Date",
          "Sent",
          "Opened",
          "Clicked",
          "Bounced",
          "UnSubscribed",
          "Leads",
        )
        .orderBy("Date", false)
        .getAll();

      const formatted = response.map((item: any) => ({
        id: item.ID,
        name: item.CampaignName,
        date: item.Date ? new Date(item.Date) : new Date(),
        sent: Number(item.Sent || 0),
        opened: Number(item.Opened || 0),
        clicked: Number(item.Clicked || 0),
        bounced: Number(item.Bounced || 0),
        unsubscribed: Number(item.UnSubscribed || 0),
        leads: Number(item.Leads || 0),
      }));

      setCampaignData(formatted);
    } catch (err) {
      console.error(err);
    }
  };

  const filtered = useMemo(() => {
    return campaignData.filter(
      (c) => c.date >= dateRange.startDate && c.date <= dateRange.endDate,
    );
  }, [campaignData, dateRange]);

  const totals = useMemo(() => {
    return {
      sent: filtered.reduce((a, b) => a + b.sent, 0),
      opened: filtered.reduce((a, b) => a + b.opened, 0),
      clicked: filtered.reduce((a, b) => a + b.clicked, 0),
      leads: filtered.reduce((a, b) => a + b.leads, 0),
    };
  }, [filtered]);

  const openRate = pct(totals.opened, totals.sent);
  const ctr = pct(totals.clicked, totals.sent);

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,

    layout: {
      padding: {
        top: 10,
        right: 10,
        bottom: 0,
        left: 0,
      },
    },

    plugins: {
      legend: {
        display: true,
        position: "top",
        align: "center",
        labels: {
          color: "#64748b",
          font: {
            size: 11,
            weight: "500",
          },
          usePointStyle: true,
          pointStyle: "rect",
          boxWidth: 8,
          padding: 16,
        },
      },
    },

    scales: {
      x: {
        grid: {
          display: false,
        },
        ticks: {
          color: "#94a3b8",
          font: { size: 10 },
        },
      },

      y: {
        beginAtZero: true,
        grid: {
          color: "#eef2f7",
          drawBorder: false,
        },
        ticks: {
          color: "#94a3b8",
          font: { size: 10 },
          stepSize: 10,
        },
      },
    },
  };

  const rateChart = {
    labels: filtered.map((c) => c.name.split("—")[0]),
    datasets: [
      {
        label: "Open Rate %",
        data: filtered.map((c) => (c.opened / c.sent) * 100),
        backgroundColor: "#059669",
        borderRadius: 8,
        barThickness: 22,
        categoryPercentage: 0.5,
      },
      {
        label: "CTR %",
        data: filtered.map((c) => (c.clicked / c.sent) * 100),
        backgroundColor: "#0891b2",
        borderRadius: 8,
        barThickness: 22,
        categoryPercentage: 0.5,
      },
    ],
  };

  const funnelChart = {
    labels: filtered.map((c) => c.name.split("—")[0]),
    datasets: [
      {
        label: "Sent",
        data: filtered.map((c) => c.sent),
        backgroundColor: "#e5e7eb",
        borderRadius: 8,
        barThickness: 18,
      },
      {
        label: "Opened",
        data: filtered.map((c) => c.opened),
        backgroundColor: "#2563eb",
        borderRadius: 8,
        barThickness: 18,
      },
      {
        label: "Clicked",
        data: filtered.map((c) => c.clicked),
        backgroundColor: "#0891b2",
        borderRadius: 8,
        barThickness: 18,
      },
      {
        label: "Leads",
        data: filtered.map((c) => c.leads),
        backgroundColor: "#059669",
        borderRadius: 8,
        barThickness: 18,
      },
    ],
  };

  React.useEffect(() => {
    fetchCampaignData();
  }, []);

  return (
    <div className={styles.root}>
      {/* HEADER */}
      <div className={styles.globalHeader}>
        {/* LEFT */}
        <div>
          <div className={styles.globalTitle}>Email Campaigns</div>
          <div className={styles.globalSub}>Campaign metrics · Excel data</div>
        </div>

        {/* RIGHT */}
        <div className={styles.headerActions}>
          <DateRangePicker
            value={dateRange}
            onChange={setDateRange}
            maxDate={new Date()}
          />

          <button className={styles["li-connect-btn"]}>
            🔗 Connect Sources
          </button>

          <button className={styles.primaryBtn}>🔄 Refresh</button>
        </div>
      </div>
      <div className={styles.topHeaderBar}>
        <div className={styles.headerContainer}>
          <div className={styles.leftSection}>
            <div className={styles.iconBox}>📧</div>

            <div>
              <div className={styles.title}>Email Campaigns</div>

              <div className={styles.subText}>
                Data from Excel upload · Manual entry
              </div>
            </div>
          </div>

          <div>
            <span className={styles.tag}>
              {" "}
              <span>📊</span>Excel Data
            </span>
          </div>
        </div>
      </div>

      <div className={styles.kpiGrid}>
        {/* TOTAL */}
        <div className={styles.kpi}>
          <div className={styles.kpiTop}>
            <div className={`${styles.kpiIcon} ${styles.blueBg}`}>📤</div>
          </div>

          <div className={styles.kpiLabel}>TOTAL EMAILS SENT</div>
          <div className={styles.kpiVal}>{fmt(totals.sent)}</div>
          <div className={styles.kpiSub}>Across campaigns</div>

          <div className={styles.kpiAccent} style={{ background: "#2563eb" }} />
        </div>

        {/* OPEN RATE */}
        <div className={styles.kpi}>
          <div className={styles.kpiTop}>
            <div className={`${styles.kpiIcon} ${styles.greenBg}`}>📊</div>
            <span className={styles.kpiBadge}>▲ 2x avg</span>
          </div>

          <div className={styles.kpiLabel}>AVG OPEN RATE</div>
          <div className={styles.kpiVal}>{openRate}</div>
          <div className={styles.kpiSub}>Industry avg 21.5%</div>

          <div className={styles.kpiAccent} style={{ background: "#059669" }} />
        </div>

        {/* CTR */}
        <div className={styles.kpi}>
          <div className={styles.kpiTop}>
            <div className={`${styles.kpiIcon} ${styles.blueSoft}`}>📈</div>
            <span className={styles.kpiBadge}>▲ Excellent</span>
          </div>

          <div className={styles.kpiLabel}>AVG CTR</div>
          <div className={styles.kpiVal}>{ctr}</div>
          <div className={styles.kpiSub}>Clicks / Sent</div>

          <div className={styles.kpiAccent} style={{ background: "#0891b2" }} />
        </div>

        {/* LEADS */}
        <div className={styles.kpi}>
          <div className={styles.kpiTop}>
            <div className={`${styles.kpiIcon} ${styles.orangeBg}`}>🎯</div>
            <span className={styles.kpiBadge}>▲ 16%</span>
          </div>

          <div className={styles.kpiLabel}>LEADS FROM EMAIL</div>
          <div className={styles.kpiVal}>{totals.leads}</div>
          <div className={styles.kpiSub}>MQLs generated</div>

          <div className={styles.kpiAccent} style={{ background: "#f59e0b" }} />
        </div>
      </div>
      <div className={styles.chartsGrid}>
        <div className={styles.card}>
          <div className={styles.cardHeader}>
            <div className={styles.cardTitle}>Open Rate vs CTR by Campaign</div>
            <div className={styles.cardSub}>Performance comparison</div>
          </div>

          <Chart type="bar" data={rateChart} options={chartOptions} />
        </div>

        <div className={styles.card}>
          <div className={styles.cardHeader}>
            <div className={styles.cardTitle}>Email Funnel</div>
            <div className={styles.cardSub}>
              Sent → Opened → Clicked → Leads
            </div>
          </div>

          <Chart type="bar" data={funnelChart} options={chartOptions} />
        </div>
      </div>

      {/* TABLE */}
      <div className={styles.tableCard}>
        <div className={styles.tableTitle}>Campaign Detail</div>

        <table className={styles.table}>
          <thead>
            <tr>
              <th>#</th>
              <th>Campaign</th>
              <th>Sent</th>
              <th>Opened</th>
              <th>Open Rate</th>
              <th>Clicked</th>
              <th>CTR</th>
              <th>Bounced</th>
              <th>Unsub</th>
              <th>Leads</th>
            </tr>
          </thead>

          <tbody>
            {filtered.map((c, i) => (
              <tr key={c.id}>
                <td>{i + 1}</td>
                <td>{c.name}</td>
                <td>{fmt(c.sent)}</td>
                <td>{fmt(c.opened)}</td>

                <td>
                  <span className={`${styles.pill} ${styles.pillGreen}`}>
                    {pct(c.opened, c.sent)}
                  </span>
                </td>

                <td>{fmt(c.clicked)}</td>

                <td>
                  <span className={`${styles.pill} ${styles.pillBlue}`}>
                    {pct(c.clicked, c.sent)}
                  </span>
                </td>

                <td>
                  <span className={`${styles.pill} ${styles.pillAmber}`}>
                    {c.bounced}
                  </span>
                </td>

                <td>
                  <span className={`${styles.pill} ${styles.pillRed}`}>
                    {c.unsubscribed}
                  </span>
                </td>

                <td>{c.leads}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className={styles.uploadHint}>📤 Add New Campaign Data</div>
      </div>
    </div>
  );
};

export default EmailCampaignsDashboard;
