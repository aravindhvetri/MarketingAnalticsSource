"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
/* eslint-disable prefer-const */
/* eslint-disable @typescript-eslint/explicit-function-return-type */
/* eslint-disable no-var */
/* eslint-disable @typescript-eslint/no-explicit-any */
// /* eslint-disable no-unused-expressions */
// /* eslint-disable no-var */
// /* eslint-disable prefer-const */
// /* eslint-disable eqeqeq */
var all_1 = require("@pnp/sp/presets/all");
require("@pnp/sp/webs");
var getAllUsers = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
    return tslib_1.__generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4 /*yield*/, all_1.sp.web.siteUsers()];
            case 1: return [2 /*return*/, _a.sent()];
        }
    });
}); };
var SPAddItem = function (params) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
    return tslib_1.__generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4 /*yield*/, all_1.sp.web.lists
                    .getByTitle(params.Listname)
                    .items.add(params.RequestJSON)];
            case 1: return [2 /*return*/, _a.sent()];
        }
    });
}); };
var SPUpdateItem = function (params) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
    return tslib_1.__generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4 /*yield*/, all_1.sp.web.lists
                    .getByTitle(params.Listname)
                    .items.getById(params.ID)
                    .update(params.RequestJSON)];
            case 1: return [2 /*return*/, _a.sent()];
        }
    });
}); };
var SPDeleteItem = function (params) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
    return tslib_1.__generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4 /*yield*/, all_1.sp.web.lists
                    .getByTitle(params.Listname)
                    .items.getById(params.ID)
                    .recycle()];
            case 1: return [2 /*return*/, _a.sent()];
        }
    });
}); };
var formatInputs = function (data) {
    var _a, _b, _c, _d, _e, _f, _g;
    (_a = data.Select) !== null && _a !== void 0 ? _a : (data.Select = "*");
    (_b = data.Topcount) !== null && _b !== void 0 ? _b : (data.Topcount = 5000);
    (_c = data.Orderby) !== null && _c !== void 0 ? _c : (data.Orderby = "ID");
    (_d = data.Expand) !== null && _d !== void 0 ? _d : (data.Expand = "");
    (_e = data.Orderbydecorasc) !== null && _e !== void 0 ? _e : (data.Orderbydecorasc = true);
    (_f = data.PageCount) !== null && _f !== void 0 ? _f : (data.PageCount = 10);
    (_g = data.PageNumber) !== null && _g !== void 0 ? _g : (data.PageNumber = 1);
    return data;
};
var formatFilterValue = function (params, filterCondition) {
    var strFilter = "";
    if (params) {
        for (var i = 0; i < params.length; i++) {
            if (params[i].FilterKey) {
                if (i !== 0) {
                    if (filterCondition === "and" || filterCondition === "or") {
                        strFilter += " " + filterCondition + " ";
                    }
                    else {
                        strFilter += " and ";
                    }
                }
                if (params[i].Operator.toLowerCase() === "eq" ||
                    params[i].Operator.toLowerCase() === "ne" ||
                    params[i].Operator.toLowerCase() === "gt" ||
                    params[i].Operator.toLowerCase() === "lt" ||
                    params[i].Operator.toLowerCase() === "ge" ||
                    params[i].Operator.toLowerCase() === "le")
                    strFilter +=
                        params[i].FilterKey +
                            " " +
                            params[i].Operator +
                            " '" +
                            params[i].FilterValue +
                            "'";
                else if (params[i].Operator.toLowerCase() === "substringof")
                    strFilter +=
                        params[i].Operator +
                            "('" +
                            params[i].FilterKey +
                            "','" +
                            params[i].FilterValue +
                            "')";
            }
        }
    }
    return strFilter;
};
var SPReadItems = function (params) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
    var filterValue;
    return tslib_1.__generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                params = formatInputs(params);
                filterValue = formatFilterValue(params.Filter, params.FilterCondition ? params.FilterCondition : "");
                return [4 /*yield*/, all_1.sp.web.lists
                        .getByTitle(params.Listname)
                        .items.select(params.Select)
                        .filter(filterValue)
                        .expand(params.Expand)
                        .top(params.Topcount)
                        .orderBy(params.Orderby, params.Orderbydecorasc)
                        .get()];
            case 1: return [2 /*return*/, _a.sent()];
        }
    });
}); };
var SPReadItemUsingId = function (params) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
    return tslib_1.__generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4 /*yield*/, all_1.sp.web.lists
                    .getByTitle(params.Listname)
                    .items.getById(params.SelectedId)
                    .select(params.Select)
                    .expand(params.Expand)
                    .get()];
            case 1: return [2 /*return*/, _a.sent()];
        }
    });
}); };
var SPAddAttachments = function (params) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
    var files;
    return tslib_1.__generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                files = params.Attachments;
                return [4 /*yield*/, all_1.sp.web.lists
                        .getByTitle(params.ListName)
                        .items.getById(params.ListID)
                        .attachmentFiles.addMultiple(files)];
            case 1: return [2 /*return*/, _a.sent()];
        }
    });
}); };
var SPAddAttachment = function (params) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
    return tslib_1.__generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4 /*yield*/, all_1.sp.web.lists
                    .getByTitle(params.ListName)
                    .items.getById(params.ListID)
                    .attachmentFiles.add(params.FileName, params.Attachments)];
            case 1: return [2 /*return*/, _a.sent()];
        }
    });
}); };
var SPGetAttachments = function (params) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
    var item;
    return tslib_1.__generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                item = all_1.sp.web.lists
                    .getByTitle(params.Listname)
                    .items.getById(params.ID);
                return [4 /*yield*/, item.attachmentFiles()];
            case 1: return [2 /*return*/, _a.sent()];
        }
    });
}); };
var SPDeleteAttachments = function (params) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
    return tslib_1.__generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4 /*yield*/, all_1.sp.web.lists
                    .getByTitle(params.ListName)
                    .items.getById(params.ListID)
                    .attachmentFiles.getByName(params.AttachmentName)
                    .recycle()];
            case 1: return [2 /*return*/, _a.sent()];
        }
    });
}); };
var SPReadAttachments = function (params) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
    return tslib_1.__generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4 /*yield*/, all_1.sp.web.lists
                    .getByTitle(params.ListName)
                    .items.getById(params.ListID)
                    .attachmentFiles.getByName(params.AttachmentName)
                    .getText()];
            case 1: return [2 /*return*/, _a.sent()];
        }
    });
}); };
var SPGetChoices = function (params) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
    return tslib_1.__generator(this, function (_a) {
        switch (_a.label) {
            case 0: return [4 /*yield*/, all_1.sp.web.lists
                    .getByTitle(params.Listname)
                    .fields.getByInternalNameOrTitle(params.FieldName)
                    .get()];
            case 1: return [2 /*return*/, _a.sent()];
        }
    });
}); };
var SPDetailsListGroupItems = function (params) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
    var newRecords, varGroup, UniqueRecords;
    return tslib_1.__generator(this, function (_a) {
        newRecords = [];
        params.Data.forEach(function (arr, index) {
            newRecords.push({
                Lesson: arr[params.Column],
                indexValue: index,
            });
        });
        varGroup = [];
        UniqueRecords = newRecords.reduce(function (item, e1) {
            var matches = item.filter(function (e2) {
                return e1[params.Column] === e2[params.Column];
            });
            if (matches.length === 0) {
                item.push(e1);
            }
            return item;
        }, []);
        UniqueRecords.forEach(function (ur) {
            var recordLength = newRecords.filter(function (arr) {
                return arr[params.Column] === ur[params.Column];
            }).length;
            varGroup.push({
                key: ur[params.Column],
                name: ur[params.Column],
                startIndex: ur.indexValue,
                count: recordLength,
            });
        });
        return [2 /*return*/, varGroup];
    });
}); };
var batchInsert = function (params) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
    var list, batch, promises, _i, _a, data, promise;
    return tslib_1.__generator(this, function (_b) {
        switch (_b.label) {
            case 0:
                list = all_1.sp.web.lists.getByTitle(params.ListName);
                batch = all_1.sp.web.createBatch();
                promises = [];
                for (_i = 0, _a = params.responseData; _i < _a.length; _i++) {
                    data = _a[_i];
                    promise = list.items.inBatch(batch).add(data);
                    promises.push(promise);
                }
                return [4 /*yield*/, batch.execute()];
            case 1:
                _b.sent();
                return [2 /*return*/, promises];
        }
    });
}); };
var batchUpdate = function (params) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
    var list, batch, promises, _i, _a, data, promise;
    return tslib_1.__generator(this, function (_b) {
        switch (_b.label) {
            case 0:
                list = all_1.sp.web.lists.getByTitle(params.ListName);
                batch = all_1.sp.web.createBatch();
                promises = [];
                for (_i = 0, _a = params.responseData; _i < _a.length; _i++) {
                    data = _a[_i];
                    promise = list.items.getById(data.ID).inBatch(batch).update(data);
                    promises.push(promise);
                }
                return [4 /*yield*/, batch.execute()];
            case 1:
                _b.sent();
                return [2 /*return*/, promises];
        }
    });
}); };
var batchDelete = function (params) { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
    var list, batch, promises, _i, _a, data, promise;
    return tslib_1.__generator(this, function (_b) {
        switch (_b.label) {
            case 0:
                list = all_1.sp.web.lists.getByTitle(params.ListName);
                batch = all_1.sp.web.createBatch();
                promises = [];
                for (_i = 0, _a = params.responseData; _i < _a.length; _i++) {
                    data = _a[_i];
                    promise = list.items.getById(data.ID).inBatch(batch).recycle();
                    promises.push(promise);
                }
                return [4 /*yield*/, batch.execute()];
            case 1:
                _b.sent();
                return [2 /*return*/, promises];
        }
    });
}); };
exports.default = {
    getAllUsers: getAllUsers,
    SPAddItem: SPAddItem,
    SPUpdateItem: SPUpdateItem,
    SPDeleteItem: SPDeleteItem,
    SPReadItems: SPReadItems,
    SPDetailsListGroupItems: SPDetailsListGroupItems,
    SPGetChoices: SPGetChoices,
    SPAddAttachments: SPAddAttachments,
    SPAddAttachment: SPAddAttachment,
    SPGetAttachments: SPGetAttachments,
    SPDeleteAttachments: SPDeleteAttachments,
    SPReadItemUsingId: SPReadItemUsingId,
    batchInsert: batchInsert,
    batchUpdate: batchUpdate,
    batchDelete: batchDelete,
    SPReadAttachments: SPReadAttachments,
};
//# sourceMappingURL=SpServices.js.map