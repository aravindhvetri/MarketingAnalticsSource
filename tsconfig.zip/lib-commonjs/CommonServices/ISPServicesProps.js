"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=ISPServicesProps.js.map