"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PaidAdsPerformance = void 0;
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var react_1 = require("react");
var chart_1 = require("primereact/chart");
var PaidAds_module_scss_1 = tslib_1.__importDefault(require("./PaidAds.module.scss"));
var sp_1 = require("@pnp/sp");
var DatePicker_1 = tslib_1.__importDefault(require("../DatePicker/DatePicker"));
// ─── Constants ────────────────────────────────────────────────────────────────
var PLATFORM_META = {
    Google: { color: "#e11d48", icon: "🔍", pillColor: "blue" },
    LinkedIn: { color: "#1a6ef5", icon: "💼", pillColor: "indigo" },
    Facebook: { color: "#7c3aed", icon: "📘", pillColor: "violet" },
};
// ─── Helpers ──────────────────────────────────────────────────────────────────
function fmt(n) {
    if (n >= 1000000)
        return (n / 1000000).toFixed(1).replace(/\.0$/, "") + "M";
    if (n >= 1000)
        return (n / 1000).toFixed(1).replace(/\.0$/, "") + "K";
    return n.toLocaleString("en-IN");
}
function defaultRange() {
    var today = new Date();
    today.setHours(0, 0, 0, 0);
    return {
        startDate: new Date(today.getFullYear(), today.getMonth(), 1),
        endDate: today,
        label: "This Month",
    };
}
function getCtrType(ctr) {
    if (ctr > 3)
        return "good";
    if (ctr > 1)
        return "mid";
    return "low";
}
function getStatus(status) {
    var upper = status === null || status === void 0 ? void 0 : status.toUpperCase();
    if (upper === "PAUSED")
        return "Paused";
    if (upper === "ACTIVE")
        return "Active";
    return "Brand";
}
/** Safe numeric sum of a key across an array */
function sumKey(arr, key) {
    return arr.reduce(function (acc, item) {
        var val = item[key];
        if (val === null || val === undefined)
            return acc;
        var num = parseFloat(String(val));
        return acc + (isNaN(num) ? 0 : num);
    }, 0);
}
/** Filter rows by date range (inclusive) */
function filterByRange(rows, range) {
    var from = new Date(range.startDate.getFullYear(), range.startDate.getMonth(), range.startDate.getDate()).getTime();
    var to = new Date(range.endDate.getFullYear(), range.endDate.getMonth(), range.endDate.getDate()).getTime();
    var _a = from <= to ? [from, to] : [to, from], lo = _a[0], hi = _a[1];
    return rows.filter(function (c) {
        var t = new Date(c.date.getFullYear(), c.date.getMonth(), c.date.getDate()).getTime();
        return t >= lo && t <= hi;
    });
}
function aggregateCampaigns(rows) {
    var map = new Map();
    console.log(rows, "ROWScvbnm");
    rows.forEach(function (c) {
        var _a;
        // ✅ FIX: normalize campaign name (important)
        var normalizedCampaign = (_a = c.campaignName) === null || _a === void 0 ? void 0 : _a.trim().toLowerCase();
        var key = "".concat(c.platform, "__").concat(normalizedCampaign);
        var spend = Number(c.spend) || 0;
        var impressions = Number(c.impressions) || 0;
        var clicks = Number(c.clicks) || 0;
        var leads = Number(c.leads) || 0;
        if (!map.has(key)) {
            map.set(key, {
                platform: c.platform,
                campaignName: c.campaignName, // original display name
                spend: spend,
                impressions: impressions,
                clicks: clicks,
                leads: leads,
                cpl: null,
                status: c.status,
                ctr: "0.00%",
                ctrType: "low",
            });
        }
        else {
            var ex = map.get(key);
            ex.spend += spend;
            ex.impressions += impressions;
            ex.clicks += clicks;
            ex.leads += leads;
        }
    });
    // ✅ Recalculate CTR & CPL after grouping
    map.forEach(function (row) {
        var ctrVal = row.impressions > 0
            ? parseFloat(((row.clicks / row.impressions) * 100).toFixed(2))
            : 0;
        row.ctr = "".concat(ctrVal.toFixed(2), "%");
        row.ctrType = getCtrType(ctrVal);
        row.cpl = row.cpl;
    });
    return Array.from(map.values());
}
var Pill = function (_a) {
    var children = _a.children, color = _a.color;
    return (React.createElement("span", { className: "".concat(PaidAds_module_scss_1.default.pill, " ").concat(PaidAds_module_scss_1.default["pill--".concat(color)]) }, children));
};
var KpiCard = function (_a) {
    var icon = _a.icon, label = _a.label, value = _a.value, sub = _a.sub, delta = _a.delta, deltaUp = _a.deltaUp, accentColor = _a.accentColor, iconBg = _a.iconBg;
    return (React.createElement("div", { className: PaidAds_module_scss_1.default.kpiCard },
        React.createElement("div", { className: PaidAds_module_scss_1.default.kpiCard__top },
            React.createElement("div", { className: PaidAds_module_scss_1.default.kpiCard__icon, style: { background: iconBg } }, icon),
            delta === null ? (React.createElement("span", { className: PaidAds_module_scss_1.default.kpiCard__menu }, "\u2014")) : (React.createElement("span", { className: "".concat(PaidAds_module_scss_1.default.kpiCard__delta, " ").concat(deltaUp
                    ? PaidAds_module_scss_1.default["kpiCard__delta--up"]
                    : PaidAds_module_scss_1.default["kpiCard__delta--flat"]) }, delta))),
        React.createElement("div", { className: PaidAds_module_scss_1.default.kpiCard__label }, label),
        React.createElement("div", { className: PaidAds_module_scss_1.default.kpiCard__value }, value),
        React.createElement("div", { className: PaidAds_module_scss_1.default.kpiCard__sub }, sub),
        React.createElement("div", { className: PaidAds_module_scss_1.default.kpiCard__bar, style: { background: accentColor } })));
};
var PaidAdsPerformance = function () {
    var _a = (0, react_1.useState)(defaultRange), dateRange = _a[0], setDateRange = _a[1];
    var _b = (0, react_1.useState)(false), mounted = _b[0], setMounted = _b[1];
    var _c = (0, react_1.useState)([]), googleAdsData = _c[0], setGoogleAdsData = _c[1];
    var _d = (0, react_1.useState)([]), facebookAdsData = _d[0], setFacebookAdsData = _d[1];
    (0, react_1.useEffect)(function () { return setMounted(true); }, []);
    var fetchGoogleAdsData = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var response, error_1;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, sp_1.sp.web.lists
                            .getByTitle("GoogleAds")
                            .items.select("Id", "Date", "CampaignName", "CPL", "Impressions", "Clicks", "Spend", "CTR", "Status", "Leads")
                            .orderBy("Date", false)
                            .getAll()];
                case 1:
                    response = _a.sent();
                    setGoogleAdsData(response);
                    return [3 /*break*/, 3];
                case 2:
                    error_1 = _a.sent();
                    console.error("Error fetching Google Ads data:", error_1);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var fetchFaceBookData = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var response, error_2;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, sp_1.sp.web.lists
                            .getByTitle("FacebookAds")
                            .items.select("Id", "CampaignName", "Spend", "Impressions", "Clicks", "CTR", "Leads", "CPL", "Date", "Status", "Created", "Modified")
                            .orderBy("Date", false)
                            .getAll()];
                case 1:
                    response = _a.sent();
                    setFacebookAdsData(response);
                    console.log(response, "responseresponse");
                    return [3 /*break*/, 3];
                case 2:
                    error_2 = _a.sent();
                    console.error("Error fetching Facebook Ads data:", error_2);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    (0, react_1.useEffect)(function () {
        fetchGoogleAdsData();
        fetchFaceBookData();
    }, []);
    var combinedData = (0, react_1.useMemo)(function () {
        var google = googleAdsData.map(function (item) {
            var _a, _b, _c, _d, _e, _f, _g;
            return ({
                platform: "Google",
                campaignName: item.CampaignName,
                date: new Date(item.Date),
                spend: Number((_a = item.Spend) !== null && _a !== void 0 ? _a : 0),
                impressions: Number((_b = item.Impressions) !== null && _b !== void 0 ? _b : 0),
                clicks: Number((_c = item.Clicks) !== null && _c !== void 0 ? _c : 0),
                ctr: "".concat(Number((_d = item.CTR) !== null && _d !== void 0 ? _d : 0).toFixed(2), "%"),
                ctrType: getCtrType(Number((_e = item.CTR) !== null && _e !== void 0 ? _e : 0)),
                leads: Number((_f = item.Leads) !== null && _f !== void 0 ? _f : 0),
                cpl: Number((_g = item.CPL) !== null && _g !== void 0 ? _g : 0),
                status: getStatus(item.Status),
            });
        });
        var facebook = facebookAdsData.map(function (item) {
            var _a, _b, _c, _d, _e, _f, _g;
            return ({
                platform: "Facebook",
                campaignName: item.CampaignName,
                date: new Date(item.Date),
                spend: Number((_a = item.Spend) !== null && _a !== void 0 ? _a : 0),
                impressions: Number((_b = item.Impressions) !== null && _b !== void 0 ? _b : 0),
                clicks: Number((_c = item.Clicks) !== null && _c !== void 0 ? _c : 0),
                ctr: "".concat(Number((_d = item.CTR) !== null && _d !== void 0 ? _d : 0).toFixed(2), "%"),
                ctrType: getCtrType(Number((_e = item.CTR) !== null && _e !== void 0 ? _e : 0)),
                leads: Number((_f = item.Leads) !== null && _f !== void 0 ? _f : 0),
                cpl: Number((_g = item.CPL) !== null && _g !== void 0 ? _g : 0),
                status: getStatus(item.Status),
            });
        });
        console.log(google, "google");
        console.log(facebook, "facebook");
        return tslib_1.__spreadArray(tslib_1.__spreadArray([], google, true), facebook, true);
    }, [googleAdsData, facebookAdsData]);
    var filtered = (0, react_1.useMemo)(function () {
        console.log("👉 combinedData:", combinedData);
        console.log("👉 dateRange:", dateRange);
        var result = filterByRange(combinedData, dateRange);
        console.log("👉 filtered RESULT:", result);
        return result;
    }, [combinedData, dateRange]);
    var kpis = (0, react_1.useMemo)(function () {
        var totalSpend = filtered.reduce(function (s, c) { return s + c.spend; }, 0);
        var totalImpressions = filtered.reduce(function (s, c) { return s + c.impressions; }, 0);
        var totalLeads = filtered.reduce(function (s, c) { var _a; return s + ((_a = c.leads) !== null && _a !== void 0 ? _a : 0); }, 0);
        var avgCpl = totalLeads > 0 ? Math.round(totalSpend / totalLeads) : 0;
        return { totalSpend: totalSpend, totalImpressions: totalImpressions, totalLeads: totalLeads, avgCpl: avgCpl };
    }, [filtered]);
    var campaignTable = (0, react_1.useMemo)(function () { return aggregateCampaigns(filtered); }, [filtered]);
    var spendLeadsData = (0, react_1.useMemo)(function () {
        var platforms = ["Google", "Facebook"];
        var spendByPlatform = platforms.map(function (p) {
            return Number(sumKey(filtered.filter(function (x) { return x.platform === p; }), "spend").toFixed(2));
        });
        var leadsByPlatform = platforms.map(function (p) {
            return Number(sumKey(filtered.filter(function (x) { return x.platform === p; }), "leads").toFixed(2));
        });
        return {
            labels: ["Google Ads", "Facebook Ads"],
            datasets: [
                {
                    label: "Ad Spend (₹)",
                    backgroundColor: ["#e11d48", "#7c3aed"],
                    data: spendByPlatform,
                    yAxisID: "y",
                },
                {
                    label: "Leads",
                    backgroundColor: "#6ee7b7",
                    data: leadsByPlatform,
                    yAxisID: "y1",
                },
            ],
        };
    }, [filtered]);
    var spendLeadsOptions = {
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: "top",
                labels: {
                    usePointStyle: true,
                    pointStyle: "rect",
                    padding: 20,
                    color: "#64748b",
                    font: { size: 12, weight: 500 },
                },
            },
        },
        scales: {
            x: {
                grid: { display: false },
                ticks: { color: "#64748b", font: { size: 12 } },
            },
            y: {
                position: "left",
                beginAtZero: true,
                grid: { color: "#e2e8f0" },
                ticks: {
                    callback: function (value) { return "\u20B9".concat(value / 1000, "K"); },
                    color: "#64748b",
                },
            },
            y1: {
                position: "right",
                beginAtZero: true,
                grid: { drawOnChartArea: false },
                ticks: { color: "#64748b" },
            },
        },
    };
    var cplTrendData = (0, react_1.useMemo)(function () {
        var grouped = {};
        filtered.forEach(function (item) {
            var d = new Date(item.date);
            var key = "".concat(d.getFullYear(), "-").concat(d.getMonth());
            if (!grouped[key]) {
                grouped[key] = {
                    date: new Date(d.getFullYear(), d.getMonth(), 1),
                    Google: [],
                    Facebook: [],
                };
            }
            var cplVal = Number(item.cpl);
            if (!isNaN(cplVal) && cplVal > 0) {
                if (item.platform === "Google") {
                    grouped[key].Google.push(cplVal);
                }
                else if (item.platform === "Facebook") {
                    grouped[key].Facebook.push(cplVal);
                }
            }
        });
        var sortedKeys = Object.keys(grouped).sort(function (a, b) { return grouped[a].date.getTime() - grouped[b].date.getTime(); });
        var labels = sortedKeys.map(function (k) {
            return grouped[k].date.toLocaleString("en-US", {
                month: "short",
                year: "2-digit",
            });
        });
        var sumArr = function (arr) {
            return Number(arr.reduce(function (t, v) { return t + v; }, 0).toFixed(2));
        };
        var googleData = sortedKeys.map(function (k) { return sumArr(grouped[k].Google); });
        var facebookData = sortedKeys.map(function (k) { return sumArr(grouped[k].Facebook); });
        if (labels.length === 1) {
            labels.push(labels[0]);
            googleData.push(googleData[0]);
            facebookData.push(facebookData[0]);
        }
        return {
            labels: labels,
            datasets: [
                {
                    label: "Google CPL (₹)",
                    data: googleData,
                    borderColor: "#e11d48",
                    backgroundColor: "rgba(225,29,72,0.08)",
                    fill: false,
                    tension: 0.3,
                    borderWidth: 2,
                    pointRadius: 5,
                    pointHoverRadius: 7,
                    spanGaps: true,
                },
                {
                    label: "Facebook CPL (₹)",
                    data: facebookData,
                    borderColor: "#7c3aed",
                    backgroundColor: "rgba(124,58,237,0.08)",
                    fill: false,
                    tension: 0.3,
                    borderWidth: 2,
                    pointRadius: 5,
                    pointHoverRadius: 7,
                    spanGaps: true,
                },
            ],
        };
    }, [filtered]);
    var cplTrendOptions = {
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: "top",
                labels: {
                    usePointStyle: true,
                    pointStyle: "circle",
                    padding: 20,
                    color: "#64748b",
                    font: { size: 12, weight: 500 },
                },
            },
            tooltip: {
                callbacks: {
                    label: function (context) {
                        var value = context.raw;
                        if (value === null || value === undefined)
                            return "No data";
                        return "\u20B9".concat(value);
                    },
                },
            },
        },
        scales: {
            x: {
                grid: { display: false },
                ticks: { color: "#64748b" },
            },
            y: {
                beginAtZero: true,
                grid: { color: "#e2e8f0" },
                ticks: {
                    color: "#64748b",
                    callback: function (value) { return "\u20B9".concat(value); },
                },
            },
        },
    };
    var KPI_CARDS = [
        {
            icon: "💸",
            label: "Total Ad Spend",
            value: "\u20B9".concat(fmt(kpis.totalSpend)),
            sub: "All platforms combined",
            delta: null,
            deltaUp: false,
            accentColor: "#e11d48",
            iconBg: "#fff0f3",
        },
        {
            icon: "👁",
            label: "Total Impressions",
            value: fmt(kpis.totalImpressions),
            sub: "All campaigns",
            delta: "▲ 14%",
            deltaUp: true,
            accentColor: "#1a6ef5",
            iconBg: "#e8f0fe",
        },
        {
            icon: "🎯",
            label: "Leads from Ads",
            value: String(kpis.totalLeads),
            sub: "Google + LinkedIn + FB",
            delta: "▲ 18%",
            deltaUp: true,
            accentColor: "#059669",
            iconBg: "#d1fae5",
        },
        {
            icon: "📉",
            label: "Avg Cost Per Lead",
            value: kpis.avgCpl > 0 ? "\u20B9".concat(kpis.avgCpl) : "—",
            sub: "Blended across platforms",
            delta: "▼ improving",
            deltaUp: true,
            accentColor: "#d97706",
            iconBg: "#fef3c7",
        },
    ];
    var rangeLabel = (0, react_1.useMemo)(function () {
        var startDate = dateRange.startDate, endDate = dateRange.endDate;
        if (!startDate || !endDate)
            return "All time";
        var f = function (d) {
            return d.toLocaleDateString("en-IN", {
                day: "numeric",
                month: "short",
                year: "numeric",
            });
        };
        return "".concat(f(startDate), " \u2013 ").concat(f(endDate));
    }, [dateRange]);
    return (React.createElement("div", { className: "".concat(PaidAds_module_scss_1.default.paidAds, " ").concat(mounted ? PaidAds_module_scss_1.default["paidAds--mounted"] : "") },
        React.createElement("div", { className: PaidAds_module_scss_1.default.topBar },
            React.createElement("div", { className: PaidAds_module_scss_1.default.topBar__left },
                React.createElement("span", { className: PaidAds_module_scss_1.default.topBar__title }, "Paid Ads Performance"),
                React.createElement("span", { className: PaidAds_module_scss_1.default.topBar__sep }, "\u00B7"),
                React.createElement("span", { className: PaidAds_module_scss_1.default.topBar__subs }, "Google \u00B7 LinkedIn \u00B7 Facebook \u00B7 Excel data")),
            React.createElement(DatePicker_1.default, { value: dateRange, onChange: function (range) { return setDateRange(range); }, maxDate: new Date() })),
        React.createElement("div", { className: PaidAds_module_scss_1.default.innerHeader },
            React.createElement("div", { className: PaidAds_module_scss_1.default.innerHeader__left },
                React.createElement("div", { className: PaidAds_module_scss_1.default.innerHeader__icon }, "\uD83D\uDCB0"),
                React.createElement("div", null,
                    React.createElement("div", { className: PaidAds_module_scss_1.default.innerHeader__title }, "Paid Ads Performance"),
                    React.createElement("div", { className: PaidAds_module_scss_1.default.innerHeader__sub },
                        "Google Ads \u00B7 LinkedIn Ads \u00B7 Facebook Ads \u00B7 Data from Excel \u00B7",
                        " ",
                        rangeLabel))),
            React.createElement("button", { className: PaidAds_module_scss_1.default.btnExcel }, "\uD83D\uDCCA Excel Data")),
        React.createElement("div", null,
            React.createElement("section", { className: PaidAds_module_scss_1.default.kpiStrip }, KPI_CARDS.map(function (c, i) { return (React.createElement(KpiCard, tslib_1.__assign({ key: i }, c))); })),
            React.createElement("section", { className: PaidAds_module_scss_1.default.chartsRow },
                React.createElement("div", { className: PaidAds_module_scss_1.default.chartCard },
                    React.createElement("div", { className: PaidAds_module_scss_1.default.chartCard__title }, "Spend vs Leads by Platform"),
                    React.createElement("div", { className: PaidAds_module_scss_1.default.chartCard__sub }, rangeLabel),
                    React.createElement("div", { className: PaidAds_module_scss_1.default.chartCard__canvas }, filtered.length > 0 ? (React.createElement(chart_1.Chart, { type: "bar", data: spendLeadsData, options: spendLeadsOptions, style: { height: "220px" } })) : (React.createElement("div", { className: PaidAds_module_scss_1.default.chartCard__empty }, "No data for selected range")))),
                React.createElement("div", { className: PaidAds_module_scss_1.default.chartCard },
                    React.createElement("div", { className: PaidAds_module_scss_1.default.chartCard__title }, "CPL Trend \u2014 Monthly"),
                    React.createElement("div", { className: PaidAds_module_scss_1.default.chartCard__sub }, "Cost Per Lead improving over time"),
                    React.createElement("div", { className: PaidAds_module_scss_1.default.chartCard__canvas }, filtered.length > 0 ? (React.createElement(chart_1.Chart, { type: "line", data: cplTrendData, options: cplTrendOptions, style: { height: "220px" } })) : (React.createElement("div", { className: PaidAds_module_scss_1.default.chartCard__empty }, "No data for selected range"))))),
            React.createElement("section", { className: PaidAds_module_scss_1.default.campaignTable },
                React.createElement("div", { className: PaidAds_module_scss_1.default.campaignTable__header },
                    React.createElement("div", null,
                        React.createElement("div", { className: PaidAds_module_scss_1.default.campaignTable__title }, "Campaign-Level Breakdown"),
                        React.createElement("div", { className: PaidAds_module_scss_1.default.campaignTable__sub },
                            "All active campaigns \u00B7 ",
                            rangeLabel,
                            " \u00B7 upload Excel to update"))),
                campaignTable.length === 0 ? (React.createElement("div", { className: PaidAds_module_scss_1.default.campaignTable__empty }, "\uD83D\uDCED No campaigns found for the selected date range.")) : (React.createElement("div", { className: PaidAds_module_scss_1.default.campaignTable__scroll },
                    React.createElement("table", { className: PaidAds_module_scss_1.default.tbl },
                        React.createElement("thead", null,
                            React.createElement("tr", null, [
                                "Platform",
                                "Campaign Name",
                                "Spend (₹)",
                                "Impressions",
                                "Clicks",
                                "CTR",
                                "Leads",
                                "CPL (₹)",
                                "Status",
                            ].map(function (h) { return (React.createElement("th", { key: h }, h)); }))),
                        React.createElement("tbody", null, campaignTable.map(function (r, i) { return (React.createElement("tr", { key: i },
                            React.createElement("td", null,
                                React.createElement(Pill, { color: PLATFORM_META[r.platform].pillColor }, r.platform)),
                            React.createElement("td", { className: PaidAds_module_scss_1.default["cell--name"] }, r.campaignName),
                            React.createElement("td", { className: PaidAds_module_scss_1.default["cell--num"] },
                                "\u20B9",
                                fmt(r.spend)),
                            React.createElement("td", { className: PaidAds_module_scss_1.default["cell--num"] }, fmt(r.impressions)),
                            React.createElement("td", { className: PaidAds_module_scss_1.default["cell--num"] }, fmt(r.clicks)),
                            React.createElement("td", null,
                                React.createElement(Pill, { color: r.ctrType === "good"
                                        ? "teal"
                                        : r.ctrType === "mid"
                                            ? "amber"
                                            : "gray" }, r.ctr)),
                            React.createElement("td", { className: PaidAds_module_scss_1.default["cell--leads"] }, r.leads > 0 ? (r.leads) : (React.createElement("span", { className: PaidAds_module_scss_1.default["cell--muted"] }, "\u2014"))),
                            React.createElement("td", null, r.cpl !== null ? (React.createElement(Pill, { color: r.cpl < 300
                                    ? "green"
                                    : r.cpl < 450
                                        ? "amber"
                                        : "gray" },
                                "\u20B9",
                                r.cpl)) : (React.createElement("span", { className: PaidAds_module_scss_1.default["cell--muted"] }, "\u2014"))),
                            React.createElement("td", null,
                                React.createElement(Pill, { color: r.status === "Active"
                                        ? "green"
                                        : r.status === "Paused"
                                            ? "amber"
                                            : "gray" }, r.status)))); }))))),
                React.createElement("div", { className: PaidAds_module_scss_1.default.uploadFooter },
                    React.createElement("span", null, "\uD83D\uDCCE"),
                    React.createElement("span", null, "Upload ads Excel to add/update campaigns \u00B7 Fields: Platform \u00B7 Campaign \u00B7 Spend \u00B7 Impressions \u00B7 Clicks \u00B7 Leads"))))));
};
exports.PaidAdsPerformance = PaidAdsPerformance;
exports.default = exports.PaidAdsPerformance;
//# sourceMappingURL=PaidAds.js.map