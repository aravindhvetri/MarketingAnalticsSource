"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var react_1 = require("react");
var SidNavComponets_1 = tslib_1.__importDefault(require("../SidNavComponets/SidNavComponets"));
require("../../../ExternalRef/CSS/ReportsStyle.css");
var LinkedIn_1 = tslib_1.__importDefault(require("../LinkedIn/LinkedIn"));
var EmailCampaigns_1 = tslib_1.__importDefault(require("../EmailCampaigns/EmailCampaigns"));
var WebsiteAnalytics_1 = tslib_1.__importDefault(require("../WebsiteAnalytics/WebsiteAnalytics"));
var SEOIntelligence_1 = tslib_1.__importDefault(require("../SEOIntelligence/SEOIntelligence"));
var LeadsIntelligence_1 = tslib_1.__importDefault(require("../LeadsIntelligence/LeadsIntelligence"));
var OverViewDashboard_1 = tslib_1.__importDefault(require("../OverViewDashboard/OverViewDashboard"));
var PaidAds_1 = tslib_1.__importDefault(require("../PaidAds/PaidAds"));
var MainComponent = function (props) {
    var _a = (0, react_1.useState)("overview"), activeSection = _a[0], setActiveSection = _a[1];
    var _b = (0, react_1.useState)("Marketing Overview"), pageTitle = _b[0], setPageTitle = _b[1];
    var _c = (0, react_1.useState)("All channels · TechnoRUCS"), pageSub = _c[0], setPageSub = _c[1];
    var handleNav = function (id, title, sub) {
        setActiveSection(id);
        setPageTitle(title);
        setPageSub(sub);
    };
    var renderSection = function () {
        switch (activeSection) {
            case "overview":
                return (React.createElement("div", { style: { padding: "24px 28px" } },
                    React.createElement(OverViewDashboard_1.default, null),
                    React.createElement("p", { style: { color: "#8a9bbf", fontSize: 13 } }, "Overview \u2014 Coming soon")));
            case "linkedin":
                return React.createElement(LinkedIn_1.default, null);
            case "email":
                return (React.createElement("div", null,
                    React.createElement(EmailCampaigns_1.default, null)));
            case "website":
                return (React.createElement("div", { style: { padding: "24px 28px" } },
                    React.createElement(WebsiteAnalytics_1.default, null),
                    React.createElement("p", { style: { color: "#8a9bbf", fontSize: 13 } }, "Website Analytics \u2014 Coming soon")));
            case "ads":
                return (React.createElement("div", { style: { padding: "24px 28px" } },
                    React.createElement(PaidAds_1.default, null),
                    React.createElement("p", { style: { color: "#8a9bbf", fontSize: 13 } }, "Paid Ads \u2014 Coming soon")));
            case "seo":
                return (React.createElement("div", { style: { padding: "24px 28px" } },
                    React.createElement(SEOIntelligence_1.default, null),
                    React.createElement("p", { style: { color: "#8a9bbf", fontSize: 13 } }, "SEO Intelligence \u2014 Coming soon")));
            case "leads":
                return (React.createElement("div", { style: { padding: "24px 28px" } },
                    React.createElement(LeadsIntelligence_1.default, null),
                    React.createElement("p", { style: { color: "#8a9bbf", fontSize: 13 } }, "Leads Intelligence \u2014 Coming soon")));
            default:
                return null;
        }
    };
    return (React.createElement("div", { style: { display: "flex", minHeight: "100vh", background: "#f4f6fb" } },
        React.createElement(SidNavComponets_1.default, { activeSection: activeSection, onNav: handleNav }),
        React.createElement("div", { style: {
                flex: 1,
                display: "flex",
                flexDirection: "column",
                overflow: "hidden",
            } },
            React.createElement("div", { style: { flex: 1, overflowY: "auto" } }, renderSection()))));
};
exports.default = MainComponent;
//# sourceMappingURL=DashboardComponets.js.map