"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var react_1 = require("react");
var SEOIntelligence_module_scss_1 = tslib_1.__importDefault(require("./SEOIntelligence.module.scss"));
var chart_1 = require("primereact/chart");
var sp_1 = require("@pnp/sp");
var datatable_1 = require("primereact/datatable");
var column_1 = require("primereact/column");
var MONTHS = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
];
function defaultYearMonth() {
    var now = new Date();
    return {
        year: now.getFullYear(),
        month: now.getMonth() + 1,
        label: "".concat(MONTHS[now.getMonth()], " ").concat(now.getFullYear()),
    };
}
function filterByYearMonth(items, ym) {
    return items.filter(function (item) {
        if (!item.Date)
            return true;
        var d = new Date(item.Date);
        if (isNaN(d.getTime())) {
            console.warn("Invalid date:", item.Date);
            return true;
        }
        if (d.getFullYear() !== ym.year)
            return false;
        if (ym.month !== null && d.getMonth() + 1 !== ym.month)
            return false;
        return true;
    });
}
var YearMonthPicker = function (_a) {
    var _b;
    var value = _a.value, onChange = _a.onChange, _c = _a.minYear, minYear = _c === void 0 ? 2020 : _c;
    var currentYear = new Date().getFullYear();
    var years = Array.from({ length: currentYear - minYear + 1 }, function (_, i) { return currentYear - i; });
    var handleYear = function (e) {
        var year = Number(e.target.value);
        var label = value.month
            ? "".concat(MONTHS[value.month - 1], " ").concat(year)
            : "Full Year ".concat(year);
        onChange(tslib_1.__assign(tslib_1.__assign({}, value), { year: year, label: label }));
    };
    var handleMonth = function (e) {
        var month = e.target.value === "0" ? null : Number(e.target.value);
        var label = month
            ? "".concat(MONTHS[month - 1], " ").concat(value.year)
            : "Full Year ".concat(value.year);
        onChange(tslib_1.__assign(tslib_1.__assign({}, value), { month: month, label: label }));
    };
    var chevronSvg = "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'%3E%3Cpath d='M1 1l4 4 4-4' stroke='%2394a3b8' stroke-width='1.5' fill='none' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E\")";
    var selectStyle = {
        appearance: "none",
        WebkitAppearance: "none",
        border: "none",
        background: "transparent",
        fontSize: 13,
        fontWeight: 500,
        color: "#334155",
        cursor: "pointer",
        padding: "0 20px 0 2px",
        backgroundImage: chevronSvg,
        backgroundRepeat: "no-repeat",
        backgroundPosition: "right 2px center",
        outline: "none",
    };
    return (React.createElement("div", { style: {
            display: "flex",
            alignItems: "center",
            gap: 6,
            background: "#fff",
            border: "1px solid #e2e8f0",
            borderRadius: 8,
            padding: "6px 10px",
            boxShadow: "0 1px 3px rgba(0,0,0,0.06)",
        } },
        React.createElement("span", { style: { fontSize: 14 } }, "\uD83D\uDCC5"),
        React.createElement("select", { style: selectStyle, value: value.year, onChange: handleYear }, years.map(function (y) { return (React.createElement("option", { key: y, value: y }, y)); })),
        React.createElement("span", { style: { fontSize: 13, color: "#cbd5e1", userSelect: "none" } }, "/"),
        React.createElement("select", { style: selectStyle, value: (_b = value.month) !== null && _b !== void 0 ? _b : 0, onChange: handleMonth },
            React.createElement("option", { value: 0 }, "All Months"),
            MONTHS.map(function (m, i) { return (React.createElement("option", { key: i + 1, value: i + 1 }, m)); }))));
};
var KpiCard = function (p) { return (React.createElement("div", { className: SEOIntelligence_module_scss_1.default.kpi },
    React.createElement("div", { className: SEOIntelligence_module_scss_1.default.kpiTop },
        React.createElement("div", { className: SEOIntelligence_module_scss_1.default.kpiIcon, style: { background: p.iconBg } }, p.icon),
        React.createElement("div", { className: "".concat(SEOIntelligence_module_scss_1.default.kpiDelta, " ").concat(p.deltaType === "up"
                ? SEOIntelligence_module_scss_1.default.deltaUp
                : p.deltaType === "dn"
                    ? SEOIntelligence_module_scss_1.default.deltaDn
                    : SEOIntelligence_module_scss_1.default.deltaFlat) }, p.deltaText)),
    React.createElement("div", { className: SEOIntelligence_module_scss_1.default.kpiLabel }, p.label),
    React.createElement("div", { className: SEOIntelligence_module_scss_1.default.kpiVal }, p.value),
    React.createElement("div", { className: SEOIntelligence_module_scss_1.default.kpiSub }, p.sub),
    React.createElement("div", { className: SEOIntelligence_module_scss_1.default.kpiAccent, style: { background: p.accentColor } }))); };
var RankDistChart = function (_a) {
    var data = _a.data;
    var chartData = {
        labels: data.map(function (d) { return d.label; }),
        datasets: [
            {
                label: "Top 1-10",
                data: data.map(function (d) { return d.top10; }),
                backgroundColor: "#059669",
            },
            {
                label: "11-50",
                data: data.map(function (d) { return d.rank11_50; }),
                backgroundColor: "#0891b2",
            },
            {
                label: "51-100",
                data: data.map(function (d) { return d.rank51_100; }),
                backgroundColor: "#d97706",
            },
            {
                label: "Not Ranked",
                data: data.map(function (d) { return d.notRanked; }),
                backgroundColor: "#e11d48",
            },
        ],
    };
    var options = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { position: "bottom" } },
        scales: { x: { stacked: true }, y: { stacked: true } },
    };
    return (React.createElement("div", { className: SEOIntelligence_module_scss_1.default.chartWrapper }, data.length === 0 ? (React.createElement("div", { className: SEOIntelligence_module_scss_1.default.emptyChart }, "\uD83D\uDCED No data")) : (React.createElement(chart_1.Chart, { type: "bar", data: chartData, options: options }))));
};
var BacklinkGrowthChart = function (_a) {
    var data = _a.data;
    var chartData = {
        labels: data.map(function (d) { return d.label; }),
        datasets: [
            {
                label: "Total Backlinks",
                data: data.map(function (d) { return d.backlinks; }),
                borderColor: "#1a6ef5",
                backgroundColor: "rgba(26,110,245,0.1)",
                tension: 0.4,
                fill: true,
            },
            {
                label: "Referring Domains",
                data: data.map(function (d) { return d.domains; }),
                borderColor: "#7c3aed",
                backgroundColor: "rgba(124,58,237,0.1)",
                tension: 0.4,
                fill: true,
            },
        ],
    };
    var options = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { position: "bottom" } },
    };
    return (React.createElement("div", { className: SEOIntelligence_module_scss_1.default.chartWrapper }, data.length === 0 ? (React.createElement("div", { className: SEOIntelligence_module_scss_1.default.emptyChart }, "\uD83D\uDCED No data")) : (React.createElement(chart_1.Chart, { type: "line", data: chartData, options: options }))));
};
var SeoIntelligenceDashboard = function () {
    var _a = (0, react_1.useState)(defaultYearMonth()), yearMonth = _a[0], setYearMonth = _a[1];
    var _b = (0, react_1.useState)(null), aggregated = _b[0], setAggregated = _b[1];
    var _c = (0, react_1.useState)(false), loading = _c[0], setLoading = _c[1];
    var _d = (0, react_1.useState)(""), rangeLabel = _d[0], setRangeLabel = _d[1];
    var _e = (0, react_1.useState)(null), error = _e[0], setError = _e[1];
    var _f = (0, react_1.useState)([]), keywordData = _f[0], setKeywordData = _f[1];
    var _g = (0, react_1.useState)([]), topPageData = _g[0], setTopPageData = _g[1];
    var _h = (0, react_1.useState)([]), backlinkData = _h[0], setBacklinkData = _h[1];
    var filteredKeywords = filterByYearMonth(keywordData, yearMonth);
    var prevYM = getPreviousMonth(yearMonth);
    var fetchKeywordData = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var res;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, sp_1.sp.web.lists
                        .getByTitle("SEOIntelligence-KeywordRankings")
                        .items.select("ID", "Keyword", "Clicks", "Impressions", "CTR", "AvgPosition", "Status", "Date")
                        .orderBy("Date", false)
                        .getAll()];
                case 1:
                    res = _a.sent();
                    setKeywordData(res.map(function (item) { return ({
                        ID: item.ID,
                        Keyword: item.Keyword,
                        Clicks: Number(item.Clicks || 0),
                        Impressions: Number(item.Impressions || 0),
                        CTR: Number(item.CTR || 0),
                        AvgPosition: Number(item.AvgPosition || 0),
                        Status: item.Status,
                        Date: item.Date || null,
                    }); }));
                    return [2 /*return*/];
            }
        });
    }); };
    var fetchTopPageData = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var res;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, sp_1.sp.web.lists
                        .getByTitle("SEOIntelligence-TopPagesDetails(GSC)")
                        .items.select("ID", "PageURL", "Clicks", "Impressions", "CTR", "AvgPosition", "Date")
                        .orderBy("Date", false)
                        .getAll()];
                case 1:
                    res = _a.sent();
                    setTopPageData(res.map(function (item) { return ({
                        ID: item.ID,
                        PageURL: item.PageURL,
                        Clicks: Number(item.Clicks || 0),
                        Impressions: Number(item.Impressions || 0),
                        CTR: Number(item.CTR || 0),
                        AvgPosition: Number(item.AvgPosition || 0),
                        Date: item.Date || null,
                    }); }));
                    return [2 /*return*/];
            }
        });
    }); };
    var fetchBacklinkData = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var res;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, sp_1.sp.web.lists
                        .getByTitle("SEOIntelligence-BacklinkSummary")
                        .items.select("ID", "Metric", "Value", "Notes", "Date")
                        .orderBy("Date", false)
                        .getAll()];
                case 1:
                    res = _a.sent();
                    setBacklinkData(res.map(function (item) { return ({
                        ID: item.ID,
                        Metric: item.Metric,
                        Value: item.Value || "0",
                        Notes: item.Notes,
                        Date: item.Date || null,
                    }); }));
                    return [2 /*return*/];
            }
        });
    }); };
    function getPreviousMonth(ym) {
        var year = ym.year;
        var month = (ym.month || 1) - 1;
        if (month === 0) {
            month = 12;
            year -= 1;
        }
        return {
            year: year,
            month: month,
            label: "".concat(MONTHS[month - 1], " ").concat(year),
        };
    }
    var currentKeywords = filterByYearMonth(keywordData, yearMonth);
    var previousKeywords = filterByYearMonth(keywordData, prevYM);
    var prevMap = new Map();
    previousKeywords.forEach(function (k) {
        prevMap.set(k.Keyword, k.AvgPosition);
    });
    // ─── Aggregation ──────────────────────────────────────────────────────────────
    // FIX 1: Moved entirely inside the function, added return statement,
    //         and added kwSummary building logic.
    function aggregateFromSPData(keywords, backlinks, _topPages) {
        if (!keywords.length && !backlinks.length)
            return null;
        var keywordsTop10 = keywords.filter(function (k) { return k.AvgPosition <= 10; }).length;
        var totalBacklinksObj = backlinks.find(function (k) { var _a; return ((_a = k.Metric) === null || _a === void 0 ? void 0 : _a.trim()) === "Total Backlinks"; });
        var totalBacklinks = totalBacklinksObj
            ? Number((totalBacklinksObj.Value || "0").replace(/,/g, ""))
            : 0;
        // FIX 2: These were orphaned outside the function — now correctly inside.
        var kwImprovedObj = backlinks.find(function (k) { var _a; return ((_a = k.Metric) === null || _a === void 0 ? void 0 : _a.trim()) === "KW Rank Improved"; });
        var kwImproved = kwImprovedObj
            ? Number((kwImprovedObj.Value || "0").replace(/,/g, ""))
            : 0;
        var kwDeclinedObj = backlinks.find(function (k) { var _a; return ((_a = k.Metric) === null || _a === void 0 ? void 0 : _a.trim()) === "KW Rank Declined"; });
        var kwDeclined = kwDeclinedObj
            ? Number((kwDeclinedObj.Value || "0").replace(/,/g, ""))
            : 0;
        var seoLeads = keywords.reduce(function (sum, k) { return sum + k.Clicks; }, 0);
        var rankDist = {
            top10: keywords.filter(function (k) { return k.AvgPosition <= 10; }).length,
            rank11_50: keywords.filter(function (k) { return k.AvgPosition > 10 && k.AvgPosition <= 50; }).length,
            rank51_100: keywords.filter(function (k) { return k.AvgPosition > 50 && k.AvgPosition <= 100; }).length,
            notRanked: keywords.filter(function (k) { return k.AvgPosition > 100; }).length,
        };
        var keywordRows = currentKeywords.map(function (k) {
            var prev = prevMap.get(k.Keyword);
            var prevRank = prev ? "#".concat(Math.round(prev)) : "—";
            var currRank = "#".concat(Math.round(k.AvgPosition));
            var change = 0;
            if (prev) {
                change = Math.round(prev - k.AvgPosition); // improvement = positive
            }
            return {
                keyword: k.Keyword,
                prevRank: prevRank,
                currRank: currRank,
                change: change,
                volume: k.Impressions.toLocaleString(),
                status: change > 0 ? "Improved" : change < 0 ? "Declined" : "Unchanged",
            };
        });
        var backlinkMetrics = backlinks.map(function (b) { return ({
            label: b.Metric,
            value: String(b.Value),
            isDelta: false,
            deltaUp: false,
        }); });
        var rankDistMonths = [
            tslib_1.__assign({ label: "Current" }, rankDist),
        ];
        var backlinkTrend = [
            { label: "Current", backlinks: totalBacklinks, domains: 0 },
        ];
        // FIX 3: kwSummary was never built — now correctly constructed.
        var kwSummary = {
            improved: kwImproved,
            declined: kwDeclined,
            unchanged: Math.max(0, keywords.length - kwImproved - kwDeclined),
        };
        // FIX 4: Added the missing return statement.
        return {
            keywordsTop10: keywordsTop10,
            totalBacklinks: totalBacklinks,
            kwImproved: kwImproved,
            seoLeads: seoLeads,
            rankDist: rankDist,
            rankDistMonths: rankDistMonths,
            backlinkTrend: backlinkTrend,
            backlinkMetrics: backlinkMetrics,
            kwSummary: kwSummary,
            keywordRows: keywordRows,
        };
    }
    // FIX 5: Initial fetch used a comma expression instead of Promise.all.
    (0, react_1.useEffect)(function () {
        var initialFetch = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
            var err_1;
            return tslib_1.__generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        _a.trys.push([0, 2, 3, 4]);
                        setLoading(true);
                        return [4 /*yield*/, Promise.all([
                                fetchKeywordData(),
                                fetchTopPageData(),
                                fetchBacklinkData(),
                            ])];
                    case 1:
                        _a.sent();
                        return [3 /*break*/, 4];
                    case 2:
                        err_1 = _a.sent();
                        console.error("Initial fetch error:", err_1);
                        setError("Failed to load data");
                        return [3 /*break*/, 4];
                    case 3:
                        setLoading(false);
                        return [7 /*endfinally*/];
                    case 4: return [2 /*return*/];
                }
            });
        }); };
        initialFetch();
    }, []);
    var handleRefresh = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var err_2;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, 3, 4]);
                    setLoading(true);
                    setError(null);
                    return [4 /*yield*/, Promise.all([
                            fetchKeywordData(),
                            fetchTopPageData(),
                            fetchBacklinkData(),
                        ])];
                case 1:
                    _a.sent();
                    return [3 /*break*/, 4];
                case 2:
                    err_2 = _a.sent();
                    console.error("Refresh error:", err_2);
                    setError("Failed to refresh data");
                    return [3 /*break*/, 4];
                case 3:
                    setLoading(false);
                    return [7 /*endfinally*/];
                case 4: return [2 /*return*/];
            }
        });
    }); };
    (0, react_1.useEffect)(function () {
        setLoading(true);
        var timer = setTimeout(function () {
            var filteredKeywords = filterByYearMonth(keywordData, yearMonth);
            var filteredBacklinks = filterByYearMonth(backlinkData, yearMonth);
            var filteredTopPages = filterByYearMonth(topPageData, yearMonth);
            var agg = aggregateFromSPData(filteredKeywords, filteredBacklinks, filteredTopPages);
            setAggregated(agg);
            setRangeLabel(yearMonth.label);
            setLoading(false);
        }, 250);
        return function () { return clearTimeout(timer); };
    }, [yearMonth, keywordData, backlinkData, topPageData]);
    var noData = !aggregated;
    return (React.createElement("div", { className: SEOIntelligence_module_scss_1.default.seoDashboard },
        React.createElement("div", { className: SEOIntelligence_module_scss_1.default.topHeader },
            React.createElement("div", null,
                React.createElement("div", { className: SEOIntelligence_module_scss_1.default.topTitle }, "SEO Intelligence"),
                React.createElement("div", { className: SEOIntelligence_module_scss_1.default.topSub }, "GSC + Excel \u00B7 Keyword & backlink data")),
            React.createElement("div", { className: SEOIntelligence_module_scss_1.default.topRight },
                React.createElement("div", { className: SEOIntelligence_module_scss_1.default.secActions },
                    React.createElement(YearMonthPicker, { value: yearMonth, onChange: setYearMonth, minYear: 2020 }),
                    React.createElement("span", { className: "".concat(SEOIntelligence_module_scss_1.default.sourceBadge, " ").concat(SEOIntelligence_module_scss_1.default.badgeBlue) }, "\uD83D\uDD17 GSC Connected"),
                    React.createElement("button", { className: SEOIntelligence_module_scss_1.default.topBtnPrimary, onClick: handleRefresh }, "Refresh")))),
        React.createElement("div", { className: SEOIntelligence_module_scss_1.default.secHeader },
            React.createElement("div", { className: SEOIntelligence_module_scss_1.default.secTitleWrap },
                React.createElement("div", { className: SEOIntelligence_module_scss_1.default.secIcon, style: { background: "#fef3c7" } }, "\uD83D\uDD0D"),
                React.createElement("div", null,
                    React.createElement("div", { className: SEOIntelligence_module_scss_1.default.secTitle }, "SEO Performance"),
                    React.createElement("div", { className: SEOIntelligence_module_scss_1.default.secSub },
                        "Google Search Console \u00B7 ",
                        rangeLabel))),
            React.createElement("span", { className: "".concat(SEOIntelligence_module_scss_1.default.sourceBadge, " ").concat(SEOIntelligence_module_scss_1.default.badgeGreen) }, "\uD83D\uDCCA Excel")),
        error && React.createElement("div", null,
            "\u26A0\uFE0F ",
            error),
        loading && (React.createElement("div", { className: SEOIntelligence_module_scss_1.default.loadingBar },
            React.createElement("div", { className: SEOIntelligence_module_scss_1.default.loadingFill }))),
        React.createElement("div", { className: SEOIntelligence_module_scss_1.default.g4 },
            React.createElement(KpiCard, { icon: "\uD83D\uDCC8", iconBg: "#d1fae5", accentColor: "#059669", deltaText: noData ? "—" : "\u25B2 ".concat(aggregated.keywordsTop10, " keywords"), deltaType: noData ? "flat" : "up", label: "Keywords Top-10", value: noData ? "—" : String(aggregated.keywordsTop10), sub: "Ranking page 1" }),
            React.createElement(KpiCard, { icon: "\uD83D\uDD17", iconBg: "#e8f0fe", accentColor: "#1a6ef5", deltaText: noData
                    ? "—"
                    : "\u25B2 Latest ".concat(aggregated.totalBacklinks.toLocaleString()), deltaType: noData ? "flat" : "up", label: "Total Backlinks", value: noData ? "—" : aggregated.totalBacklinks.toLocaleString(), sub: "Acquired in range" }),
            React.createElement(KpiCard, { icon: "\u2B06\uFE0F", iconBg: "#fef3c7", accentColor: "#d97706", deltaText: noData ? "—" : "\u25B2 ".concat(aggregated.kwImproved, " improved"), deltaType: noData ? "flat" : "up", label: "Kw Rank Improved", value: noData ? "—" : String(aggregated.kwImproved), sub: "vs previous period" }),
            React.createElement(KpiCard, { icon: "\uD83C\uDFAF", iconBg: "#e0f5fa", accentColor: "#0891b2", deltaText: noData ? "—" : "\u25B2 ".concat(aggregated.seoLeads, " leads"), deltaType: noData ? "flat" : "up", label: "SEO Leads", value: noData ? "—" : aggregated.seoLeads.toLocaleString(), sub: "Organic conversions" })),
        React.createElement("div", { className: "".concat(SEOIntelligence_module_scss_1.default.g2, " ").concat(SEOIntelligence_module_scss_1.default.mt) },
            React.createElement("div", { className: SEOIntelligence_module_scss_1.default.card },
                React.createElement("div", { className: SEOIntelligence_module_scss_1.default.cardHead },
                    React.createElement("div", null,
                        React.createElement("div", { className: SEOIntelligence_module_scss_1.default.cardTitle }, "Keyword Rank Distribution"),
                        React.createElement("div", { className: SEOIntelligence_module_scss_1.default.cardSub },
                            "How keywords are spread across positions \u00B7 ",
                            yearMonth.label))),
                React.createElement(RankDistChart, { data: noData ? [] : aggregated.rankDistMonths })),
            React.createElement("div", { className: SEOIntelligence_module_scss_1.default.card },
                React.createElement("div", { className: SEOIntelligence_module_scss_1.default.cardHead },
                    React.createElement("div", null,
                        React.createElement("div", { className: SEOIntelligence_module_scss_1.default.cardTitle }, "Backlink Growth"),
                        React.createElement("div", { className: SEOIntelligence_module_scss_1.default.cardSub },
                            "Total backlinks vs referring domains \u00B7 ",
                            yearMonth.label))),
                React.createElement(BacklinkGrowthChart, { data: noData ? [] : aggregated.backlinkTrend }))),
        React.createElement("div", { className: "".concat(SEOIntelligence_module_scss_1.default.g2, " ").concat(SEOIntelligence_module_scss_1.default.mt) },
            React.createElement("div", { className: SEOIntelligence_module_scss_1.default.card },
                React.createElement("div", { className: SEOIntelligence_module_scss_1.default.cardHead },
                    React.createElement("div", null,
                        React.createElement("div", { className: SEOIntelligence_module_scss_1.default.cardTitle }, "Keyword Rankings Detail"),
                        React.createElement("div", { className: SEOIntelligence_module_scss_1.default.cardSub },
                            "Top commercial-intent keywords \u00B7 ",
                            yearMonth.label))),
                noData ? (React.createElement("div", { className: SEOIntelligence_module_scss_1.default.emptyState }, "\uD83D\uDCED No data found for selected period.")) : (React.createElement(datatable_1.DataTable, { value: (aggregated === null || aggregated === void 0 ? void 0 : aggregated.keywordRows) || [], paginator: true, rows: 10 },
                    React.createElement(column_1.Column, { field: "keyword", header: "Keyword" }),
                    React.createElement(column_1.Column, { field: "prevRank", header: "Prev Rank" }),
                    React.createElement(column_1.Column, { field: "currRank", header: "Curr Rank" }),
                    React.createElement(column_1.Column, { field: "change", header: "Change", body: function (rowData) {
                            var isUp = rowData.change > 0;
                            return (React.createElement("span", { className: "".concat(SEOIntelligence_module_scss_1.default.delta, " ").concat(isUp ? SEOIntelligence_module_scss_1.default.deltaUp : rowData.change < 0 ? SEOIntelligence_module_scss_1.default.deltaDn : SEOIntelligence_module_scss_1.default.deltaFlat) }, isUp
                                ? "\u25B2+".concat(rowData.change)
                                : rowData.change < 0
                                    ? "\u25BC".concat(rowData.change)
                                    : "—"));
                        } }),
                    React.createElement(column_1.Column, { field: "volume", header: "Volume" }),
                    React.createElement(column_1.Column, { field: "status", header: "Status", body: function (rowData) {
                            var statusClass = rowData.status === "Improved"
                                ? SEOIntelligence_module_scss_1.default.pillGreen
                                : rowData.status === "Declined"
                                    ? SEOIntelligence_module_scss_1.default.pillRose
                                    : SEOIntelligence_module_scss_1.default.pillGray;
                            return (React.createElement("span", { className: "".concat(SEOIntelligence_module_scss_1.default.pill, " ").concat(statusClass) }, rowData.status));
                        } })))),
            React.createElement("div", { className: SEOIntelligence_module_scss_1.default.card },
                React.createElement("div", { className: SEOIntelligence_module_scss_1.default.cardHead },
                    React.createElement("div", null,
                        React.createElement("div", { className: SEOIntelligence_module_scss_1.default.cardTitle }, "Backlinks \u2014 Selected Period"),
                        React.createElement("div", { className: SEOIntelligence_module_scss_1.default.cardSub },
                            "Quality & growth metrics \u00B7 ",
                            yearMonth.label))),
                noData ? (React.createElement("div", { className: SEOIntelligence_module_scss_1.default.emptyState }, "\uD83D\uDCED No data found for selected period.")) : (React.createElement(React.Fragment, null,
                    aggregated.backlinkMetrics.map(function (m, i) { return (React.createElement("div", { className: SEOIntelligence_module_scss_1.default.miniM, key: i },
                        React.createElement("span", { className: SEOIntelligence_module_scss_1.default.miniLabel }, m.label),
                        React.createElement("span", { className: "".concat(SEOIntelligence_module_scss_1.default.miniVal, " ").concat(m.isDelta ? (m.deltaUp ? SEOIntelligence_module_scss_1.default.deltaUp : SEOIntelligence_module_scss_1.default.deltaDn) : "") }, m.value))); }),
                    React.createElement("div", { className: SEOIntelligence_module_scss_1.default.divider }),
                    React.createElement("div", { className: SEOIntelligence_module_scss_1.default.cardHead, style: { marginBottom: 8 } },
                        React.createElement("div", { className: SEOIntelligence_module_scss_1.default.cardTitle }, "Keywords Improved vs Declined")),
                    React.createElement("div", { className: SEOIntelligence_module_scss_1.default.kwSummaryRow },
                        React.createElement("div", { className: "".concat(SEOIntelligence_module_scss_1.default.kwSummaryBox, " ").concat(SEOIntelligence_module_scss_1.default.kwSummaryGreen) },
                            React.createElement("div", { className: SEOIntelligence_module_scss_1.default.kwSummaryNum, style: { color: "#059669" } }, aggregated.kwSummary.improved),
                            React.createElement("div", { className: SEOIntelligence_module_scss_1.default.kwSummaryLbl, style: { color: "#059669" } }, "Keywords \u25B2 Improved")),
                        React.createElement("div", { className: "".concat(SEOIntelligence_module_scss_1.default.kwSummaryBox, " ").concat(SEOIntelligence_module_scss_1.default.kwSummaryRose) },
                            React.createElement("div", { className: SEOIntelligence_module_scss_1.default.kwSummaryNum, style: { color: "#e11d48" } }, aggregated.kwSummary.declined),
                            React.createElement("div", { className: SEOIntelligence_module_scss_1.default.kwSummaryLbl, style: { color: "#e11d48" } }, "Keywords \u25BC Declined")),
                        React.createElement("div", { className: "".concat(SEOIntelligence_module_scss_1.default.kwSummaryBox, " ").concat(SEOIntelligence_module_scss_1.default.kwSummaryGray) },
                            React.createElement("div", { className: SEOIntelligence_module_scss_1.default.kwSummaryNum, style: { color: "#4a5a7a" } }, aggregated.kwSummary.unchanged),
                            React.createElement("div", { className: SEOIntelligence_module_scss_1.default.kwSummaryLbl, style: { color: "#8a9bbf" } }, "Unchanged")))))))));
};
exports.default = SeoIntelligenceDashboard;
//# sourceMappingURL=SEOIntelligence.js.map