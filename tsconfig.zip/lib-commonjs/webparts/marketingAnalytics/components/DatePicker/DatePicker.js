"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var react_1 = require("react");
var DatePicker_module_scss_1 = tslib_1.__importDefault(require("./DatePicker.module.scss"));
function today() {
    var d = new Date();
    d.setHours(0, 0, 0, 0);
    return d;
}
function sameDay(a, b) {
    return (a.getFullYear() === b.getFullYear() &&
        a.getMonth() === b.getMonth() &&
        a.getDate() === b.getDate());
}
function fmtDisplay(dt) {
    return dt.toLocaleDateString("en-IN", {
        month: "short",
        day: "numeric",
        year: "numeric",
    });
}
function fmtInput(dt) {
    var pad = function (n) { return (n < 10 ? "0" + n : n.toString()); };
    return "".concat(pad(dt.getDate()), "/").concat(pad(dt.getMonth() + 1), "/").concat(dt.getFullYear());
}
function parseInput(val) {
    var parts = val.split("/");
    if (parts.length === 3) {
        var d = parseInt(parts[0]), m = parseInt(parts[1]) - 1, y = parseInt(parts[2]);
        var dt = new Date(y, m, d);
        if (!isNaN(dt.getTime()))
            return dt;
    }
    return null;
}
var DAY_NAMES = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"];
var MONTH_NAMES = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December",
];
function buildPreset(key) {
    var t = today();
    switch (key) {
        case "today":
            return { startDate: t, endDate: t, label: "Today" };
        case "yesterday": {
            var y = new Date(t);
            y.setDate(y.getDate() - 1);
            return { startDate: y, endDate: y, label: "Yesterday" };
        }
        case "7d": {
            var s = new Date(t);
            s.setDate(s.getDate() - 6);
            return { startDate: s, endDate: t, label: "Last 7 Days" };
        }
        case "this_month": {
            var s = new Date(t.getFullYear(), t.getMonth(), 1);
            return { startDate: s, endDate: t, label: "This Month" };
        }
        case "last_month": {
            var s = new Date(t.getFullYear(), t.getMonth() - 1, 1);
            var e = new Date(t.getFullYear(), t.getMonth(), 0);
            return { startDate: s, endDate: e, label: "Last Month" };
        }
        default:
            return buildPreset("this_month");
    }
}
var DateRangePicker = function (_a) {
    var value = _a.value, onChange = _a.onChange, maxDate = _a.maxDate, minDate = _a.minDate;
    var defaultRange = buildPreset("this_month");
    var _b = (0, react_1.useState)(value !== null && value !== void 0 ? value : defaultRange), range = _b[0], setRange = _b[1];
    var _c = (0, react_1.useState)(false), open = _c[0], setOpen = _c[1];
    var _d = (0, react_1.useState)(range.startDate.getFullYear()), viewYear = _d[0], setViewYear = _d[1];
    var _e = (0, react_1.useState)(range.startDate.getMonth()), viewMonth = _e[0], setViewMonth = _e[1];
    var _f = (0, react_1.useState)(range.startDate), tempStart = _f[0], setTempStart = _f[1];
    var _g = (0, react_1.useState)(range.endDate), tempEnd = _g[0], setTempEnd = _g[1];
    // ✅ FIX: Use a single clear step: "start" = waiting for first click, "end" = waiting for second
    var _h = (0, react_1.useState)("start"), step = _h[0], setStep = _h[1];
    var _j = (0, react_1.useState)(fmtInput(range.startDate)), startInput = _j[0], setStartInput = _j[1];
    var _k = (0, react_1.useState)(fmtInput(range.endDate)), endInput = _k[0], setEndInput = _k[1];
    var _l = (0, react_1.useState)("this_month"), activePreset = _l[0], setActivePreset = _l[1];
    var pickerRef = (0, react_1.useRef)(null);
    (0, react_1.useEffect)(function () {
        if (value) {
            setRange(value);
            setTempStart(value.startDate);
            setTempEnd(value.endDate);
            setStartInput(fmtInput(value.startDate));
            setEndInput(fmtInput(value.endDate));
        }
    }, [value]);
    (0, react_1.useEffect)(function () {
        var handler = function (e) {
            if (pickerRef.current && !pickerRef.current.contains(e.target)) {
                setOpen(false);
            }
        };
        if (open)
            document.addEventListener("mousedown", handler);
        return function () { return document.removeEventListener("mousedown", handler); };
    }, [open]);
    var toggle = function () {
        if (!open) {
            setTempStart(range.startDate);
            setTempEnd(range.endDate);
            setStartInput(fmtInput(range.startDate));
            setEndInput(fmtInput(range.endDate));
            setViewYear(range.startDate.getFullYear());
            setViewMonth(range.startDate.getMonth());
            setStep("start"); // ✅ Always reset to "start" when opening
        }
        setOpen(function (p) { return !p; });
    };
    var applyPreset = function (key) {
        var preset = buildPreset(key);
        setTempStart(preset.startDate);
        setTempEnd(preset.endDate);
        setStartInput(fmtInput(preset.startDate));
        setEndInput(fmtInput(preset.endDate));
        setViewYear(preset.startDate.getFullYear());
        setViewMonth(preset.startDate.getMonth());
        setActivePreset(key);
        setStep("start"); // ✅ Reset step after preset
    };
    // ✅ FIX: Wrap in useCallback with ALL dependencies listed
    var onDayClick = (0, react_1.useCallback)(function (day) {
        if (step === "start") {
            // First click → set both start and end to same day, wait for end
            setTempStart(day);
            setTempEnd(day);
            setStartInput(fmtInput(day));
            setEndInput(fmtInput(day));
            setActivePreset("");
            setStep("end");
        }
        else {
            // Second click → finalize the range
            if (day < tempStart) {
                // Clicked before start → swap
                setTempStart(day);
                setTempEnd(tempStart);
                setStartInput(fmtInput(day));
                setEndInput(fmtInput(tempStart));
            }
            else {
                setTempEnd(day);
                setEndInput(fmtInput(day));
            }
            setActivePreset("");
            setStep("start"); // ✅ Reset back to "start" for next interaction
        }
    }, [step, tempStart] // ✅ Correct dependencies — no stale closures
    );
    var onStartInput = function (val) {
        setStartInput(val);
        setActivePreset("");
        var parsed = parseInput(val);
        if (parsed) {
            setTempStart(parsed);
            setViewYear(parsed.getFullYear());
            setViewMonth(parsed.getMonth());
        }
    };
    var onEndInput = function (val) {
        setEndInput(val);
        setActivePreset("");
        var parsed = parseInput(val);
        if (parsed)
            setTempEnd(parsed);
    };
    var apply = function () {
        var start = tempStart;
        var end = tempEnd !== null && tempEnd !== void 0 ? tempEnd : tempStart;
        var isSingleDay = sameDay(start, end);
        var newRange = {
            startDate: start,
            endDate: end,
            label: activePreset
                ? buildPreset(activePreset).label
                : isSingleDay
                    ? fmtDisplay(start)
                    : "".concat(fmtDisplay(start), " \u2013 ").concat(fmtDisplay(end)),
        };
        setRange(newRange);
        onChange === null || onChange === void 0 ? void 0 : onChange(newRange);
        setOpen(false);
        setStep("start"); // ✅ Reset step on apply
    };
    var cancel = function () {
        setOpen(false);
        setStep("start"); // ✅ Reset step on cancel
    };
    var shiftMonth = function (dir) {
        var m = viewMonth + dir;
        var y = viewYear;
        if (m < 0) {
            m = 11;
            y--;
        }
        if (m > 11) {
            m = 0;
            y++;
        }
        setViewMonth(m);
        setViewYear(y);
    };
    // ✅ FIX: onDayClick is now in the dependency array
    var buildDays = (0, react_1.useCallback)(function () {
        var firstDay = new Date(viewYear, viewMonth, 1).getDay();
        var daysInMonth = new Date(viewYear, viewMonth + 1, 0).getDate();
        var daysInPrev = new Date(viewYear, viewMonth, 0).getDate();
        var cells = [];
        var t = today();
        for (var i = firstDay - 1; i >= 0; i--) {
            var d = new Date(viewYear, viewMonth - 1, daysInPrev - i);
            cells.push(React.createElement("div", { key: "prev-".concat(i), className: "".concat(DatePicker_module_scss_1.default.drDay, " ").concat(DatePicker_module_scss_1.default.otherMonth) }, d.getDate()));
        }
        var _loop_1 = function (day) {
            var d = new Date(viewYear, viewMonth, day);
            var isStart = sameDay(d, tempStart);
            var isEnd = sameDay(d, tempEnd);
            var inRange = d >= tempStart && d <= tempEnd;
            var isToday = sameDay(d, t);
            var isDisabled = (maxDate && d > maxDate) || (minDate && d < minDate);
            var cls = DatePicker_module_scss_1.default.drDay;
            if (isStart)
                cls += " ".concat(DatePicker_module_scss_1.default.selectedStart);
            if (isEnd)
                cls += " ".concat(DatePicker_module_scss_1.default.selectedEnd);
            if (inRange && !isStart && !isEnd)
                cls += " ".concat(DatePicker_module_scss_1.default.inRange);
            if (isToday)
                cls += " ".concat(DatePicker_module_scss_1.default.todayDay);
            if (isDisabled)
                cls += " ".concat(DatePicker_module_scss_1.default.disabled);
            cells.push(React.createElement("div", { key: day, className: cls, onClick: function () { return !isDisabled && onDayClick(d); } }, day));
        };
        for (var day = 1; day <= daysInMonth; day++) {
            _loop_1(day);
        }
        return cells;
    }, [viewYear, viewMonth, tempStart, tempEnd, maxDate, minDate, onDayClick]); // ✅ onDayClick added
    var displayLabel = range.label || "Select Range";
    var displayRange = sameDay(range.startDate, range.endDate)
        ? fmtDisplay(range.startDate)
        : "".concat(fmtDisplay(range.startDate), " \u2013 ").concat(fmtDisplay(range.endDate));
    return (React.createElement("div", { className: DatePicker_module_scss_1.default.drPicker, ref: pickerRef },
        React.createElement("div", { className: "".concat(DatePicker_module_scss_1.default.drTrigger, " ").concat(open ? DatePicker_module_scss_1.default.open : ""), onClick: toggle, role: "button", "aria-haspopup": "true", "aria-expanded": open },
            React.createElement("span", { className: DatePicker_module_scss_1.default.drCalIcon }, "\uD83D\uDCC5"),
            React.createElement("div", { className: DatePicker_module_scss_1.default.drLabel },
                React.createElement("div", { className: DatePicker_module_scss_1.default.drLabelText }, displayLabel),
                React.createElement("div", { className: DatePicker_module_scss_1.default.drRangeDisplay }, displayRange)),
            React.createElement("span", { className: DatePicker_module_scss_1.default.drChevron }, "\u25BC")),
        open && (React.createElement("div", { className: "".concat(DatePicker_module_scss_1.default.drDropdown, " ").concat(DatePicker_module_scss_1.default.open) },
            React.createElement("div", { className: DatePicker_module_scss_1.default.drLayout },
                React.createElement("div", { className: DatePicker_module_scss_1.default.drPresets },
                    React.createElement("div", { className: DatePicker_module_scss_1.default.drPresetGroup }, "Quick Select"),
                    [
                        { key: "today", label: "Today" },
                        { key: "yesterday", label: "Yesterday" },
                        { key: "7d", label: "Last 7 Days" },
                    ].map(function (p) { return (React.createElement("button", { key: p.key, className: "".concat(DatePicker_module_scss_1.default.drPresetItem, " ").concat(activePreset === p.key ? DatePicker_module_scss_1.default.active : ""), onClick: function () { return applyPreset(p.key); } }, p.label)); }),
                    React.createElement("div", { className: DatePicker_module_scss_1.default.drPresetGroup }, "Month"),
                    [
                        { key: "this_month", label: "This Month" },
                        { key: "last_month", label: "Last Month" },
                    ].map(function (p) { return (React.createElement("button", { key: p.key, className: "".concat(DatePicker_module_scss_1.default.drPresetItem, " ").concat(activePreset === p.key ? DatePicker_module_scss_1.default.active : ""), onClick: function () { return applyPreset(p.key); } }, p.label)); }),
                    React.createElement("div", { className: DatePicker_module_scss_1.default.drPresetGroup }, "Custom"),
                    React.createElement("button", { className: "".concat(DatePicker_module_scss_1.default.drPresetItem, " ").concat(activePreset === "" && step === "end" ? DatePicker_module_scss_1.default.active : ""), onClick: function () {
                            setActivePreset("");
                            setStep("start"); // ✅ Reset to start when clicking Custom Range
                        } }, "Custom Range")),
                React.createElement("div", { className: DatePicker_module_scss_1.default.drCalendars },
                    React.createElement("div", { className: DatePicker_module_scss_1.default.drCalHeader },
                        React.createElement("div", { className: DatePicker_module_scss_1.default.drMonthNav },
                            React.createElement("button", { className: DatePicker_module_scss_1.default.drNavBtn, onClick: function () { return shiftMonth(-1); } }, "\u2039"),
                            React.createElement("div", { className: DatePicker_module_scss_1.default.drMonthLabel },
                                MONTH_NAMES[viewMonth],
                                " ",
                                viewYear),
                            React.createElement("button", { className: DatePicker_module_scss_1.default.drNavBtn, onClick: function () { return shiftMonth(1); } }, "\u203A")),
                        React.createElement("span", { className: DatePicker_module_scss_1.default.selectHint }, step === "start" ? "Pick start date" : "Pick end date")),
                    React.createElement("div", { className: DatePicker_module_scss_1.default.drCalGrid },
                        DAY_NAMES.map(function (d) { return (React.createElement("div", { key: d, className: DatePicker_module_scss_1.default.drDayName }, d)); }),
                        buildDays()))),
            React.createElement("div", { className: DatePicker_module_scss_1.default.drFooter },
                React.createElement("div", { className: DatePicker_module_scss_1.default.drRangeInputs },
                    React.createElement("div", { className: DatePicker_module_scss_1.default.drInputWrap },
                        React.createElement("div", { className: DatePicker_module_scss_1.default.drInputLabel }, "Start Date"),
                        React.createElement("input", { className: DatePicker_module_scss_1.default.drInput, type: "text", value: startInput, placeholder: "DD/MM/YYYY", onChange: function (e) { return onStartInput(e.target.value); } })),
                    React.createElement("div", { className: DatePicker_module_scss_1.default.drArrow }, "\u2192"),
                    React.createElement("div", { className: DatePicker_module_scss_1.default.drInputWrap },
                        React.createElement("div", { className: DatePicker_module_scss_1.default.drInputLabel }, "End Date"),
                        React.createElement("input", { className: DatePicker_module_scss_1.default.drInput, type: "text", value: endInput, placeholder: "DD/MM/YYYY", onChange: function (e) { return onEndInput(e.target.value); } }))),
                React.createElement("div", { className: DatePicker_module_scss_1.default.drFooterBtns },
                    React.createElement("button", { className: DatePicker_module_scss_1.default.drCancel, onClick: cancel }, "Cancel"),
                    React.createElement("button", { className: DatePicker_module_scss_1.default.drApply, onClick: apply }, "Apply Range")))))));
};
exports.default = DateRangePicker;
//# sourceMappingURL=DatePicker.js.map