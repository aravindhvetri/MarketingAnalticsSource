"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
require("../../../ExternalRef/CSS/ReportsStyle.css");
var DashboardComponets_1 = tslib_1.__importDefault(require("../DashboardComponets/DashboardComponets"));
var MainComponent = function (props) {
    return (React.createElement("div", null,
        React.createElement(DashboardComponets_1.default, null)));
};
exports.default = MainComponent;
//# sourceMappingURL=MainComponents.js.map