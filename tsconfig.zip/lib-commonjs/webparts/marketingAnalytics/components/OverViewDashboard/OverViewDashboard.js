"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var react_1 = require("react");
var chart_js_1 = require("chart.js");
var OverViewDashboard_module_scss_1 = tslib_1.__importDefault(require("./OverViewDashboard.module.scss"));
chart_js_1.Chart.register(chart_js_1.BarController, chart_js_1.LineController, chart_js_1.DoughnutController, chart_js_1.BarElement, chart_js_1.LineElement, chart_js_1.ArcElement, chart_js_1.PointElement, chart_js_1.LinearScale, chart_js_1.CategoryScale, chart_js_1.Legend, chart_js_1.Tooltip, chart_js_1.Filler);
chart_js_1.Chart.defaults.font.family = "'Plus Jakarta Sans', 'Segoe UI', sans-serif";
chart_js_1.Chart.defaults.font.size = 11;
chart_js_1.Chart.defaults.color = "#8a9bbf";
var SUMMARY_BAND = [
    { id: "totalLeads", value: "628", label: "Total Leads" },
    { id: "sessions", value: "41.3K", label: "Website Users" },
    { id: "adSpend", value: "₹83K", label: "Ad Spend" },
    { id: "convRate", value: "1.36%", label: "Conv. Rate" },
    { id: "cpl", value: "₹312", label: "Avg CPL" },
    { id: "qualLeads", value: "184", label: "Qualified Leads" },
];
var KPI_CARDS = [
    {
        icon: "💼", iconBg: "#e8f0fe", accentColor: "#1a6ef5",
        deltaText: "▲ 28%", deltaType: "up",
        label: "LinkedIn Followers", value: "12,840", sub: "+820 gained this month",
    },
    {
        icon: "📧", iconBg: "#d1fae5", accentColor: "#059669",
        deltaText: "▲ 41.9%", deltaType: "up",
        label: "Email Open Rate", value: "42%", sub: "Industry avg 21.5%",
    },
    {
        icon: "🌐", iconBg: "#e0f5fa", accentColor: "#0891b2",
        deltaText: "▲ 23%", deltaType: "up",
        label: "Total Website Users", value: "41.3K", sub: "Unique visitors · GA4",
    },
    {
        icon: "💰", iconBg: "#ffe4e6", accentColor: "#e11d48",
        deltaText: "▼ CPL ₹312", deltaType: "dn",
        label: "Ads Leads", value: "305", sub: "Google + LinkedIn Ads",
    },
];
var CHANNEL_SCORES = [
    { icon: "💼", label: "LinkedIn Organic", score: 87, color: "#1a6ef5" },
    { icon: "🔍", label: "SEO / GSC", score: 74, color: "#0891b2" },
    { icon: "📧", label: "Email Campaigns", score: 81, color: "#059669" },
    { icon: "💰", label: "Google Ads", score: 69, color: "#d97706" },
    { icon: "💰", label: "LinkedIn Ads", score: 58, color: "#ea580c" },
];
var TOP_CAMPAIGNS = [
    { icon: "🗂", label: "SharePoint Migration EOL", value: 184 },
    { icon: "🤖", label: "Copilot Studio Awareness", value: 112 },
    { icon: "⚡", label: "Power Platform — Mfg", value: 96 },
    { icon: "☁️", label: "Azure Migration Bundle", value: 84 },
    { icon: "📋", label: "Dynamics 365 Webinar", value: 80 },
    { icon: "📊", label: "Salesforce CRM Promo", value: 72 },
];
var LEAD_SOURCE_STATS = [
    { value: "305", label: "Ads", color: "#1a6ef5" },
    { value: "158", label: "Email", color: "#059669" },
    { value: "165", label: "Organic", color: "#0891b2" },
];
var LeadsTrendChart = function () {
    var canvasRef = (0, react_1.useRef)(null);
    var chartRef = (0, react_1.useRef)(null);
    var wrapperRef = (0, react_1.useRef)(null);
    (0, react_1.useEffect)(function () {
        if (!canvasRef.current)
            return;
        if (chartRef.current) {
            chartRef.current.destroy();
            chartRef.current = null;
        }
        var canvas = canvasRef.current;
        canvas.width = wrapperRef.current ? wrapperRef.current.clientWidth : 600;
        canvas.height = 220;
        chartRef.current = new chart_js_1.Chart(canvas, {
            type: "line",
            data: {
                labels: ["Oct", "Nov", "Dec", "Jan", "Feb", "Mar"],
                datasets: [
                    {
                        label: "Google Ads",
                        data: [140, 165, 155, 175, 180, 210],
                        borderColor: "#e11d48",
                        backgroundColor: "rgba(225,29,72,.06)",
                        fill: true, tension: 0.4, pointRadius: 4, borderWidth: 2,
                    },
                    {
                        label: "LinkedIn Ads",
                        data: [40, 55, 62, 70, 78, 95],
                        borderColor: "#7c3aed",
                        backgroundColor: "rgba(124,58,237,.04)",
                        fill: true, tension: 0.4, pointRadius: 4, borderWidth: 2,
                    },
                    {
                        label: "Email",
                        data: [60, 72, 68, 80, 85, 73],
                        borderColor: "#059669",
                        backgroundColor: "rgba(5,150,105,.04)",
                        fill: true, tension: 0.4, pointRadius: 4, borderWidth: 2,
                    },
                    {
                        label: "Organic SEO",
                        data: [80, 95, 105, 120, 140, 165],
                        borderColor: "#0891b2",
                        backgroundColor: "rgba(8,145,178,.04)",
                        fill: true, tension: 0.4, pointRadius: 4, borderWidth: 2,
                    },
                ],
            },
            options: {
                responsive: false,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: "bottom",
                        labels: { boxWidth: 10, padding: 14, font: { size: 11 } },
                    },
                },
                scales: {
                    y: { grid: { color: "rgba(226,232,242,.8)" }, beginAtZero: true },
                    x: { grid: { color: "rgba(226,232,242,.4)" } },
                },
            },
        });
        return function () { if (chartRef.current) {
            chartRef.current.destroy();
            chartRef.current = null;
        } };
    }, []);
    return (React.createElement("div", { ref: wrapperRef, className: OverViewDashboard_module_scss_1.default.chartWrapper },
        React.createElement("canvas", { ref: canvasRef })));
};
var LeadSourcePieChart = function () {
    var canvasRef = (0, react_1.useRef)(null);
    var chartRef = (0, react_1.useRef)(null);
    var wrapperRef = (0, react_1.useRef)(null);
    (0, react_1.useEffect)(function () {
        if (!canvasRef.current)
            return;
        if (chartRef.current) {
            chartRef.current.destroy();
            chartRef.current = null;
        }
        var canvas = canvasRef.current;
        canvas.width = wrapperRef.current ? wrapperRef.current.clientWidth : 300;
        canvas.height = 190;
        chartRef.current = new chart_js_1.Chart(canvas, {
            type: "doughnut",
            data: {
                labels: ["Paid Ads", "Email", "Organic SEO"],
                datasets: [{
                        data: [305, 158, 165],
                        backgroundColor: ["#e11d48", "#059669", "#0891b2"],
                        borderWidth: 0,
                        hoverOffset: 8,
                    }],
            },
            options: {
                responsive: false,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: "bottom",
                        labels: { boxWidth: 10, padding: 12, font: { size: 10 } },
                    },
                },
            },
        });
        return function () { if (chartRef.current) {
            chartRef.current.destroy();
            chartRef.current = null;
        } };
    }, []);
    return (React.createElement("div", { ref: wrapperRef, className: OverViewDashboard_module_scss_1.default.chartWrapperSm },
        React.createElement("canvas", { ref: canvasRef })));
};
var TrafficDonutChart = function () {
    var canvasRef = (0, react_1.useRef)(null);
    var chartRef = (0, react_1.useRef)(null);
    var wrapperRef = (0, react_1.useRef)(null);
    (0, react_1.useEffect)(function () {
        if (!canvasRef.current)
            return;
        if (chartRef.current) {
            chartRef.current.destroy();
            chartRef.current = null;
        }
        var canvas = canvasRef.current;
        canvas.width = wrapperRef.current ? wrapperRef.current.clientWidth : 300;
        canvas.height = 220;
        chartRef.current = new chart_js_1.Chart(canvas, {
            type: "doughnut",
            data: {
                labels: ["Organic", "Direct", "Social", "Referral", "Paid"],
                datasets: [{
                        data: [9200, 4200, 2800, 2300, 1400],
                        backgroundColor: ["#1a6ef5", "#0891b2", "#7c3aed", "#d97706", "#e11d48"],
                        borderWidth: 0,
                        hoverOffset: 6,
                    }],
            },
            options: {
                responsive: false,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: "right",
                        labels: { boxWidth: 10, font: { size: 10 } },
                    },
                },
            },
        });
        return function () { if (chartRef.current) {
            chartRef.current.destroy();
            chartRef.current = null;
        } };
    }, []);
    return (React.createElement("div", { ref: wrapperRef, className: OverViewDashboard_module_scss_1.default.chartWrapper },
        React.createElement("canvas", { ref: canvasRef })));
};
var KpiCard = function (props) {
    var deltaClass = props.deltaType === "up" ? OverViewDashboard_module_scss_1.default.deltaUp :
        props.deltaType === "dn" ? OverViewDashboard_module_scss_1.default.deltaDn :
            OverViewDashboard_module_scss_1.default.deltaFlat;
    return (React.createElement("div", { className: OverViewDashboard_module_scss_1.default.kpi },
        React.createElement("div", { className: OverViewDashboard_module_scss_1.default.kpiTop },
            React.createElement("div", { className: OverViewDashboard_module_scss_1.default.kpiIcon, style: { background: props.iconBg } }, props.icon),
            React.createElement("div", { className: "".concat(OverViewDashboard_module_scss_1.default.kpiDelta, " ").concat(deltaClass) }, props.deltaText)),
        React.createElement("div", { className: OverViewDashboard_module_scss_1.default.kpiLabel }, props.label),
        React.createElement("div", { className: OverViewDashboard_module_scss_1.default.kpiVal }, props.value),
        React.createElement("div", { className: OverViewDashboard_module_scss_1.default.kpiSub }, props.sub),
        React.createElement("div", { className: OverViewDashboard_module_scss_1.default.kpiAccent, style: { background: props.accentColor } })));
};
var SummaryBand = function () { return (React.createElement("div", { className: OverViewDashboard_module_scss_1.default.summaryBand }, SUMMARY_BAND.map(function (item, i) { return (React.createElement(React.Fragment, { key: item.id },
    i > 0 && React.createElement("div", { className: OverViewDashboard_module_scss_1.default.sbDiv }),
    React.createElement("div", { className: OverViewDashboard_module_scss_1.default.sbItem },
        React.createElement("div", { className: OverViewDashboard_module_scss_1.default.sbNum }, item.value),
        React.createElement("div", { className: OverViewDashboard_module_scss_1.default.sbLbl }, item.label)))); }))); };
var ChannelPerformance = function () { return (React.createElement("div", { className: OverViewDashboard_module_scss_1.default.progList }, CHANNEL_SCORES.map(function (ch, i) { return (React.createElement("div", { className: OverViewDashboard_module_scss_1.default.progWrap, key: i },
    React.createElement("div", { className: OverViewDashboard_module_scss_1.default.progRow },
        React.createElement("span", { className: OverViewDashboard_module_scss_1.default.progLabel },
            ch.icon,
            " ",
            ch.label),
        React.createElement("span", { className: OverViewDashboard_module_scss_1.default.progVal },
            ch.score,
            "/100")),
    React.createElement("div", { className: OverViewDashboard_module_scss_1.default.progBar },
        React.createElement("div", { className: OverViewDashboard_module_scss_1.default.progFill, style: { width: "".concat(ch.score, "%"), background: ch.color } })))); }))); };
var TopCampaigns = function () { return (React.createElement(React.Fragment, null, TOP_CAMPAIGNS.map(function (c, i) { return (React.createElement("div", { className: OverViewDashboard_module_scss_1.default.miniM, key: i },
    React.createElement("span", { className: OverViewDashboard_module_scss_1.default.miniLabel },
        c.icon,
        " ",
        c.label),
    React.createElement("span", { className: OverViewDashboard_module_scss_1.default.miniVal }, c.value))); }))); };
var OverViewDashboard = function () {
    return (React.createElement("div", { className: OverViewDashboard_module_scss_1.default.overviewDashboard },
        React.createElement("div", { className: OverViewDashboard_module_scss_1.default.secHeader },
            React.createElement("div", { className: OverViewDashboard_module_scss_1.default.secTitleWrap },
                React.createElement("div", { className: OverViewDashboard_module_scss_1.default.secIcon, style: { background: "#e8f0fe" } }, "\u2B1B"),
                React.createElement("div", null,
                    React.createElement("div", { className: OverViewDashboard_module_scss_1.default.secTitle }, "Marketing Overview"),
                    React.createElement("div", { className: OverViewDashboard_module_scss_1.default.secSub }, "All channels \u00B7 TechnoRUCS"))),
            React.createElement("div", { className: OverViewDashboard_module_scss_1.default.secActions },
                React.createElement("span", { className: "".concat(OverViewDashboard_module_scss_1.default.sourceBadge, " ").concat(OverViewDashboard_module_scss_1.default.badgeGreen) }, "\uD83D\uDFE2 Live Dashboard"))),
        React.createElement(SummaryBand, null),
        React.createElement("div", { className: "".concat(OverViewDashboard_module_scss_1.default.g4, " ").concat(OverViewDashboard_module_scss_1.default.mt) }, KPI_CARDS.map(function (kpi, i) { return React.createElement(KpiCard, tslib_1.__assign({ key: i }, kpi)); })),
        React.createElement("div", { className: "".concat(OverViewDashboard_module_scss_1.default.gWide, " ").concat(OverViewDashboard_module_scss_1.default.mt) },
            React.createElement("div", { className: OverViewDashboard_module_scss_1.default.card },
                React.createElement("div", { className: OverViewDashboard_module_scss_1.default.cardHead },
                    React.createElement("div", null,
                        React.createElement("div", { className: OverViewDashboard_module_scss_1.default.cardTitle }, "Lead Generation \u2014 All Channels"),
                        React.createElement("div", { className: OverViewDashboard_module_scss_1.default.cardSub }, "Monthly trend across all marketing sources")),
                    React.createElement("span", { className: "".concat(OverViewDashboard_module_scss_1.default.cardBadge, " ").concat(OverViewDashboard_module_scss_1.default.pillBlue) }, "Last 6 Months")),
                React.createElement(LeadsTrendChart, null)),
            React.createElement("div", { className: OverViewDashboard_module_scss_1.default.card },
                React.createElement("div", { className: OverViewDashboard_module_scss_1.default.cardHead },
                    React.createElement("div", null,
                        React.createElement("div", { className: OverViewDashboard_module_scss_1.default.cardTitle }, "Lead Source Mix"),
                        React.createElement("div", { className: OverViewDashboard_module_scss_1.default.cardSub }, "This period"))),
                React.createElement(LeadSourcePieChart, null),
                React.createElement("div", { className: OverViewDashboard_module_scss_1.default.statRow }, LEAD_SOURCE_STATS.map(function (s, i) { return (React.createElement("div", { className: OverViewDashboard_module_scss_1.default.statBox, key: i },
                    React.createElement("div", { className: OverViewDashboard_module_scss_1.default.statVal, style: { color: s.color } }, s.value),
                    React.createElement("div", { className: OverViewDashboard_module_scss_1.default.statLbl }, s.label))); })))),
        React.createElement("div", { className: "".concat(OverViewDashboard_module_scss_1.default.g3, " ").concat(OverViewDashboard_module_scss_1.default.mt) },
            React.createElement("div", { className: OverViewDashboard_module_scss_1.default.card },
                React.createElement("div", { className: OverViewDashboard_module_scss_1.default.cardHead },
                    React.createElement("div", null,
                        React.createElement("div", { className: OverViewDashboard_module_scss_1.default.cardTitle }, "Channel Performance Score"),
                        React.createElement("div", { className: OverViewDashboard_module_scss_1.default.cardSub }, "Relative effectiveness"))),
                React.createElement(ChannelPerformance, null)),
            React.createElement("div", { className: OverViewDashboard_module_scss_1.default.card },
                React.createElement("div", { className: OverViewDashboard_module_scss_1.default.cardHead },
                    React.createElement("div", null,
                        React.createElement("div", { className: OverViewDashboard_module_scss_1.default.cardTitle }, "Website Traffic Sources"),
                        React.createElement("div", { className: OverViewDashboard_module_scss_1.default.cardSub }, "Session share this period"))),
                React.createElement(TrafficDonutChart, null)),
            React.createElement("div", { className: OverViewDashboard_module_scss_1.default.card },
                React.createElement("div", { className: OverViewDashboard_module_scss_1.default.cardHead },
                    React.createElement("div", null,
                        React.createElement("div", { className: OverViewDashboard_module_scss_1.default.cardTitle }, "Top Performing Campaigns"),
                        React.createElement("div", { className: OverViewDashboard_module_scss_1.default.cardSub }, "By leads generated"))),
                React.createElement(TopCampaigns, null)))));
};
exports.default = OverViewDashboard;
//# sourceMappingURL=OverViewDashboard.js.map