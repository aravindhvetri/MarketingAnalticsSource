"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var pnpjs_1 = require("@pnp/pnpjs");
var MainComponents_1 = tslib_1.__importDefault(require("./MainComponents/MainComponents"));
var MarketingAnalytics = /** @class */ (function (_super) {
    tslib_1.__extends(MarketingAnalytics, _super);
    function MarketingAnalytics(prop, state) {
        var _this = _super.call(this, prop) || this;
        pnpjs_1.sp.setup({
            spfxContext: _this.props.context,
        });
        return _this;
    }
    MarketingAnalytics.prototype.render = function () {
        return (React.createElement("div", null,
            React.createElement(MainComponents_1.default, { context: this.props.context })));
    };
    return MarketingAnalytics;
}(React.Component));
exports.default = MarketingAnalytics;
//# sourceMappingURL=MarketingAnalytics.js.map