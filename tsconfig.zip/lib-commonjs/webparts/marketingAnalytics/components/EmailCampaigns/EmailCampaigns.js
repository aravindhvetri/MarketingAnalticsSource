"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var react_1 = require("react");
var EmailCampaigns_module_scss_1 = tslib_1.__importDefault(require("./EmailCampaigns.module.scss"));
var DatePicker_1 = tslib_1.__importDefault(require("../DatePicker/DatePicker"));
var chart_1 = require("primereact/chart");
var sp_1 = require("@pnp/sp");
var pct = function (n, d) {
    return d === 0 ? "0%" : "".concat(((n / d) * 100).toFixed(1), "%");
};
var fmt = function (n) {
    return n >= 1000 ? (n / 1000).toFixed(1) + "K" : n.toString();
};
function defaultRange() {
    var today = new Date();
    return {
        startDate: new Date(today.getFullYear(), today.getMonth(), 1),
        endDate: today,
        label: "This Month",
    };
}
var EmailCampaignsDashboard = function () {
    var _a = (0, react_1.useState)(defaultRange()), dateRange = _a[0], setDateRange = _a[1];
    var _b = (0, react_1.useState)([]), campaignData = _b[0], setCampaignData = _b[1];
    var fetchCampaignData = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var response, formatted, err_1;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, sp_1.sp.web.lists
                            .getByTitle("WebsiteAnalyticsEmailCampaign")
                            .items.select("ID", "CampaignName", "Date", "Sent", "Opened", "Clicked", "Bounced", "UnSubscribed", "Leads")
                            .orderBy("Date", false)
                            .getAll()];
                case 1:
                    response = _a.sent();
                    formatted = response.map(function (item) { return ({
                        id: item.ID,
                        name: item.CampaignName,
                        date: item.Date ? new Date(item.Date) : new Date(),
                        sent: Number(item.Sent || 0),
                        opened: Number(item.Opened || 0),
                        clicked: Number(item.Clicked || 0),
                        bounced: Number(item.Bounced || 0),
                        unsubscribed: Number(item.UnSubscribed || 0),
                        leads: Number(item.Leads || 0),
                    }); });
                    setCampaignData(formatted);
                    return [3 /*break*/, 3];
                case 2:
                    err_1 = _a.sent();
                    console.error(err_1);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var filtered = (0, react_1.useMemo)(function () {
        return campaignData.filter(function (c) { return c.date >= dateRange.startDate && c.date <= dateRange.endDate; });
    }, [campaignData, dateRange]);
    var totals = (0, react_1.useMemo)(function () {
        return {
            sent: filtered.reduce(function (a, b) { return a + b.sent; }, 0),
            opened: filtered.reduce(function (a, b) { return a + b.opened; }, 0),
            clicked: filtered.reduce(function (a, b) { return a + b.clicked; }, 0),
            leads: filtered.reduce(function (a, b) { return a + b.leads; }, 0),
        };
    }, [filtered]);
    var openRate = pct(totals.opened, totals.sent);
    var ctr = pct(totals.clicked, totals.sent);
    var chartOptions = {
        responsive: true,
        maintainAspectRatio: false,
        layout: {
            padding: {
                top: 10,
                right: 10,
                bottom: 0,
                left: 0,
            },
        },
        plugins: {
            legend: {
                display: true,
                position: "top",
                align: "center",
                labels: {
                    color: "#64748b",
                    font: {
                        size: 11,
                        weight: "500",
                    },
                    usePointStyle: true,
                    pointStyle: "rect",
                    boxWidth: 8,
                    padding: 16,
                },
            },
        },
        scales: {
            x: {
                grid: {
                    display: false,
                },
                ticks: {
                    color: "#94a3b8",
                    font: { size: 10 },
                },
            },
            y: {
                beginAtZero: true,
                grid: {
                    color: "#eef2f7",
                    drawBorder: false,
                },
                ticks: {
                    color: "#94a3b8",
                    font: { size: 10 },
                    stepSize: 10,
                },
            },
        },
    };
    var rateChart = {
        labels: filtered.map(function (c) { return c.name.split("—")[0]; }),
        datasets: [
            {
                label: "Open Rate %",
                data: filtered.map(function (c) { return (c.opened / c.sent) * 100; }),
                backgroundColor: "#059669",
                borderRadius: 8,
                barThickness: 22,
                categoryPercentage: 0.5,
            },
            {
                label: "CTR %",
                data: filtered.map(function (c) { return (c.clicked / c.sent) * 100; }),
                backgroundColor: "#0891b2",
                borderRadius: 8,
                barThickness: 22,
                categoryPercentage: 0.5,
            },
        ],
    };
    var funnelChart = {
        labels: filtered.map(function (c) { return c.name.split("—")[0]; }),
        datasets: [
            {
                label: "Sent",
                data: filtered.map(function (c) { return c.sent; }),
                backgroundColor: "#e5e7eb",
                borderRadius: 8,
                barThickness: 18,
            },
            {
                label: "Opened",
                data: filtered.map(function (c) { return c.opened; }),
                backgroundColor: "#2563eb",
                borderRadius: 8,
                barThickness: 18,
            },
            {
                label: "Clicked",
                data: filtered.map(function (c) { return c.clicked; }),
                backgroundColor: "#0891b2",
                borderRadius: 8,
                barThickness: 18,
            },
            {
                label: "Leads",
                data: filtered.map(function (c) { return c.leads; }),
                backgroundColor: "#059669",
                borderRadius: 8,
                barThickness: 18,
            },
        ],
    };
    React.useEffect(function () {
        fetchCampaignData();
    }, []);
    return (React.createElement("div", { className: EmailCampaigns_module_scss_1.default.root },
        React.createElement("div", { className: EmailCampaigns_module_scss_1.default.globalHeader },
            React.createElement("div", null,
                React.createElement("div", { className: EmailCampaigns_module_scss_1.default.globalTitle }, "Email Campaigns"),
                React.createElement("div", { className: EmailCampaigns_module_scss_1.default.globalSub }, "Campaign metrics \u00B7 Excel data")),
            React.createElement("div", { className: EmailCampaigns_module_scss_1.default.headerActions },
                React.createElement(DatePicker_1.default, { value: dateRange, onChange: setDateRange, maxDate: new Date() }),
                React.createElement("button", { className: EmailCampaigns_module_scss_1.default["li-connect-btn"] }, "\uD83D\uDD17 Connect Sources"),
                React.createElement("button", { className: EmailCampaigns_module_scss_1.default.primaryBtn }, "\uD83D\uDD04 Refresh"))),
        React.createElement("div", { className: EmailCampaigns_module_scss_1.default.topHeaderBar },
            React.createElement("div", { className: EmailCampaigns_module_scss_1.default.headerContainer },
                React.createElement("div", { className: EmailCampaigns_module_scss_1.default.leftSection },
                    React.createElement("div", { className: EmailCampaigns_module_scss_1.default.iconBox }, "\uD83D\uDCE7"),
                    React.createElement("div", null,
                        React.createElement("div", { className: EmailCampaigns_module_scss_1.default.title }, "Email Campaigns"),
                        React.createElement("div", { className: EmailCampaigns_module_scss_1.default.subText }, "Data from Excel upload \u00B7 Manual entry"))),
                React.createElement("div", null,
                    React.createElement("span", { className: EmailCampaigns_module_scss_1.default.tag },
                        " ",
                        React.createElement("span", null, "\uD83D\uDCCA"),
                        "Excel Data")))),
        React.createElement("div", { className: EmailCampaigns_module_scss_1.default.kpiGrid },
            React.createElement("div", { className: EmailCampaigns_module_scss_1.default.kpi },
                React.createElement("div", { className: EmailCampaigns_module_scss_1.default.kpiTop },
                    React.createElement("div", { className: "".concat(EmailCampaigns_module_scss_1.default.kpiIcon, " ").concat(EmailCampaigns_module_scss_1.default.blueBg) }, "\uD83D\uDCE4")),
                React.createElement("div", { className: EmailCampaigns_module_scss_1.default.kpiLabel }, "TOTAL EMAILS SENT"),
                React.createElement("div", { className: EmailCampaigns_module_scss_1.default.kpiVal }, fmt(totals.sent)),
                React.createElement("div", { className: EmailCampaigns_module_scss_1.default.kpiSub }, "Across campaigns"),
                React.createElement("div", { className: EmailCampaigns_module_scss_1.default.kpiAccent, style: { background: "#2563eb" } })),
            React.createElement("div", { className: EmailCampaigns_module_scss_1.default.kpi },
                React.createElement("div", { className: EmailCampaigns_module_scss_1.default.kpiTop },
                    React.createElement("div", { className: "".concat(EmailCampaigns_module_scss_1.default.kpiIcon, " ").concat(EmailCampaigns_module_scss_1.default.greenBg) }, "\uD83D\uDCCA"),
                    React.createElement("span", { className: EmailCampaigns_module_scss_1.default.kpiBadge }, "\u25B2 2x avg")),
                React.createElement("div", { className: EmailCampaigns_module_scss_1.default.kpiLabel }, "AVG OPEN RATE"),
                React.createElement("div", { className: EmailCampaigns_module_scss_1.default.kpiVal }, openRate),
                React.createElement("div", { className: EmailCampaigns_module_scss_1.default.kpiSub }, "Industry avg 21.5%"),
                React.createElement("div", { className: EmailCampaigns_module_scss_1.default.kpiAccent, style: { background: "#059669" } })),
            React.createElement("div", { className: EmailCampaigns_module_scss_1.default.kpi },
                React.createElement("div", { className: EmailCampaigns_module_scss_1.default.kpiTop },
                    React.createElement("div", { className: "".concat(EmailCampaigns_module_scss_1.default.kpiIcon, " ").concat(EmailCampaigns_module_scss_1.default.blueSoft) }, "\uD83D\uDCC8"),
                    React.createElement("span", { className: EmailCampaigns_module_scss_1.default.kpiBadge }, "\u25B2 Excellent")),
                React.createElement("div", { className: EmailCampaigns_module_scss_1.default.kpiLabel }, "AVG CTR"),
                React.createElement("div", { className: EmailCampaigns_module_scss_1.default.kpiVal }, ctr),
                React.createElement("div", { className: EmailCampaigns_module_scss_1.default.kpiSub }, "Clicks / Sent"),
                React.createElement("div", { className: EmailCampaigns_module_scss_1.default.kpiAccent, style: { background: "#0891b2" } })),
            React.createElement("div", { className: EmailCampaigns_module_scss_1.default.kpi },
                React.createElement("div", { className: EmailCampaigns_module_scss_1.default.kpiTop },
                    React.createElement("div", { className: "".concat(EmailCampaigns_module_scss_1.default.kpiIcon, " ").concat(EmailCampaigns_module_scss_1.default.orangeBg) }, "\uD83C\uDFAF"),
                    React.createElement("span", { className: EmailCampaigns_module_scss_1.default.kpiBadge }, "\u25B2 16%")),
                React.createElement("div", { className: EmailCampaigns_module_scss_1.default.kpiLabel }, "LEADS FROM EMAIL"),
                React.createElement("div", { className: EmailCampaigns_module_scss_1.default.kpiVal }, totals.leads),
                React.createElement("div", { className: EmailCampaigns_module_scss_1.default.kpiSub }, "MQLs generated"),
                React.createElement("div", { className: EmailCampaigns_module_scss_1.default.kpiAccent, style: { background: "#f59e0b" } }))),
        React.createElement("div", { className: EmailCampaigns_module_scss_1.default.chartsGrid },
            React.createElement("div", { className: EmailCampaigns_module_scss_1.default.card },
                React.createElement("div", { className: EmailCampaigns_module_scss_1.default.cardHeader },
                    React.createElement("div", { className: EmailCampaigns_module_scss_1.default.cardTitle }, "Open Rate vs CTR by Campaign"),
                    React.createElement("div", { className: EmailCampaigns_module_scss_1.default.cardSub }, "Performance comparison")),
                React.createElement(chart_1.Chart, { type: "bar", data: rateChart, options: chartOptions })),
            React.createElement("div", { className: EmailCampaigns_module_scss_1.default.card },
                React.createElement("div", { className: EmailCampaigns_module_scss_1.default.cardHeader },
                    React.createElement("div", { className: EmailCampaigns_module_scss_1.default.cardTitle }, "Email Funnel"),
                    React.createElement("div", { className: EmailCampaigns_module_scss_1.default.cardSub }, "Sent \u2192 Opened \u2192 Clicked \u2192 Leads")),
                React.createElement(chart_1.Chart, { type: "bar", data: funnelChart, options: chartOptions }))),
        React.createElement("div", { className: EmailCampaigns_module_scss_1.default.tableCard },
            React.createElement("div", { className: EmailCampaigns_module_scss_1.default.tableTitle }, "Campaign Detail"),
            React.createElement("table", { className: EmailCampaigns_module_scss_1.default.table },
                React.createElement("thead", null,
                    React.createElement("tr", null,
                        React.createElement("th", null, "#"),
                        React.createElement("th", null, "Campaign"),
                        React.createElement("th", null, "Sent"),
                        React.createElement("th", null, "Opened"),
                        React.createElement("th", null, "Open Rate"),
                        React.createElement("th", null, "Clicked"),
                        React.createElement("th", null, "CTR"),
                        React.createElement("th", null, "Bounced"),
                        React.createElement("th", null, "Unsub"),
                        React.createElement("th", null, "Leads"))),
                React.createElement("tbody", null, filtered.map(function (c, i) { return (React.createElement("tr", { key: c.id },
                    React.createElement("td", null, i + 1),
                    React.createElement("td", null, c.name),
                    React.createElement("td", null, fmt(c.sent)),
                    React.createElement("td", null, fmt(c.opened)),
                    React.createElement("td", null,
                        React.createElement("span", { className: "".concat(EmailCampaigns_module_scss_1.default.pill, " ").concat(EmailCampaigns_module_scss_1.default.pillGreen) }, pct(c.opened, c.sent))),
                    React.createElement("td", null, fmt(c.clicked)),
                    React.createElement("td", null,
                        React.createElement("span", { className: "".concat(EmailCampaigns_module_scss_1.default.pill, " ").concat(EmailCampaigns_module_scss_1.default.pillBlue) }, pct(c.clicked, c.sent))),
                    React.createElement("td", null,
                        React.createElement("span", { className: "".concat(EmailCampaigns_module_scss_1.default.pill, " ").concat(EmailCampaigns_module_scss_1.default.pillAmber) }, c.bounced)),
                    React.createElement("td", null,
                        React.createElement("span", { className: "".concat(EmailCampaigns_module_scss_1.default.pill, " ").concat(EmailCampaigns_module_scss_1.default.pillRed) }, c.unsubscribed)),
                    React.createElement("td", null, c.leads))); }))),
            React.createElement("div", { className: EmailCampaigns_module_scss_1.default.uploadHint }, "\uD83D\uDCE4 Add New Campaign Data"))));
};
exports.default = EmailCampaignsDashboard;
//# sourceMappingURL=EmailCampaigns.js.map