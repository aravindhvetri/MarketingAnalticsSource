"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SECTIONS_META = void 0;
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var Sidebar_module_scss_1 = tslib_1.__importDefault(require("./Sidebar.module.scss"));
require("../../../ExternalRef/CSS/ReportsStyle.css");
var SECTIONS_META = {
    overview: { title: 'Marketing Overview', sub: 'All channels · TechnoRUCS' },
    linkedin: { title: 'LinkedIn Analytics', sub: 'Organic performance · API Connected' },
    email: { title: 'Email Campaigns', sub: 'Campaign metrics · Excel data' },
    website: { title: 'Website Analytics', sub: 'GA4 Connected · technorucs.com' },
    ads: { title: 'Paid Ads Performance', sub: 'Google · LinkedIn · Facebook · Excel data' },
    seo: { title: 'SEO Intelligence', sub: 'GSC + Excel · Keyword & backlink data' },
    leads: { title: 'Leads Intelligence', sub: 'All sources · qualified vs junk · Excel' },
};
exports.SECTIONS_META = SECTIONS_META;
var Sidebar = function (_a) {
    var activeSection = _a.activeSection, onNav = _a.onNav;
    var _b = React.useState(''), liveDate = _b[0], setLiveDate = _b[1];
    var _c = React.useState(''), liveTime = _c[0], setLiveTime = _c[1];
    React.useEffect(function () {
        var tick = function () {
            var n = new Date();
            setLiveDate(n.toLocaleDateString('en-IN', {
                weekday: 'short',
                day: 'numeric',
                month: 'short',
                year: 'numeric'
            }));
            setLiveTime(n.toLocaleTimeString('en-IN', {
                hour: '2-digit',
                minute: '2-digit'
            }));
        };
        tick();
        var timerId = setInterval(tick, 1000);
        return function () { return clearInterval(timerId); };
    }, []);
    var handleNav = function (id) {
        var info = SECTIONS_META[id];
        onNav(id, info.title, info.sub);
    };
    return (React.createElement("aside", { className: Sidebar_module_scss_1.default.sidebar },
        React.createElement("div", { className: Sidebar_module_scss_1.default.sbLogo },
            React.createElement("div", { className: Sidebar_module_scss_1.default.sbLogoMark },
                "Techno",
                React.createElement("em", null, "RUCS")),
            React.createElement("div", { className: Sidebar_module_scss_1.default.sbLogoSub }, "Marketing Analytics")),
        React.createElement("div", { className: Sidebar_module_scss_1.default.sbLive },
            React.createElement("div", { className: Sidebar_module_scss_1.default.liveDot }),
            "LIVE DASHBOARD"),
        React.createElement("nav", { className: Sidebar_module_scss_1.default.sbNav },
            React.createElement("div", { className: Sidebar_module_scss_1.default.sbSection }, "Overview"),
            React.createElement("a", { className: "".concat(Sidebar_module_scss_1.default.sbItem, " ").concat(activeSection === 'overview' ? Sidebar_module_scss_1.default.active : ''), onClick: function () { return handleNav('overview'); } },
                React.createElement("span", { className: Sidebar_module_scss_1.default.sbIcon }, "\u2B1B"),
                "Overview"),
            React.createElement("div", { className: Sidebar_module_scss_1.default.sbSection }, "Channels"),
            React.createElement("a", { className: "".concat(Sidebar_module_scss_1.default.sbItem, " ").concat(activeSection === 'linkedin' ? Sidebar_module_scss_1.default.active : ''), onClick: function () { return handleNav('linkedin'); } },
                React.createElement("span", { className: Sidebar_module_scss_1.default.sbIcon }, "\uD83D\uDCBC"),
                "LinkedIn",
                React.createElement("span", { className: Sidebar_module_scss_1.default.sbBadge }, "Live")),
            React.createElement("a", { className: "".concat(Sidebar_module_scss_1.default.sbItem, " ").concat(activeSection === 'email' ? Sidebar_module_scss_1.default.active : ''), onClick: function () { return handleNav('email'); } },
                React.createElement("span", { className: Sidebar_module_scss_1.default.sbIcon }, "\u2709\uFE0F"),
                "Email Campaigns"),
            React.createElement("a", { className: "".concat(Sidebar_module_scss_1.default.sbItem, " ").concat(activeSection === 'website' ? Sidebar_module_scss_1.default.active : ''), onClick: function () { return handleNav('website'); } },
                React.createElement("span", { className: Sidebar_module_scss_1.default.sbIcon }, "\uD83C\uDF10"),
                "Website Analytics",
                React.createElement("span", { className: Sidebar_module_scss_1.default.sbBadge }, "GA4")),
            React.createElement("a", { className: "".concat(Sidebar_module_scss_1.default.sbItem, " ").concat(activeSection === 'ads' ? Sidebar_module_scss_1.default.active : ''), onClick: function () { return handleNav('ads'); } },
                React.createElement("span", { className: Sidebar_module_scss_1.default.sbIcon }, "\uD83D\uDCB0"),
                "Paid Ads"),
            React.createElement("div", { className: Sidebar_module_scss_1.default.sbSection }, "Organic"),
            React.createElement("a", { className: "".concat(Sidebar_module_scss_1.default.sbItem, " ").concat(activeSection === 'seo' ? Sidebar_module_scss_1.default.active : ''), onClick: function () { return handleNav('seo'); } },
                React.createElement("span", { className: Sidebar_module_scss_1.default.sbIcon }, "\uD83D\uDD0D"),
                "SEO",
                React.createElement("span", { className: Sidebar_module_scss_1.default.sbBadge }, "GSC")),
            React.createElement("div", { className: Sidebar_module_scss_1.default.sbSection }, "Pipeline"),
            React.createElement("a", { className: "".concat(Sidebar_module_scss_1.default.sbItem, " ").concat(activeSection === 'leads' ? Sidebar_module_scss_1.default.active : ''), onClick: function () { return handleNav('leads'); } },
                React.createElement("span", { className: Sidebar_module_scss_1.default.sbIcon }, "\uD83C\uDFAF"),
                "Leads")),
        React.createElement("div", { className: Sidebar_module_scss_1.default.sbDate },
            React.createElement("strong", null, liveDate || 'Loading...'),
            React.createElement("span", null, liveTime || '--:--'),
            " IST \u00B7 Auto-refresh 5m")));
};
exports.default = Sidebar;
//# sourceMappingURL=SidNavComponets.js.map