"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.filterByDateRange = filterByDateRange;
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var react_1 = require("react");
var chart_1 = require("primereact/chart");
var datatable_1 = require("primereact/datatable");
var column_1 = require("primereact/column");
var card_1 = require("primereact/card");
var progressbar_1 = require("primereact/progressbar");
var skeleton_1 = require("primereact/skeleton");
var DatePicker_1 = tslib_1.__importDefault(require("../DatePicker/DatePicker"));
var WebsiteAnalytics_module_scss_1 = tslib_1.__importDefault(require("./WebsiteAnalytics.module.scss"));
var sp_1 = require("@pnp/sp");
function fmtNum(n) {
    if (n === undefined || n === null || isNaN(n))
        return "0";
    if (n >= 1000000)
        return (n / 1000000).toFixed(1).replace(/\.0$/, "") + "M";
    if (n >= 1000)
        return (n / 1000).toFixed(1).replace(/\.0$/, "") + "K";
    return n.toLocaleString("en-IN");
}
function toMidnight(d) {
    var copy = new Date(d);
    copy.setHours(0, 0, 0, 0);
    return copy;
}
function parseDurationToSeconds(duration) {
    var match = duration === null || duration === void 0 ? void 0 : duration.match(/(\d+)m\s*(\d+)s/);
    if (!match)
        return 0;
    return parseInt(match[1], 10) * 60 + parseInt(match[2], 10);
}
function formatDuration(seconds) {
    return "".concat(Math.floor(seconds / 60), "m ").concat(Math.round(seconds % 60), "s");
}
function defaultRange() {
    var today = toMidnight(new Date());
    return {
        startDate: new Date(today.getFullYear(), today.getMonth(), 1),
        endDate: today,
        label: "This Month",
    };
}
function filterByDateRange(items, startDate, endDate) {
    var from = new Date(startDate.getFullYear(), startDate.getMonth(), startDate.getDate()).getTime();
    var to = new Date(endDate.getFullYear(), endDate.getMonth(), endDate.getDate()).getTime();
    var _a = from <= to ? [from, to] : [to, from], normalFrom = _a[0], normalTo = _a[1];
    return items.filter(function (item) {
        if (!item.Date)
            return false;
        var itemTime;
        if (item.Date instanceof Date) {
            // Already a Date object
            itemTime = new Date(item.Date.getFullYear(), item.Date.getMonth(), item.Date.getDate()).getTime();
        }
        else {
            var raw = item.Date;
            var datePart = raw.split("T")[0];
            var _a = datePart.split("-").map(Number), y = _a[0], m = _a[1], d = _a[2];
            if (!y || !m || !d)
                return false;
            itemTime = new Date(y, m - 1, d).getTime();
        }
        return itemTime >= normalFrom && itemTime <= normalTo;
    });
}
var doughnutOpts = function (unit) {
    if (unit === void 0) { unit = ""; }
    return ({
        responsive: true,
        maintainAspectRatio: false,
        cutout: "45%",
        plugins: {
            legend: {
                position: "right",
                labels: { usePointStyle: true, font: { size: 11 } },
            },
            tooltip: {
                callbacks: {
                    label: function (ctx) {
                        var _a;
                        var value = Number((_a = ctx.raw) !== null && _a !== void 0 ? _a : 0); // ✅ SAFE
                        return " ".concat(ctx.label, ": ").concat(unit ? value + unit : fmtNum(value));
                    },
                },
            },
        },
    });
};
var trendChartOpts = {
    responsive: true,
    maintainAspectRatio: false,
    spanGaps: true,
    elements: {
        line: { tension: 0.4 },
        point: { radius: 4, hoverRadius: 6 },
    },
    plugins: {
        legend: { position: "bottom" },
        tooltip: { mode: "index", intersect: false },
    },
    scales: {
        x: {
            grid: { display: false },
            ticks: { color: "#4d8ef8" },
        },
        y: {
            beginAtZero: true,
            ticks: { color: "#0891b2" },
            grid: { color: "#E5E7EB" },
        },
    },
};
var NoData = function () { return (React.createElement("div", { style: {
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        height: "100%",
        minHeight: "120px",
        color: "#9CA3AF",
        gap: "8px",
    } },
    React.createElement("span", { style: { fontSize: "28px" } }, "\uD83D\uDCED"),
    React.createElement("span", { style: { fontSize: "13px", fontWeight: 500 } }, "No data found"))); };
// MAIN COMPONENT
var WebsiteAnalytics = function () {
    var _a = (0, react_1.useState)(defaultRange), dateRange = _a[0], setDateRange = _a[1];
    var _b = (0, react_1.useState)(true), loading = _b[0], setLoading = _b[1];
    // Raw SharePoint data
    var _c = (0, react_1.useState)([]), dailySummaryData = _c[0], setDailySummaryData = _c[1];
    var _d = (0, react_1.useState)([]), monthlyTrendData = _d[0], setMonthlyTrendData = _d[1];
    var _e = (0, react_1.useState)([]), trafficSources = _e[0], setTrafficSources = _e[1];
    var _f = (0, react_1.useState)([]), pageDetails = _f[0], setPageDetails = _f[1];
    var _g = (0, react_1.useState)([]), countryDetails = _g[0], setCountryDetails = _g[1];
    var _h = (0, react_1.useState)([]), deviceSessionMetrics = _h[0], setDeviceSessionMetrics = _h[1];
    var _j = (0, react_1.useState)(1), currentPage = _j[0], setCurrentPage = _j[1];
    var rowsPerPage = 5; // change to 10 if needed
    var fetchDailySummary = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var response, error_1;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, sp_1.sp.web.lists
                            .getByTitle("WebsiteAnalyticsDailySummary")
                            .items.select("*")
                            .orderBy("Date", false)
                            .getAll()];
                case 1:
                    response = _a.sent();
                    console.log(response, "dailySummaryData");
                    setDailySummaryData(response.map(function (item) { return ({
                        ID: item.ID,
                        Date: item.Date || null,
                        Users: Number(item.Users || 0),
                        Sessions: Number(item.Sessions || 0),
                        Bounce: Number(item.Bounce || 0),
                        Conversion: Number(item.Conversion || 0),
                        NewUsers: Number(item.NewUsers || 0),
                    }); }));
                    return [3 /*break*/, 3];
                case 2:
                    error_1 = _a.sent();
                    console.error("Error fetching data:", error_1);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var fetchMonthlyTrend = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var now, sixMonthsAgo, fromISO, response, error_2;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    now = new Date();
                    sixMonthsAgo = new Date(now.getFullYear(), now.getMonth() - 5, 1);
                    fromISO = new Date(sixMonthsAgo.getFullYear(), sixMonthsAgo.getMonth(), sixMonthsAgo.getDate(), 0, 0, 0).toISOString();
                    return [4 /*yield*/, sp_1.sp.web.lists
                            .getByTitle("WebsiteAnalyticsMonthlyTrend")
                            .items.select("*")
                            .filter("Date ge datetime'".concat(fromISO, "'"))
                            .orderBy("Date", true)
                            .getAll()];
                case 1:
                    response = _a.sent();
                    console.log(response, "monthlyTrendData");
                    setMonthlyTrendData(response.map(function (item) { return ({
                        ID: item.ID,
                        Date: item.Date || null,
                        Sessions: Number(item.Sessions || 0),
                        Users: Number(item.Users || 0),
                    }); }));
                    return [3 /*break*/, 3];
                case 2:
                    error_2 = _a.sent();
                    console.error("Error fetching monthly trend:", error_2);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var fetchTrafficSources = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var response, error_3;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, sp_1.sp.web.lists
                            .getByTitle("WebsiteAnalyticsTrafficSources")
                            .items.select("*")
                            .orderBy("Date", false)
                            .getAll()];
                case 1:
                    response = _a.sent();
                    console.log(response, "Traffic");
                    setTrafficSources(response.map(function (item) { return ({
                        ID: item.ID,
                        Date: item.Date || null,
                        TotalUser: Number(item.Sessions || 0),
                        Source: item.Source || "Unknown",
                    }); }));
                    return [3 /*break*/, 3];
                case 2:
                    error_3 = _a.sent();
                    console.error("Error fetching traffic sources:", error_3);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var fetchPageDetails = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var response, formattedData, error_4;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, sp_1.sp.web.lists
                            .getByTitle("WebsiteAnalyticsPagesDetails")
                            .items.select("ID", "Date", "Page", "Sessions", "Bounce", "AvgTime", "TotalUser")
                            .orderBy("Date", false)
                            .getAll()];
                case 1:
                    response = _a.sent();
                    console.log(response, "pageDetails");
                    formattedData = response.map(function (item) {
                        var _a, _b, _c, _d;
                        return ({
                            ID: item.ID,
                            Date: item.Date ? new Date(item.Date) : null,
                            Page: item.Page || "",
                            Session: Number((_a = item.Sessions) !== null && _a !== void 0 ? _a : 0),
                            Bounce: Number((_b = item.Bounce) !== null && _b !== void 0 ? _b : 0),
                            AvgTime: Number((_c = item.AvgTime) !== null && _c !== void 0 ? _c : 0),
                            totalUsers: Number((_d = item.TotalUser) !== null && _d !== void 0 ? _d : 0),
                        });
                    });
                    setPageDetails(formattedData);
                    return [3 /*break*/, 3];
                case 2:
                    error_4 = _a.sent();
                    console.error("Error fetching page details:", error_4);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var fetchCountryDetails = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var response, formattedData, error_5;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, sp_1.sp.web.lists
                            .getByTitle("WebsiteAnalyticsCountry")
                            .items.select("ID", "Date", "Country", "CountryCode", "TotalUsers")
                            .orderBy("Date", false)
                            .getAll()];
                case 1:
                    response = _a.sent();
                    console.log(response, "countryDetails");
                    formattedData = response.map(function (item) {
                        var _a, _b, _c;
                        return ({
                            ID: item.ID,
                            Date: item.Date ? new Date(item.Date) : null,
                            Country: (_a = item.Country) !== null && _a !== void 0 ? _a : "",
                            CountryCode: (_b = item.CountryCode) !== null && _b !== void 0 ? _b : "",
                            TotalUser: Number((_c = item.TotalUsers) !== null && _c !== void 0 ? _c : 0),
                        });
                    });
                    setCountryDetails(formattedData);
                    return [3 /*break*/, 3];
                case 2:
                    error_5 = _a.sent();
                    console.error("Error fetching country details:", error_5);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var fetchDeviceSessionMetrics = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var response, formattedData, error_6;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, sp_1.sp.web.lists
                            .getByTitle("WebsiteAnalyticsDeviceSessionMetrics")
                            .items.select("ID", "Date", "Device", "ReturningUsers", "NewUsers", "TotalUsers")
                            .orderBy("Date", false)
                            .getAll()];
                case 1:
                    response = _a.sent();
                    console.log(response, "deviceSessionMetrics");
                    formattedData = response.map(function (item) {
                        var _a, _b, _c;
                        var rawDevice = (item.Device || "").toLowerCase();
                        var validDevices = ["desktop", "mobile", "tablet"];
                        var device = validDevices.indexOf(rawDevice) !== -1
                            ? rawDevice.charAt(0).toUpperCase() + rawDevice.slice(1)
                            : "Desktop";
                        return {
                            ID: item.ID,
                            Date: item.Date ? new Date(item.Date) : null,
                            Device: device,
                            ReturningUsers: Number((_a = item.ReturningUsers) !== null && _a !== void 0 ? _a : 0),
                            NewUsers: Number((_b = item.NewUsers) !== null && _b !== void 0 ? _b : 0),
                            TotalUsers: Number((_c = item.TotalUsers) !== null && _c !== void 0 ? _c : 0),
                        };
                    });
                    setDeviceSessionMetrics(formattedData);
                    return [3 /*break*/, 3];
                case 2:
                    error_6 = _a.sent();
                    console.error("Error fetching device metrics:", error_6);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var fetchAllData = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var err_1;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    setLoading(true);
                    setDateRange(defaultRange());
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 3, 4, 5]);
                    return [4 /*yield*/, Promise.all([
                            fetchDailySummary(),
                            fetchMonthlyTrend(),
                            fetchTrafficSources(),
                            fetchPageDetails(),
                            fetchCountryDetails(),
                            fetchDeviceSessionMetrics(),
                        ])];
                case 2:
                    _a.sent();
                    return [3 /*break*/, 5];
                case 3:
                    err_1 = _a.sent();
                    console.error("WebsiteAnalytics fetch error:", err_1);
                    return [3 /*break*/, 5];
                case 4:
                    setLoading(false);
                    return [7 /*endfinally*/];
                case 5: return [2 /*return*/];
            }
        });
    }); };
    (0, react_1.useEffect)(function () {
        void fetchAllData();
    }, []);
    var startDate = dateRange.startDate, endDate = dateRange.endDate;
    var filteredDaily = (0, react_1.useMemo)(function () {
        if (!startDate || !endDate || !dailySummaryData.length)
            return dailySummaryData;
        return filterByDateRange(dailySummaryData, startDate, endDate);
    }, [dateRange, dailySummaryData]);
    // const filteredMonthly = useMemo(() => {
    //   if (!startDate || !endDate || !monthlyTrendData.length)
    //     return monthlyTrendData;
    //   return monthlyTrendData.filter((item) => {
    //     const d = new Date(item.Date);
    //     return d >= startDate && d <= endDate;
    //   });
    // }, [dateRange, monthlyTrendData]);
    var filteredTrafficSources = (0, react_1.useMemo)(function () {
        if (!startDate || !endDate || !trafficSources.length)
            return trafficSources;
        return filterByDateRange(trafficSources, startDate, endDate);
    }, [dateRange, trafficSources]);
    var filteredPageDetails = (0, react_1.useMemo)(function () {
        if (!startDate || !endDate || !pageDetails.length)
            return pageDetails;
        return filterByDateRange(pageDetails, startDate, endDate);
    }, [dateRange, pageDetails]);
    var filteredCountryDetails = (0, react_1.useMemo)(function () {
        if (!startDate || !endDate || !countryDetails.length)
            return countryDetails;
        return filterByDateRange(countryDetails, startDate, endDate);
    }, [dateRange, countryDetails]);
    var filteredDeviceMetrics = (0, react_1.useMemo)(function () {
        if (!startDate || !endDate || !deviceSessionMetrics.length)
            return deviceSessionMetrics;
        return filterByDateRange(deviceSessionMetrics, startDate, endDate);
    }, [dateRange, deviceSessionMetrics]);
    var totalUsers = (0, react_1.useMemo)(function () { return filteredDaily.reduce(function (s, i) { return s + i.Users; }, 0); }, [filteredDaily]);
    var totalSessions = (0, react_1.useMemo)(function () { return filteredDaily.reduce(function (s, i) { return s + i.Sessions; }, 0); }, [filteredDaily]);
    var bounceTotal = (0, react_1.useMemo)(function () {
        var total = filteredDaily.reduce(function (sum, item) { return sum + Number(item.Bounce || 0); }, 0);
        return total.toFixed(2) + "%";
    }, [filteredDaily]);
    var convRate = (0, react_1.useMemo)(function () {
        if (!filteredDaily.length)
            return "—";
        var total = filteredDaily.reduce(function (s, i) { return s + Number(i.Conversion || 0); }, 0);
        return total.toFixed(2) + "%";
    }, [filteredDaily]);
    var sourceTotals = (0, react_1.useMemo)(function () {
        var totals = { Organic: 0, Direct: 0, Social: 0, Referral: 0, Paid: 0 };
        console.log(filteredTrafficSources, "Filtered Traffic Sources");
        filteredTrafficSources.forEach(function (_a) {
            var _b;
            var Source = _a.Source, TotalUser = _a.TotalUser;
            var src = (_b = Source === null || Source === void 0 ? void 0 : Source.toLowerCase()) !== null && _b !== void 0 ? _b : "";
            console.log(src, "sourceess");
            if (src.includes("organic search"))
                totals.Organic += TotalUser;
            else if (src.includes("organic social"))
                totals.Social += TotalUser;
            else if (src.includes("direct"))
                totals.Direct += TotalUser;
            else if (src.includes("referral"))
                totals.Referral += TotalUser;
            else if (src.includes("paid"))
                totals.Paid += TotalUser;
        });
        console.log(totals, "Source Totals");
        return totals;
    }, [filteredTrafficSources]);
    /** Device session counts grouped by device type */
    var deviceStats = (0, react_1.useMemo)(function () {
        var grouped = { Desktop: 0, Mobile: 0, Tablet: 0 };
        filteredDeviceMetrics.forEach(function (_a) {
            var Device = _a.Device, TotalUsers = _a.TotalUsers;
            grouped[Device] =
                (grouped[Device] || 0) + TotalUsers;
        });
        return grouped;
    }, [filteredDeviceMetrics]);
    var newVsReturning = (0, react_1.useMemo)(function () {
        if (!filteredDeviceMetrics.length)
            return "— / —";
        var totalNew = filteredDeviceMetrics.reduce(function (s, i) { return s + i.NewUsers; }, 0);
        var totalReturning = filteredDeviceMetrics.reduce(function (s, i) { return s + i.ReturningUsers; }, 0);
        var totalAllUsers = filteredDeviceMetrics.reduce(function (s, i) { return s + i.TotalUsers; }, 0);
        var newPct = totalAllUsers
            ? Math.round((totalNew / totalAllUsers) * 100)
            : 0;
        var returningPct = totalAllUsers
            ? Math.round((totalReturning / totalAllUsers) * 100)
            : 0;
        return "".concat(newPct, "% / ").concat(returningPct, "%");
    }, [filteredDeviceMetrics]);
    var countryStats = (0, react_1.useMemo)(function () {
        if (!filteredCountryDetails.length)
            return [];
        var grouped = {};
        filteredCountryDetails.forEach(function (_a) {
            var Country = _a.Country, CountryCode = _a.CountryCode, TotalUser = _a.TotalUser;
            var key = (Country === null || Country === void 0 ? void 0 : Country.trim()) || "Unknown";
            if (!grouped[key]) {
                grouped[key] = {
                    name: key,
                    code: CountryCode || "XX",
                    totaluser: 0,
                };
            }
            grouped[key].totaluser += Number(TotalUser) || 0;
        });
        var result = Object.keys(grouped).map(function (key) { return grouped[key]; });
        var total = result.reduce(function (s, r) { return s + r.totaluser; }, 0);
        var max = Math.max.apply(Math, tslib_1.__spreadArray(tslib_1.__spreadArray([], result.map(function (r) { return r.totaluser; }), false), [1], false));
        return result
            .map(function (r) { return (tslib_1.__assign(tslib_1.__assign({}, r), { pct: total > 0 ? Math.round((r.totaluser / total) * 100) : 0, progress: Math.round((r.totaluser / max) * 100) })); })
            .sort(function (a, b) { return b.totaluser - a.totaluser; }); // ❌ no slice
    }, [filteredCountryDetails]);
    var totalPages = Math.ceil(countryStats.length / rowsPerPage);
    var groupedPages = (0, react_1.useMemo)(function () {
        var map = {};
        filteredPageDetails.forEach(function (item) {
            var key = item.Page || "Unknown";
            if (!map[key]) {
                map[key] = {
                    page: key,
                    sessions: 0,
                    totalBounce: 0,
                    totalTime: 0,
                    totalUsers: 0,
                    count: 0,
                };
            }
            map[key].sessions += item.Session || 0;
            map[key].totalBounce += item.Bounce || 0;
            map[key].totalTime += item.AvgTime || 0;
            map[key].count += 1;
            map[key].totalUsers += item.totalUsers || 0;
        });
        // SAFE return
        return Object.keys(map).map(function (key) { return map[key]; });
    }, [filteredPageDetails]);
    var topPagesData = (0, react_1.useMemo)(function () {
        return groupedPages
            .map(function (item) {
            var avgBounce = item.totalBounce / item.count;
            var avgTime = item.totalTime / item.count;
            return {
                page: item.page,
                sessions: item.sessions,
                totalUsers: item.totalUsers,
                bounce: "".concat(avgBounce.toFixed(1), "%"),
                avgTime: formatDuration(avgTime),
            };
        })
            .sort(function (a, b) { return b.sessions - a.sessions; });
    }, [groupedPages]);
    var trendChartData = (0, react_1.useMemo)(function () {
        var _a, _b;
        var grouped = {};
        (monthlyTrendData || []).forEach(function (item) {
            var d = new Date(item.Date);
            var month = d.getMonth() + 1;
            var key = "".concat(d.getFullYear(), "-").concat(month < 10 ? "0" : "").concat(month);
            if (!grouped[key]) {
                grouped[key] = {
                    Sessions: 0,
                    Users: 0,
                    label: "",
                };
            }
            grouped[key].Sessions += item.Sessions;
            grouped[key].Users += item.Users;
        });
        var months = [];
        var today = new Date();
        for (var i = 5; i >= 0; i--) {
            var d = new Date(today.getFullYear(), today.getMonth() - i, 1);
            var month = d.getMonth() + 1;
            var key = "".concat(d.getFullYear(), "-").concat(month < 10 ? "0" : "").concat(month);
            var label = d.toLocaleDateString("en-IN", {
                month: "short",
                year: "2-digit",
            });
            months.push({
                label: label,
                Sessions: ((_a = grouped[key]) === null || _a === void 0 ? void 0 : _a.Sessions) || 0,
                Users: ((_b = grouped[key]) === null || _b === void 0 ? void 0 : _b.Users) || 0,
            });
        }
        console.log("Trend Chart Data:", months);
        return {
            labels: months.map(function (m) { return m.label; }),
            datasets: [
                {
                    label: "Sessions",
                    data: months.map(function (m) { return m.Sessions; }),
                    borderColor: "#4F46E5",
                    backgroundColor: "rgba(79,70,229,0.15)",
                    tension: 0.4,
                    fill: true,
                },
                {
                    label: "Users",
                    data: months.map(function (m) { return m.Users; }),
                    borderColor: "#06B6D4",
                    backgroundColor: "rgba(6,182,212,0.15)",
                    tension: 0.4,
                    fill: true,
                },
            ],
        };
    }, [monthlyTrendData]);
    var sourceChartData = (0, react_1.useMemo)(function () { return ({
        labels: ["Organic Search", "Direct", "Social", "Referral", "Paid"],
        datasets: [
            {
                data: [
                    sourceTotals.Organic,
                    sourceTotals.Direct,
                    sourceTotals.Social,
                    sourceTotals.Referral,
                    sourceTotals.Paid,
                ],
                backgroundColor: [
                    "#1a6ef5",
                    "#0891b2",
                    "#7c3aed",
                    "#d97706",
                    "#e11d48",
                ],
                hoverOffset: 6,
                borderWidth: 2,
                borderColor: "#fff",
            },
        ],
    }); }, [sourceTotals]);
    var deviceChartData = (0, react_1.useMemo)(function () {
        var total = deviceStats.Desktop + deviceStats.Mobile + deviceStats.Tablet;
        return {
            labels: ["Desktop", "Mobile", "Tablet"],
            datasets: [
                {
                    data: [deviceStats.Desktop, deviceStats.Mobile, deviceStats.Tablet],
                    backgroundColor: ["#1e3a5f", "#1a6ef5", "#0891b2"],
                    borderWidth: 2,
                    borderColor: "#fff",
                },
            ],
        };
    }, [deviceStats]);
    var kpis = [
        {
            iconBg: "#e8f0fe",
            icon: "👤",
            label: "Total Users",
            value: filteredDaily.length === 0 ? "—" : fmtNum(totalUsers),
            sub: "Unique visitors",
            accent: "#1a6ef5",
        },
        {
            iconBg: "#e0f5fa",
            icon: "📊",
            label: "Sessions",
            value: filteredDaily.length === 0 ? "—" : fmtNum(totalSessions),
            sub: "Total sessions",
            accent: "#0891b2",
        },
        {
            iconBg: "#ffe4e6",
            icon: "↩",
            label: "Bounce Rate",
            value: String(bounceTotal),
            sub: "Lower is better",
            accent: "#e11d48",
        },
        {
            iconBg: "#d1fae5",
            icon: "🎯",
            label: "Conversion Rate",
            value: convRate,
            sub: "Goal completions",
            accent: "#059669",
        },
    ];
    var miniMetrics = [{ label: "New vs Returning", value: newVsReturning }];
    var rangeLabel = (0, react_1.useMemo)(function () {
        if (!startDate || !endDate)
            return "All time";
        var fmt = function (d) {
            return d.toLocaleDateString("en-IN", {
                day: "numeric",
                month: "short",
                year: "numeric",
            });
        };
        return "".concat(fmt(startDate), " \u2013 ").concat(fmt(endDate));
    }, [dateRange]);
    var pageTemplate = function (rowData) { return React.createElement("span", null, rowData.page); };
    var sessionsTemplate = function (rowData) { return rowData.sessions.toLocaleString(); };
    var TotalUserTemplate = function (rowData) {
        return rowData.totalUsers.toLocaleString();
    };
    var bounceTemplate = function (rowData) {
        var value = parseFloat(rowData.bounce || "0");
        var severity = value > 60 ? "high" : value > 40 ? "medium" : "low";
        return React.createElement("span", { className: "badge ".concat(severity) }, rowData.bounce);
    };
    return (React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.root },
        React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.wrapper },
            React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.topHeader },
                React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.topLeft },
                    React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.mainTitle }, "Website Analytics"),
                    React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.mainSub }, "GA4 Connected \u00B7 technorucs.com")),
                React.createElement("div", { style: { display: "flex", alignItems: "center", gap: "8px" } },
                    React.createElement(DatePicker_1.default, { value: dateRange, onChange: function (range) { return setDateRange(range); }, maxDate: new Date() }),
                    React.createElement("button", { className: WebsiteAnalytics_module_scss_1.default.connectBtn }, "\uD83D\uDD17 Connect Sources"),
                    React.createElement("button", { className: WebsiteAnalytics_module_scss_1.default.refreshBtn, onClick: fetchAllData }, "\u21BB Refresh"))),
            React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.secHeader },
                React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.secLeft },
                    React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.secIcon }, "\uD83C\uDF10"),
                    React.createElement("div", null,
                        React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.secTitle }, "Website Analytics"),
                        React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.secSub },
                            "Connected via Google Analytics 4 \u00B7 ",
                            rangeLabel))),
                React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.secRight },
                    React.createElement("span", { className: WebsiteAnalytics_module_scss_1.default.sourceBadge }, "\uD83D\uDD17 GA4 Connected")))),
        loading && (React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.loadingBar },
            React.createElement(progressbar_1.ProgressBar, { mode: "indeterminate", style: { height: "4px" } }))),
        React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.g4 }, kpis.map(function (k, i) { return (React.createElement("div", { key: i, className: WebsiteAnalytics_module_scss_1.default.kpiCard },
            React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.kpiTop },
                React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.kpiIconBox, style: { background: k.iconBg } }, k.icon)),
            React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.kpiLabel }, k.label),
            loading ? (React.createElement(skeleton_1.Skeleton, { height: "28px", className: WebsiteAnalytics_module_scss_1.default.kpiVal })) : (React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.kpiVal }, k.value)),
            React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.kpiSub }, k.sub),
            React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.kpiAccent, style: { background: k.accent } }))); })),
        React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.gridTwo },
            React.createElement(card_1.Card, { header: React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.cardHdr },
                    React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.cardTitle }, "Sessions & Users Trend")), className: WebsiteAnalytics_module_scss_1.default.card },
                React.createElement("div", { style: { height: "260px" } }, loading ? (React.createElement(skeleton_1.Skeleton, { height: "260px" })) : monthlyTrendData.length === 0 ? (React.createElement(NoData, null)) : (React.createElement(chart_1.Chart, { type: "line", data: trendChartData, options: trendChartOpts, style: { height: "100%" } })))),
            React.createElement(card_1.Card, { header: React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.cardHdr },
                    React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.cardTitle }, "Traffic Sources"),
                    React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.cardSub }, rangeLabel)), className: WebsiteAnalytics_module_scss_1.default.card },
                React.createElement("div", { style: { height: "200px" } }, loading ? (React.createElement(skeleton_1.Skeleton, { height: "200px" })) : filteredTrafficSources.length === 0 ? (React.createElement(NoData, null)) : (React.createElement(chart_1.Chart, { type: "doughnut", data: sourceChartData, options: doughnutOpts(), style: { height: "100%" } }))))),
        React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.gW3 },
            React.createElement(card_1.Card, { header: React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.cardHdr },
                    React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.cardTitle }, "Top Pages"),
                    React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.cardSub },
                        "By sessions \u00B7 ",
                        rangeLabel)), className: WebsiteAnalytics_module_scss_1.default.card }, loading ? (React.createElement(skeleton_1.Skeleton, { height: "200px" })) : topPagesData.length === 0 ? (React.createElement(NoData, null)) : (React.createElement(datatable_1.DataTable, { value: topPagesData, size: "small", className: "top-pages-table", stripedRows: true, paginator: topPagesData && topPagesData.length > 0, rows: 6 },
                React.createElement(column_1.Column, { field: "page", header: "PAGE", style: { width: "44%" }, body: pageTemplate }),
                React.createElement(column_1.Column, { field: "TotalUser", style: { width: "14%" }, header: "USERS", body: TotalUserTemplate, headerClassName: "left", bodyClassName: "left" }),
                React.createElement(column_1.Column, { field: "sessions", style: { width: "14%" }, header: "SESSIONS", body: sessionsTemplate, headerClassName: "left", bodyClassName: "left" }),
                React.createElement(column_1.Column, { field: "bounce", style: { width: "14%" }, header: "BOUNCE", body: bounceTemplate, headerClassName: "left", bodyClassName: "left" }),
                React.createElement(column_1.Column, { field: "avgTime", style: { width: "14%" }, header: "AVG TIME", headerClassName: "left", bodyClassName: "left" })))),
            React.createElement(card_1.Card, { header: React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.cardHdr },
                    React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.cardTitle }, "Visitors by Country"),
                    React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.cardSub }, "Session share")), className: WebsiteAnalytics_module_scss_1.default.card },
                React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.geoPadding }, loading ? (React.createElement(skeleton_1.Skeleton, { height: "200px" })) : countryStats.length === 0 ? (React.createElement(NoData, null)) : (React.createElement(datatable_1.DataTable, { value: countryStats, paginator: countryStats && countryStats.length > 0, rows: 5, showGridlines: false, className: "custom-country-table" },
                    React.createElement(column_1.Column, { body: function (rowData) { return (React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.geoRow },
                            React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.geoLeft },
                                React.createElement("span", { className: WebsiteAnalytics_module_scss_1.default.geoCode }, rowData.code),
                                React.createElement("span", { className: WebsiteAnalytics_module_scss_1.default.geoName }, rowData.name)),
                            React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.geoBarWrap },
                                React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.geoBar },
                                    React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.geoFill, style: { width: "".concat(rowData.progress, "%") } }))),
                            React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.geoRight },
                                React.createElement("span", { className: WebsiteAnalytics_module_scss_1.default.geoSess }, fmtNum(rowData.totaluser)),
                                React.createElement("span", { className: WebsiteAnalytics_module_scss_1.default.geoPct },
                                    rowData.pct,
                                    "%")))); } }))))),
            React.createElement(card_1.Card, { header: React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.cardHdr },
                    React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.cardTitle }, "Device & Session Metrics")), className: WebsiteAnalytics_module_scss_1.default.card },
                React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.chartWrapSm }, loading ? (React.createElement(skeleton_1.Skeleton, { height: "180px" })) : filteredDeviceMetrics.length === 0 ? (React.createElement(NoData, null)) : (React.createElement(chart_1.Chart, { type: "doughnut", data: deviceChartData, options: doughnutOpts(), style: { height: "100%" } }))),
                React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.divider }),
                React.createElement("div", { className: WebsiteAnalytics_module_scss_1.default.miniSection }, miniMetrics.map(function (m, i) { return (React.createElement("div", { key: i, className: WebsiteAnalytics_module_scss_1.default.miniM },
                    React.createElement("span", { className: WebsiteAnalytics_module_scss_1.default.miniLabel }, m.label),
                    React.createElement("span", { className: WebsiteAnalytics_module_scss_1.default.miniVal }, m.value))); }))))));
};
exports.default = WebsiteAnalytics;
//# sourceMappingURL=WebsiteAnalytics.js.map