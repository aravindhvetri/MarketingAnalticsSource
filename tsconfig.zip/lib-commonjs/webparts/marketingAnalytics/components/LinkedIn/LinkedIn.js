"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = LinkedInAnalytics;
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var react_1 = require("react");
var LinkedIn_module_scss_1 = tslib_1.__importDefault(require("./LinkedIn.module.scss"));
var DatePicker_1 = tslib_1.__importDefault(require("../DatePicker/DatePicker"));
var chart_1 = require("primereact/chart");
var LINKEDIN_DATA = [
    { date: new Date(2026, 0, 26), totalFollowers: 12020, followersGained: 12, postsPublished: 1, profileVisits: 260, linkClicks: 300, reactions: 150 },
    { date: new Date(2026, 0, 27), totalFollowers: 12032, followersGained: 12, postsPublished: 0, profileVisits: 250, linkClicks: 290, reactions: 145 },
    { date: new Date(2026, 0, 28), totalFollowers: 12045, followersGained: 13, postsPublished: 1, profileVisits: 255, linkClicks: 295, reactions: 148 },
    { date: new Date(2026, 0, 29), totalFollowers: 12058, followersGained: 13, postsPublished: 0, profileVisits: 270, linkClicks: 310, reactions: 155 },
    { date: new Date(2026, 0, 30), totalFollowers: 12071, followersGained: 13, postsPublished: 1, profileVisits: 265, linkClicks: 305, reactions: 152 },
    { date: new Date(2026, 1, 2), totalFollowers: 12090, followersGained: 19, postsPublished: 1, profileVisits: 275, linkClicks: 315, reactions: 160 },
    { date: new Date(2026, 1, 3), totalFollowers: 12108, followersGained: 18, postsPublished: 1, profileVisits: 280, linkClicks: 325, reactions: 165 },
    { date: new Date(2026, 1, 4), totalFollowers: 12120, followersGained: 12, postsPublished: 0, profileVisits: 270, linkClicks: 310, reactions: 155 },
    { date: new Date(2026, 1, 5), totalFollowers: 12135, followersGained: 15, postsPublished: 1, profileVisits: 285, linkClicks: 330, reactions: 168 },
    { date: new Date(2026, 1, 6), totalFollowers: 12114, followersGained: 30, postsPublished: 1, profileVisits: 330, linkClicks: 330, reactions: 172 },
    { date: new Date(2026, 1, 9), totalFollowers: 12145, followersGained: 20, postsPublished: 1, profileVisits: 270, linkClicks: 315, reactions: 157 },
    { date: new Date(2026, 1, 10), totalFollowers: 12162, followersGained: 17, postsPublished: 0, profileVisits: 265, linkClicks: 308, reactions: 153 },
    { date: new Date(2026, 1, 11), totalFollowers: 12178, followersGained: 16, postsPublished: 1, profileVisits: 272, linkClicks: 318, reactions: 159 },
    { date: new Date(2026, 1, 12), totalFollowers: 12194, followersGained: 16, postsPublished: 0, profileVisits: 268, linkClicks: 312, reactions: 156 },
    { date: new Date(2026, 1, 13), totalFollowers: 12202, followersGained: 19, postsPublished: 1, profileVisits: 295, linkClicks: 337, reactions: 165 },
    { date: new Date(2026, 1, 16), totalFollowers: 12225, followersGained: 23, postsPublished: 1, profileVisits: 300, linkClicks: 370, reactions: 183 },
    { date: new Date(2026, 1, 17), totalFollowers: 12248, followersGained: 23, postsPublished: 1, profileVisits: 302, linkClicks: 373, reactions: 184 },
    { date: new Date(2026, 1, 18), totalFollowers: 12272, followersGained: 24, postsPublished: 0, profileVisits: 310, linkClicks: 380, reactions: 188 },
    { date: new Date(2026, 1, 19), totalFollowers: 12295, followersGained: 23, postsPublished: 1, profileVisits: 298, linkClicks: 368, reactions: 182 },
    { date: new Date(2026, 1, 20), totalFollowers: 12312, followersGained: 17, postsPublished: 1, profileVisits: 290, linkClicks: 409, reactions: 183 },
    { date: new Date(2026, 1, 23), totalFollowers: 12332, followersGained: 20, postsPublished: 1, profileVisits: 292, linkClicks: 352, reactions: 170 },
    { date: new Date(2026, 1, 24), totalFollowers: 12351, followersGained: 19, postsPublished: 0, profileVisits: 285, linkClicks: 345, reactions: 167 },
    { date: new Date(2026, 1, 25), totalFollowers: 12372, followersGained: 21, postsPublished: 1, profileVisits: 295, linkClicks: 358, reactions: 173 },
    { date: new Date(2026, 1, 26), totalFollowers: 12391, followersGained: 19, postsPublished: 1, profileVisits: 288, linkClicks: 350, reactions: 169 },
    { date: new Date(2026, 1, 27), totalFollowers: 12414, followersGained: 23, postsPublished: 0, profileVisits: 300, linkClicks: 395, reactions: 171 },
    { date: new Date(2026, 2, 2), totalFollowers: 12440, followersGained: 26, postsPublished: 1, profileVisits: 320, linkClicks: 415, reactions: 208 },
    { date: new Date(2026, 2, 3), totalFollowers: 12466, followersGained: 26, postsPublished: 1, profileVisits: 322, linkClicks: 414, reactions: 207 },
    { date: new Date(2026, 2, 4), totalFollowers: 12490, followersGained: 24, postsPublished: 0, profileVisits: 315, linkClicks: 408, reactions: 203 },
    { date: new Date(2026, 2, 5), totalFollowers: 12516, followersGained: 26, postsPublished: 1, profileVisits: 323, linkClicks: 416, reactions: 208 },
    { date: new Date(2026, 2, 6), totalFollowers: 12542, followersGained: 26, postsPublished: 1, profileVisits: 460, linkClicks: 647, reactions: 224 },
    { date: new Date(2026, 2, 9), totalFollowers: 12564, followersGained: 22, postsPublished: 1, profileVisits: 312, linkClicks: 396, reactions: 197 },
    { date: new Date(2026, 2, 10), totalFollowers: 12586, followersGained: 22, postsPublished: 0, profileVisits: 308, linkClicks: 392, reactions: 195 },
    { date: new Date(2026, 2, 11), totalFollowers: 12608, followersGained: 22, postsPublished: 1, profileVisits: 314, linkClicks: 398, reactions: 198 },
    { date: new Date(2026, 2, 12), totalFollowers: 12630, followersGained: 22, postsPublished: 1, profileVisits: 310, linkClicks: 394, reactions: 196 },
    { date: new Date(2026, 2, 13), totalFollowers: 12658, followersGained: 28, postsPublished: 0, profileVisits: 336, linkClicks: 380, reactions: 174 },
    { date: new Date(2026, 2, 16), totalFollowers: 12680, followersGained: 22, postsPublished: 1, profileVisits: 330, linkClicks: 430, reactions: 230 },
    { date: new Date(2026, 2, 17), totalFollowers: 12703, followersGained: 23, postsPublished: 1, profileVisits: 332, linkClicks: 432, reactions: 231 },
    { date: new Date(2026, 2, 18), totalFollowers: 12728, followersGained: 25, postsPublished: 0, profileVisits: 338, linkClicks: 440, reactions: 235 },
    { date: new Date(2026, 2, 19), totalFollowers: 12754, followersGained: 26, postsPublished: 1, profileVisits: 342, linkClicks: 444, reactions: 237 },
    { date: new Date(2026, 2, 20), totalFollowers: 12840, followersGained: 44, postsPublished: 0, profileVisits: 558, linkClicks: 654, reactions: 267 },
];
var POST_DATA = [
    { date: new Date(2026, 1, 18), topic: "SharePoint EOL Checklist", type: "Article", typeColor: "blue", impressions: 18400, reactions: 342, comments: 48, reposts: 94, clicks: 620 },
    { date: new Date(2026, 2, 5), topic: "Copilot Studio Demo", type: "Video", typeColor: "violet", impressions: 14200, reactions: 281, comments: 34, reposts: 72, clicks: 480 },
    { date: new Date(2026, 1, 25), topic: "Power Platform ROI Stats", type: "Infographic", typeColor: "green", impressions: 11800, reactions: 198, comments: 27, reposts: 55, clicks: 340 },
    { date: new Date(2026, 2, 12), topic: "Healthcare Case Study", type: "Article", typeColor: "teal", impressions: 9400, reactions: 156, comments: 19, reposts: 38, clicks: 290 },
    { date: new Date(2026, 2, 3), topic: "Dynamics 365 Tips", type: "Carousel", typeColor: "amber", impressions: 8200, reactions: 134, comments: 15, reposts: 29, clicks: 220 },
    { date: new Date(2026, 2, 24), topic: "Azure Migration Guide", type: "Article", typeColor: "orange", impressions: 7100, reactions: 112, comments: 12, reposts: 24, clicks: 180 },
    { date: new Date(2026, 3, 10), topic: "Azure Migration Guide", type: "Article", typeColor: "orange", impressions: 7100, reactions: 112, comments: 12, reposts: 24, clicks: 180 },
    { date: new Date(2026, 1, 10), topic: "Azure Migration Guide", type: "Article", typeColor: "orange", impressions: 7100, reactions: 112, comments: 12, reposts: 24, clicks: 180 },
];
var C = { blue: "#1a6ef5", teal: "#0891b2", green: "#059669", amber: "#d97706", rose: "#e11d48", violet: "#7c3aed", orange: "#ea580c", navy: "#1e3a5f" };
function getMondayOf(d) {
    var copy = new Date(d);
    copy.setHours(0, 0, 0, 0);
    var day = copy.getDay();
    copy.setDate(copy.getDate() + (day === 0 ? -6 : 1 - day));
    return copy;
}
function generateWeeks(startDate, endDate) {
    var weeks = [];
    var cursor = getMondayOf(startDate);
    var n = 1;
    while (cursor <= endDate) {
        var end = new Date(cursor);
        end.setDate(end.getDate() + 6);
        weeks.push({ label: "W".concat(n), weekStart: new Date(cursor), weekEnd: end });
        cursor.setDate(cursor.getDate() + 7);
        n++;
    }
    return weeks;
}
function aggregateLinkedIn(liRows, pRows, weeks) {
    return weeks.map(function (week) {
        var lr = liRows.filter(function (r) { return r.date >= week.weekStart && r.date <= week.weekEnd; });
        var pr = pRows.filter(function (p) { return p.date >= week.weekStart && p.date <= week.weekEnd; });
        return {
            label: week.label, weekStart: week.weekStart, weekEnd: week.weekEnd,
            totalFollowers: lr.length > 0 ? lr[lr.length - 1].totalFollowers : 0,
            followersGained: lr.reduce(function (s, r) { return s + r.followersGained; }, 0),
            postsPublished: lr.reduce(function (s, r) { return s + r.postsPublished; }, 0),
            profileVisits: lr.reduce(function (s, r) { return s + r.profileVisits; }, 0),
            linkClicks: lr.reduce(function (s, r) { return s + r.linkClicks; }, 0),
            reactions: lr.reduce(function (s, r) { return s + r.reactions; }, 0),
            impressions: pr.reduce(function (s, p) { return s + p.impressions; }, 0),
            engagement: pr.reduce(function (s, p) { return s + p.reactions + p.comments + p.reposts; }, 0),
        };
    });
}
function fmt(n) {
    if (n >= 1000000)
        return (n / 1000000).toFixed(1).replace(/\.0$/, "") + "M";
    if (n >= 1000)
        return (n / 1000).toFixed(1).replace(/\.0$/, "") + "K";
    return n.toLocaleString("en-IN");
}
function buildKpis(weeks) {
    var BASE = [
        { icon: "👥", iconBg: "#e8f0fe", label: "Total Followers", accent: C.blue },
        { icon: "📝", iconBg: "#ede9fe", label: "Posts Published", accent: C.violet },
        { icon: "👁", iconBg: "#e0f5fa", label: "Profile Visits", accent: C.teal },
        { icon: "🖱", iconBg: "#d1fae5", label: "Link Clicks", accent: C.green },
        { icon: "❤️", iconBg: "#fef3c7", label: "Reactions & Likes", accent: C.amber },
    ];
    if (weeks.length === 0)
        return BASE.map(function (b) { return (tslib_1.__assign(tslib_1.__assign({}, b), { value: "—", sub: "No data", delta: "—", deltaType: "flat" })); });
    var totalFollowers = weeks[weeks.length - 1].totalFollowers;
    var followersGained = weeks.reduce(function (s, w) { return s + w.followersGained; }, 0);
    var firstFollowers = weeks[0].totalFollowers;
    var followerPct = firstFollowers > 0 ? (((totalFollowers - firstFollowers) / firstFollowers) * 100).toFixed(1) : "0";
    return [
        tslib_1.__assign(tslib_1.__assign({}, BASE[0]), { value: totalFollowers.toLocaleString("en-IN"), sub: "+".concat(fmt(followersGained), " gained"), delta: "\u25B2 ".concat(followerPct, "%"), deltaType: "up" }),
        tslib_1.__assign(tslib_1.__assign({}, BASE[1]), { value: weeks.reduce(function (s, w) { return s + w.postsPublished; }, 0).toString(), sub: "Across ".concat(weeks.length, " week").concat(weeks.length > 1 ? "s" : ""), delta: "▲ 25%", deltaType: "up" }),
        tslib_1.__assign(tslib_1.__assign({}, BASE[2]), { value: fmt(weeks.reduce(function (s, w) { return s + w.profileVisits; }, 0)), sub: "Unique visitors", delta: "▲ 18%", deltaType: "up" }),
        tslib_1.__assign(tslib_1.__assign({}, BASE[3]), { value: fmt(weeks.reduce(function (s, w) { return s + w.linkClicks; }, 0)), sub: "Post + profile clicks", delta: "▲ 12%", deltaType: "up" }),
        tslib_1.__assign(tslib_1.__assign({}, BASE[4]), { value: fmt(weeks.reduce(function (s, w) { return s + w.reactions; }, 0)), sub: "Across all posts", delta: "▲ 34%", deltaType: "up" }),
    ];
}
function defaultRange() {
    var today = new Date();
    today.setHours(0, 0, 0, 0);
    return {
        startDate: new Date(today.getFullYear(), today.getMonth(), 1),
        endDate: today,
        label: "This Month",
    };
}
function LinkedInAnalytics() {
    var _a = (0, react_1.useState)("linkedin"), activeNav = _a[0], setActiveNav = _a[1];
    var _b = (0, react_1.useState)([]), kpis = _b[0], setKpis = _b[1];
    var _c = (0, react_1.useState)(null), trendData = _c[0], setTrendData = _c[1];
    var _d = (0, react_1.useState)(null), followersData = _d[0], setFollowersData = _d[1];
    var _e = (0, react_1.useState)(null), postTypeData = _e[0], setPostTypeData = _e[1];
    var _f = (0, react_1.useState)([]), filteredPosts = _f[0], setFilteredPosts = _f[1];
    var _g = (0, react_1.useState)(null), topPost = _g[0], setTopPost = _g[1];
    var _h = (0, react_1.useState)(false), loading = _h[0], setLoading = _h[1];
    var _j = (0, react_1.useState)(""), liveTime = _j[0], setLiveTime = _j[1];
    var _k = (0, react_1.useState)(""), liveDate = _k[0], setLiveDate = _k[1];
    var _l = (0, react_1.useState)(defaultRange()), dateRange = _l[0], setDateRange = _l[1];
    var postTypeOpt = {
        responsive: true,
        maintainAspectRatio: false, // 🔥 IMPORTANT
        cutout: "65%", // nice donut like first image
        plugins: {
            legend: {
                position: "right",
                labels: {
                    usePointStyle: true,
                    boxWidth: 8,
                    padding: 12,
                    font: { size: 11 }
                }
            }
        },
    };
    // Live clock
    (0, react_1.useEffect)(function () {
        function tick() {
            var now = new Date();
            setLiveTime(now.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" }));
            setLiveDate(now.toLocaleDateString("en-IN", { weekday: "short", day: "numeric", month: "short", year: "numeric" }));
        }
        tick();
        var id = setInterval(tick, 60000);
        return function () { return clearInterval(id); };
    }, []);
    (0, react_1.useEffect)(function () {
        setLoading(true);
        var timer = setTimeout(function () {
            var _a;
            var weeks = generateWeeks(dateRange.startDate, dateRange.endDate);
            var aggregated = aggregateLinkedIn(LINKEDIN_DATA, POST_DATA, weeks);
            var posts = POST_DATA
                .filter(function (p) { return p.date >= dateRange.startDate && p.date <= dateRange.endDate; })
                .sort(function (a, b) { return b.impressions - a.impressions; });
            setKpis(buildKpis(aggregated));
            setFilteredPosts(posts);
            setTopPost((_a = posts[0]) !== null && _a !== void 0 ? _a : null);
            var labels = aggregated.map(function (w) { return w.label; });
            setTrendData({
                labels: labels,
                datasets: [
                    {
                        label: "Impressions",
                        data: aggregated.map(function (w) { return w.impressions; }),
                        backgroundColor: "rgba(26,110,245,0.15)",
                        borderColor: "#1a6ef5",
                        borderWidth: 2,
                        borderRadius: 6,
                        barThickness: 26,
                        categoryPercentage: 0.6,
                        barPercentage: 0.8,
                        yAxisID: "y",
                    },
                    {
                        label: "Engagement",
                        data: aggregated.map(function (w) { return w.engagement; }),
                        backgroundColor: "#059669",
                        borderRadius: 6,
                        barThickness: 26,
                        categoryPercentage: 0.6,
                        barPercentage: 0.8,
                        yAxisID: "y1",
                    },
                ],
            });
            setFollowersData({
                labels: labels,
                datasets: [{ label: "Followers Gained", data: aggregated.map(function (w) { return w.followersGained; }), backgroundColor: C.blue, borderRadius: 6 }],
            });
            var typeCounts = {};
            posts.forEach(function (p) { typeCounts[p.type] = (typeCounts[p.type] || 0) + 1; });
            var typeLabels = Object.keys(typeCounts);
            setPostTypeData({
                labels: typeLabels.length ? typeLabels : ["No Data"],
                datasets: [{
                        data: typeLabels.length ? typeLabels.map(function (l) { return typeCounts[l]; }) : [1],
                        backgroundColor: [C.blue, C.violet, C.rose, C.amber, C.teal, C.orange].slice(0, Math.max(typeLabels.length, 1)),
                        borderWidth: 0, hoverOffset: 6,
                    }],
            });
            console.log(trendData, "tren");
            setLoading(false);
        }, 250);
        return function () { return clearTimeout(timer); };
    }, [dateRange]);
    var trendOpt = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: "top",
                labels: {
                    usePointStyle: true,
                    boxWidth: 8,
                    padding: 12,
                    font: {
                        size: 11,
                        weight: "500",
                    },
                },
            },
        },
        scales: {
            x: {
                grid: {
                    display: false,
                },
                ticks: {
                    color: "#64748b",
                    font: { size: 11 },
                },
            },
            y: {
                position: "left",
                grid: {
                    color: "rgba(226,232,240,0.7)",
                },
                ticks: {
                    color: "#64748b",
                    font: { size: 11 },
                },
            },
            y1: {
                position: "right",
                grid: {
                    drawOnChartArea: false,
                },
                ticks: {
                    color: "#64748b",
                    font: { size: 11 },
                },
            },
        },
    };
    var followersOpt = {
        responsive: true, maintainAspectRatio: true,
        plugins: { legend: { display: false } },
        scales: { y: { grid: { color: "rgba(226,232,242,.8)" } }, x: { grid: { display: false } } },
        maxBarThickness: 40,
    };
    // Page title map
    var PAGE_TITLES = {
        overview: { title: "Marketing Overview", sub: "All channels · TechnoRUCS" },
        linkedin: { title: "LinkedIn Analytics", sub: "Organic performance · TechnoRUCS" },
        email: { title: "Email Campaigns", sub: "Campaign performance · TechnoRUCS" },
        website: { title: "Website Analytics", sub: "GA4 data · TechnoRUCS" },
        ads: { title: "Paid Ads", sub: "Ad performance · TechnoRUCS" },
        seo: { title: "SEO", sub: "Search Console data · TechnoRUCS" },
        leads: { title: "Leads", sub: "Pipeline · TechnoRUCS" },
    };
    var _m = PAGE_TITLES[activeNav] || PAGE_TITLES.linkedin, pageTitle = _m.title, pageSub = _m.sub;
    return (React.createElement(React.Fragment, null,
        React.createElement("main", { className: LinkedIn_module_scss_1.default['li-main'] },
            React.createElement("header", { className: LinkedIn_module_scss_1.default['li-topbar'] },
                React.createElement("div", { className: LinkedIn_module_scss_1.default['li-topbar-left'] },
                    React.createElement("div", null,
                        React.createElement("div", { className: LinkedIn_module_scss_1.default['li-page-title'] }, pageTitle),
                        React.createElement("div", { className: LinkedIn_module_scss_1.default['li-page-sub'] }, pageSub))),
                React.createElement("div", { className: LinkedIn_module_scss_1.default['li-topbar-right'] },
                    React.createElement(DatePicker_1.default, { value: dateRange, onChange: setDateRange, maxDate: new Date() }),
                    React.createElement("button", { className: LinkedIn_module_scss_1.default['li-connect-btn'] }, "\uD83D\uDD17 Connect Sources"),
                    React.createElement("button", { className: LinkedIn_module_scss_1.default['li-refresh-btn'], onClick: function () { return setDateRange(function (r) { return (tslib_1.__assign({}, r)); }); } }, "\u21BB Refresh"))),
            React.createElement("div", { className: LinkedIn_module_scss_1.default['li-content'] },
                React.createElement("div", { className: LinkedIn_module_scss_1.default['li-sec-header'] },
                    React.createElement("div", { className: LinkedIn_module_scss_1.default['li-sec-title-wrap'] },
                        React.createElement("div", { className: LinkedIn_module_scss_1.default['li-sec-icon'], style: { background: "var(--blue-lt)" } }, "\uD83D\uDCBC"),
                        React.createElement("div", null,
                            React.createElement("div", { className: LinkedIn_module_scss_1.default['li-sec-title'] }, "LinkedIn Analytics"),
                            React.createElement("div", { className: LinkedIn_module_scss_1.default['li-sec-sub'] }, "Organic performance \u00B7 Connected via LinkedIn API"))),
                    React.createElement("div", { className: LinkedIn_module_scss_1.default['li-sec-actions'] },
                        React.createElement("span", { className: LinkedIn_module_scss_1.default['li-source-badge'] }, "\uD83D\uDD17 LinkedIn Connected"))),
                loading && (React.createElement("div", { className: LinkedIn_module_scss_1.default['li-loading-bar'] },
                    React.createElement("div", { className: LinkedIn_module_scss_1.default['li-loading-fill'] }))),
                React.createElement("div", { className: LinkedIn_module_scss_1.default["li-g5"] }, kpis.map(function (k) { return (React.createElement("div", { key: k.label, className: LinkedIn_module_scss_1.default["li-kpi"] },
                    React.createElement("div", { className: LinkedIn_module_scss_1.default["li-kpi-top"] },
                        React.createElement("div", { className: LinkedIn_module_scss_1.default["li-kpi-icon"], style: { background: k.iconBg } }, k.icon),
                        React.createElement("div", { className: "".concat(LinkedIn_module_scss_1.default["li-kpi-delta"], " ").concat(LinkedIn_module_scss_1.default[k.deltaType]) }, k.delta)),
                    React.createElement("div", { className: LinkedIn_module_scss_1.default["li-kpi-label"] }, k.label),
                    React.createElement("div", { className: LinkedIn_module_scss_1.default["li-kpi-val"] }, k.value),
                    React.createElement("div", { className: LinkedIn_module_scss_1.default["li-kpi-sub"] }, k.sub),
                    React.createElement("div", { className: LinkedIn_module_scss_1.default["li-kpi-accent"], style: { background: k.accent } }))); })),
                trendData && followersData && (React.createElement("div", { className: "".concat(LinkedIn_module_scss_1.default["li-g-wide"], " ").concat(LinkedIn_module_scss_1.default["li-mt"]) },
                    React.createElement("div", { className: LinkedIn_module_scss_1.default["li-card"] },
                        React.createElement("div", { className: LinkedIn_module_scss_1.default["li-card-head"] },
                            React.createElement("div", null,
                                React.createElement("div", { className: LinkedIn_module_scss_1.default["li-card-title"] }, "Impressions & Engagement Trend"),
                                React.createElement("div", { className: LinkedIn_module_scss_1.default["li-card-sub"] }, "Weekly LinkedIn organic performance"))),
                        React.createElement(chart_1.Chart, { type: "bar", data: trendData, options: trendOpt, style: { height: "220px" } })),
                    React.createElement("div", { className: LinkedIn_module_scss_1.default["li-card"] },
                        React.createElement("div", { className: LinkedIn_module_scss_1.default["li-card-head"] },
                            React.createElement("div", null,
                                React.createElement("div", { className: LinkedIn_module_scss_1.default["li-card-title"] }, "Follower Growth"),
                                React.createElement("div", { className: LinkedIn_module_scss_1.default["li-card-sub"] }, "Net new followers weekly"))),
                        React.createElement(chart_1.Chart, { type: "bar", data: followersData, options: followersOpt, style: { height: "220px" } })))),
                React.createElement("div", { className: "".concat(LinkedIn_module_scss_1.default["li-g2"], " ").concat(LinkedIn_module_scss_1.default["li-mt"]) },
                    React.createElement("div", null,
                        React.createElement("div", { className: LinkedIn_module_scss_1.default["li-top-post"] }, topPost ? (React.createElement(React.Fragment, null,
                            React.createElement("div", { className: LinkedIn_module_scss_1.default["li-post-label"] }, "\uD83C\uDFC6 Top Post This Period"),
                            React.createElement("div", { className: LinkedIn_module_scss_1.default["li-post-title"] },
                                "\"",
                                topPost.topic,
                                "\""),
                            React.createElement("div", { className: LinkedIn_module_scss_1.default["li-post-stats"] },
                                React.createElement("span", null,
                                    "\uD83D\uDC41 ",
                                    fmt(topPost.impressions),
                                    " impressions"),
                                React.createElement("span", null,
                                    "\u2764\uFE0F ",
                                    topPost.reactions,
                                    " reactions"),
                                React.createElement("span", null,
                                    "\uD83D\uDCAC ",
                                    topPost.comments,
                                    " comments"),
                                React.createElement("span", null,
                                    "\uD83D\uDD01 ",
                                    topPost.reposts,
                                    " reposts")))) : (React.createElement(React.Fragment, null,
                            React.createElement("div", { className: LinkedIn_module_scss_1.default["li-post-label"] }, "\uD83C\uDFC6 Top Post"),
                            React.createElement("div", { className: LinkedIn_module_scss_1.default["li-post-title"] }, "No posts in selected range")))),
                        postTypeData && (React.createElement("div", { className: "".concat(LinkedIn_module_scss_1.default["li-card"], " ").concat(LinkedIn_module_scss_1.default["li-mt"]) },
                            React.createElement("div", { className: LinkedIn_module_scss_1.default["li-card-head"] },
                                React.createElement("div", null,
                                    React.createElement("div", { className: LinkedIn_module_scss_1.default["li-card-title"] }, "Post Type Performance"),
                                    React.createElement("div", { className: LinkedIn_module_scss_1.default["li-card-sub"] }, "Engagement by content type"))),
                            React.createElement("div", { className: LinkedIn_module_scss_1.default["li-donut-wrap"] },
                                React.createElement(chart_1.Chart, { type: "doughnut", data: postTypeData, options: postTypeOpt }))))),
                    React.createElement("div", { className: LinkedIn_module_scss_1.default["li-card"] },
                        React.createElement("div", { className: LinkedIn_module_scss_1.default["li-card-head"] },
                            React.createElement("div", null,
                                React.createElement("div", { className: LinkedIn_module_scss_1.default["li-card-title"] }, "Post Performance Detail"),
                                React.createElement("div", { className: LinkedIn_module_scss_1.default["li-card-sub"] },
                                    filteredPosts.length,
                                    " post",
                                    filteredPosts.length !== 1 ? "s" : "",
                                    " \u00B7 sorted by reach"))),
                        filteredPosts.length > 0 ? (React.createElement("table", { className: LinkedIn_module_scss_1.default["li-tbl"] },
                            React.createElement("thead", null,
                                React.createElement("tr", null,
                                    React.createElement("th", null, "Post Topic"),
                                    React.createElement("th", null, "Type"),
                                    React.createElement("th", null, "Impressions"),
                                    React.createElement("th", null, "Reactions"),
                                    React.createElement("th", null, "Clicks"))),
                            React.createElement("tbody", null, filteredPosts.map(function (p, i) { return (React.createElement("tr", { key: i },
                                React.createElement("td", null,
                                    React.createElement("strong", null, p.topic)),
                                React.createElement("td", null,
                                    React.createElement("span", { className: "".concat(LinkedIn_module_scss_1.default["li-pill"], " ").concat(LinkedIn_module_scss_1.default["li-pill-".concat(p.typeColor)]) }, p.type)),
                                React.createElement("td", null, fmt(p.impressions)),
                                React.createElement("td", null, p.reactions),
                                React.createElement("td", null, p.clicks))); })))) : (React.createElement("div", { className: LinkedIn_module_scss_1.default["li-empty-state"] }, "\uD83D\uDCED No posts found for the selected date range."))))))));
}
//# sourceMappingURL=LinkedIn.js.map