"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var react_1 = require("react");
var LeadsIntelligence_module_scss_1 = tslib_1.__importDefault(require("./LeadsIntelligence.module.scss"));
var DatePicker_1 = tslib_1.__importDefault(require("../DatePicker/DatePicker"));
var chart_1 = require("primereact/chart");
var sp_1 = require("@pnp/sp");
// ─── Helpers ─────────────────────────────────────────────────────────────────
function defaultRange() {
    var start = new Date();
    start.setDate(1);
    start.setHours(0, 0, 0, 0); // start of first day of current month
    var end = new Date();
    end.setHours(23, 59, 59, 999); // end of today (not midnight!)
    return {
        startDate: start,
        endDate: end,
        label: "This Month",
    };
}
/**
 * Parse a SharePoint date string safely in LOCAL time.
 * SharePoint returns ISO strings like "2024-06-15T00:00:00Z".
 * If parsed directly, browsers shift by UTC offset (e.g. IST = UTC+5:30
 * turns June 15 into June 14 at 18:30 local), breaking date comparisons.
 * We strip the time part and construct a local-midnight Date instead.
 */
function parseSharePointDate(raw) {
    if (!raw)
        return null;
    try {
        var datePart = raw.split("T")[0]; // "2024-06-15"
        var _a = datePart.split("-").map(Number), y = _a[0], m = _a[1], d = _a[2];
        if (!y || !m || !d)
            return null;
        return new Date(y, m - 1, d); // local midnight — no timezone shift
    }
    catch (_b) {
        return null;
    }
}
var SOURCE_META_LIST = [
    {
        key: "Google Ads",
        icon: "🔍",
        iconBg: "#ffe4e6",
        meta: "Search campaigns",
        countColor: "#e11d48",
    },
    {
        key: "Organic",
        icon: "🌐",
        iconBg: "#e0f5fa",
        meta: "Contact form · SEO",
        countColor: "#0891b2",
    },
    {
        key: "Email",
        icon: "✉️",
        iconBg: "#d1fae5",
        meta: "Campaign emails",
        countColor: "#059669",
    },
    {
        key: "LinkedIn Ads",
        icon: "💼",
        iconBg: "#e8f0fe",
        meta: "Sponsored + InMail",
        countColor: "#1a6ef5",
    },
];
var PILL_MAP = {
    "Google Ads": { source: LeadsIntelligence_module_scss_1.default.pillBlue, status: "" },
    "LinkedIn Ads": { source: LeadsIntelligence_module_scss_1.default.pillViolet, status: "" },
    Email: { source: LeadsIntelligence_module_scss_1.default.pillGreen, status: "" },
    Organic: { source: LeadsIntelligence_module_scss_1.default.pillTeal, status: "" },
    Qualified: { source: "", status: LeadsIntelligence_module_scss_1.default.pillGreen },
    Junk: { source: "", status: LeadsIntelligence_module_scss_1.default.pillRose },
    Review: { source: "", status: LeadsIntelligence_module_scss_1.default.pillAmber },
};
// ─── Chart: Lead Source Bar ───────────────────────────────────────────────────
var LeadSourceChart = function (_a) {
    var _b, _c, _d, _e;
    var data = _a.data;
    var labels = ["Google Ads", "Website/SEO", "Email", "LinkedIn Ads"];
    var chartData = {
        labels: labels,
        datasets: [
            {
                label: "Leads",
                backgroundColor: ["#e11d48", "#0891b2", "#059669", "#2563eb"],
                borderRadius: 8,
                barThickness: 36,
                data: [
                    (_b = data["Google Ads"]) !== null && _b !== void 0 ? _b : 0,
                    (_c = data["Organic"]) !== null && _c !== void 0 ? _c : 0,
                    (_d = data["Email"]) !== null && _d !== void 0 ? _d : 0,
                    (_e = data["LinkedIn Ads"]) !== null && _e !== void 0 ? _e : 0,
                ],
            },
        ],
    };
    var options = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
            x: {
                grid: { display: false },
                ticks: { color: "#64748b", font: { size: 11 } },
            },
            y: {
                beginAtZero: true,
                ticks: { color: "#94a3b8", font: { size: 11 } },
                grid: { color: "#e5e7eb", drawBorder: false },
            },
        },
    };
    return (React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.chartWrapper },
        React.createElement(chart_1.Chart, { type: "bar", data: chartData, options: options })));
};
var LeadQualityChart = function (_a) {
    var qualified = _a.qualified, review = _a.review, junk = _a.junk;
    var chartData = {
        labels: ["Qualified", "In Review", "Junk"],
        datasets: [
            {
                data: [qualified, review, junk],
                backgroundColor: ["#059669", "#d97706", "#e11d48"],
                borderWidth: 0,
            },
        ],
    };
    var options = {
        responsive: true,
        maintainAspectRatio: false,
        cutout: "65%",
        plugins: {
            legend: {
                position: "bottom",
                labels: {
                    color: "#64748b",
                    boxWidth: 14,
                    padding: 20,
                    font: { size: 11 },
                },
            },
        },
    };
    return (React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.chartWrapper },
        React.createElement(chart_1.Chart, { type: "doughnut", data: chartData, options: options })));
};
// ─── Main Component ───────────────────────────────────────────────────────────
var LeadsIntelligenceDashboard = function () {
    var _a = (0, react_1.useState)(defaultRange()), dateRange = _a[0], setDateRange = _a[1];
    var _b = (0, react_1.useState)(false), loading = _b[0], setLoading = _b[1];
    var _c = (0, react_1.useState)([]), leadData = _c[0], setLeadData = _c[1];
    // ── Fetch from SharePoint
    var fetchLeadData = function () { return tslib_1.__awaiter(void 0, void 0, void 0, function () {
        var response, formatted, err_1;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    setLoading(true);
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 3, 4, 5]);
                    return [4 /*yield*/, sp_1.sp.web.lists
                            .getByTitle("MarketingAnalytics-LeadsIntelligenceDetails")
                            .items.select("ID", "Date", "LeadName", "PhoneNumber", "CompanyName", "EmailId", "Enquiry", "Source", "Campaign", "Country", "Notes", "Status")
                            .orderBy("Date", false)
                            .getAll()];
                case 2:
                    response = _a.sent();
                    formatted = response.map(function (item) { return ({
                        id: item.ID,
                        // ✅ FIX: Use parseSharePointDate to avoid UTC→local timezone shift
                        date: parseSharePointDate(item.Date),
                        leadName: item.LeadName || "",
                        phoneNumber: item.PhoneNumber || "",
                        companyName: item.CompanyName || "",
                        email: item.EmailId || "",
                        enquiry: item.Enquiry || "",
                        source: item.Source || "",
                        campaign: item.Campaign || "",
                        country: item.Country || "",
                        notes: item.Notes || "",
                        status: item.Status || "",
                    }); });
                    setLeadData(formatted);
                    return [3 /*break*/, 5];
                case 3:
                    err_1 = _a.sent();
                    console.error("Failed to fetch leads:", err_1);
                    return [3 /*break*/, 5];
                case 4:
                    setLoading(false);
                    return [7 /*endfinally*/];
                case 5: return [2 /*return*/];
            }
        });
    }); };
    (0, react_1.useEffect)(function () {
        fetchLeadData();
    }, []);
    // Debounced loading indicator on date change
    (0, react_1.useEffect)(function () {
        setLoading(true);
        var t = setTimeout(function () { return setLoading(false); }, 300);
        return function () { return clearTimeout(t); };
    }, [dateRange]);
    // ── Filter leadData by date range
    // ✅ FIX: Normalise both bounds so entire start-day and end-day are included
    var filtered = (0, react_1.useMemo)(function () {
        var start = new Date(dateRange.startDate);
        start.setHours(0, 0, 0, 0); // beginning of start day
        var end = new Date(dateRange.endDate);
        end.setHours(23, 59, 59, 999); // end of end day — captures full day
        return leadData.filter(function (l) {
            if (!l.date)
                return false;
            return l.date >= start && l.date <= end;
        });
    }, [leadData, dateRange]);
    // ── Aggregate KPIs from filtered leadData
    var kpis = (0, react_1.useMemo)(function () {
        var total = filtered.length;
        var qualified = filtered.filter(function (l) { return l.status.toLowerCase() === "qualified"; }).length;
        var junk = filtered.filter(function (l) { return l.status.toLowerCase() === "junk"; }).length;
        var review = filtered.filter(function (l) { return l.status.toLowerCase() === "review"; }).length;
        var qualRate = total > 0 ? ((qualified / total) * 100).toFixed(1) : "0";
        var junkRate = total > 0 ? ((junk / total) * 100).toFixed(1) : "0";
        return { total: total, qualified: qualified, junk: junk, review: review, qualRate: qualRate, junkRate: junkRate };
    }, [filtered]);
    // ── Per-source counts from filtered leadData
    var sourceCounts = (0, react_1.useMemo)(function () {
        var counts = {
            "Google Ads": 0,
            Organic: 0,
            Email: 0,
            "LinkedIn Ads": 0,
        };
        filtered.forEach(function (l) {
            if (l.source in counts) {
                counts[l.source] += 1;
            }
        });
        return counts;
    }, [filtered]);
    var KPI_CARDS = [
        {
            icon: "📥",
            iconBg: "#e8f0fe",
            accentColor: "#1a6ef5",
            deltaText: "▲ 21%",
            deltaType: "up",
            label: "Total Leads",
            value: String(kpis.total),
            sub: "All sources this period",
        },
        {
            icon: "✅",
            iconBg: "#d1fae5",
            accentColor: "#059669",
            deltaText: "▲ 18%",
            deltaType: "up",
            label: "Qualified Leads",
            value: String(kpis.qualified),
            sub: "".concat(kpis.qualRate, "% qualification rate"),
        },
        {
            icon: "🗑️",
            iconBg: "#ffe4e6",
            accentColor: "#e11d48",
            deltaText: "—",
            deltaType: "flat",
            label: "Junk Leads",
            value: String(kpis.junk),
            sub: "".concat(kpis.junkRate, "% junk rate"),
        },
        {
            icon: "⏳",
            iconBg: "#fef3c7",
            accentColor: "#d97706",
            deltaText: "—",
            deltaType: "flat",
            label: "In Review",
            value: String(kpis.review),
            sub: "Pending qualification",
        },
    ];
    var QUALITY_STATS = [
        { value: kpis.qualified, label: "Qualified", color: "#059669" },
        { value: kpis.junk, label: "Junk", color: "#e11d48" },
        { value: kpis.review, label: "Review", color: "#d97706" },
    ];
    return (React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.leadsDashboard },
        React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.secHeader },
            React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.secTitleWrap },
                React.createElement("div", null,
                    React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.secTitle }, "Leads Intelligence"),
                    React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.secSub },
                        "All lead sources \u00B7 qualified vs junk \u00B7 ",
                        dateRange.label))),
            React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.secActions },
                React.createElement(DatePicker_1.default, { value: dateRange, onChange: setDateRange, maxDate: new Date() }),
                React.createElement("button", { className: LeadsIntelligence_module_scss_1.default.secondaryBtn }, "Connect Sources"),
                React.createElement("button", { className: LeadsIntelligence_module_scss_1.default.primaryBtn, onClick: fetchLeadData }, "\uD83D\uDD04 Refresh"))),
        React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.secHeader },
            React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.secTitleWrap },
                React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.secIcon, style: { background: "#ede9fe" } }, "\uD83C\uDFAF"),
                React.createElement("div", null,
                    React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.secTitle }, "Leads Intelligence"),
                    React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.secSub },
                        "All lead sources \u00B7 qualified vs junk \u00B7 ",
                        dateRange.label))),
            React.createElement("span", { className: "".concat(LeadsIntelligence_module_scss_1.default.sourceBadge, " ").concat(LeadsIntelligence_module_scss_1.default.badgeGreen) }, "\uD83D\uDCCA SharePoint Data")),
        loading && (React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.loadingBar },
            React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.loadingFill }))),
        React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.g4 }, KPI_CARDS.map(function (kpi, i) { return (React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.kpi, key: i },
            React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.kpiTop },
                React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.kpiIcon, style: { background: kpi.iconBg } }, kpi.icon),
                React.createElement("div", { className: "".concat(LeadsIntelligence_module_scss_1.default.kpiDelta, " ").concat(kpi.deltaType === "up" ? LeadsIntelligence_module_scss_1.default.deltaUp : LeadsIntelligence_module_scss_1.default.deltaFlat) }, kpi.deltaText)),
            React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.kpiLabel }, kpi.label),
            React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.kpiVal }, kpi.value),
            React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.kpiSub }, kpi.sub),
            React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.kpiAccent, style: { background: kpi.accentColor } }))); })),
        React.createElement("div", { className: "".concat(LeadsIntelligence_module_scss_1.default.g2, " ").concat(LeadsIntelligence_module_scss_1.default.mt) },
            React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.card },
                React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.cardHead },
                    React.createElement("div", null,
                        React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.cardTitle }, "Lead Volume by Source"),
                        React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.cardSub },
                            "Where leads are coming from \u00B7 ",
                            dateRange.label))),
                filtered.length > 0 ? (React.createElement(LeadSourceChart, { data: sourceCounts })) : (React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.emptyState }, "\uD83D\uDCED No leads found for selected range"))),
            React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.card },
                React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.cardHead },
                    React.createElement("div", null,
                        React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.cardTitle }, "Lead Quality Breakdown"),
                        React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.cardSub },
                            "Qualified vs Junk vs In Review \u00B7 ",
                            dateRange.label))),
                filtered.length > 0 ? (React.createElement(React.Fragment, null,
                    React.createElement(LeadQualityChart, { qualified: kpis.qualified, review: kpis.review, junk: kpis.junk }),
                    React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.statRow }, QUALITY_STATS.map(function (s, i) { return (React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.statBox, key: i },
                        React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.statVal, style: { color: s.color } }, s.value),
                        React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.statLbl }, s.label))); })))) : (React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.emptyState }, "\uD83D\uDCED No leads found for selected range")))),
        React.createElement("div", { className: "".concat(LeadsIntelligence_module_scss_1.default.g2, " ").concat(LeadsIntelligence_module_scss_1.default.mt) },
            React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.card },
                React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.cardHead },
                    React.createElement("div", null,
                        React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.cardTitle }, "Lead Source Breakdown"),
                        React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.cardSub },
                            "Incoming by channel \u00B7 ",
                            dateRange.label))),
                SOURCE_META_LIST.map(function (meta) { return (React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.leadStat, key: meta.key },
                    React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.leadIcon, style: { background: meta.iconBg } }, meta.icon),
                    React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.leadInfo },
                        React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.leadName }, meta.key),
                        React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.leadMeta }, meta.meta)),
                    React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.leadCount, style: { color: meta.countColor } }, sourceCounts[meta.key] > 0 ? sourceCounts[meta.key] : "—"))); })),
            React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.card },
                React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.cardHead },
                    React.createElement("div", null,
                        React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.cardTitle }, "Lead Detail Table"),
                        React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.cardSub },
                            filtered.length,
                            " lead",
                            filtered.length !== 1 ? "s" : "",
                            " \u00B7",
                            " ",
                            dateRange.label))),
                filtered.length === 0 ? (React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.emptyState }, "\uD83D\uDCED No leads found for the selected date range.")) : (React.createElement(React.Fragment, null,
                    React.createElement("table", { className: LeadsIntelligence_module_scss_1.default.tbl },
                        React.createElement("thead", null,
                            React.createElement("tr", null,
                                React.createElement("th", null, "Lead Name"),
                                React.createElement("th", null, "Source"),
                                React.createElement("th", null, "Service Interest"),
                                React.createElement("th", null, "Status"))),
                        React.createElement("tbody", null, filtered.slice(0, 10).map(function (row, i) {
                            var _a, _b, _c, _d;
                            return (React.createElement("tr", { key: i },
                                React.createElement("td", null,
                                    React.createElement("strong", null, row.leadName)),
                                React.createElement("td", null,
                                    React.createElement("span", { className: "".concat(LeadsIntelligence_module_scss_1.default.pill, " ").concat((_b = (_a = PILL_MAP[row.source]) === null || _a === void 0 ? void 0 : _a.source) !== null && _b !== void 0 ? _b : "") }, row.source)),
                                React.createElement("td", null, row.enquiry),
                                React.createElement("td", null,
                                    React.createElement("span", { className: "".concat(LeadsIntelligence_module_scss_1.default.pill, " ").concat((_d = (_c = PILL_MAP[row.status]) === null || _c === void 0 ? void 0 : _c.status) !== null && _d !== void 0 ? _d : "") }, row.status))));
                        }))),
                    filtered.length > 10 && (React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.uploadNote },
                        "+",
                        filtered.length - 10,
                        " more leads in this period")))),
                React.createElement("div", { className: LeadsIntelligence_module_scss_1.default.uploadNote }, "\uD83D\uDCE4 Data sourced from SharePoint \u00B7 Fields: Name \u00B7 Source \u00B7 Enquiry \u00B7 Status")))));
};
exports.default = LeadsIntelligenceDashboard;
//# sourceMappingURL=LeadsIntelligence.js.map