import { IListItems, IListItemUsingId, IAddList, IUpdateList, ISPList, IDetailsListGroup, ISPAttachments, ISPAttachment, IAttachDelete, ISPListChoiceField } from "./ISPServicesProps";
import { IItemAddResult } from "@pnp/sp/items";
import "@pnp/sp/webs";
declare const _default: {
    getAllUsers: () => Promise<any[]>;
    SPAddItem: (params: IAddList) => Promise<IItemAddResult>;
    SPUpdateItem: (params: IUpdateList) => Promise<IItemAddResult>;
    SPDeleteItem: (params: ISPList) => Promise<any>;
    SPReadItems: (params: IListItems) => Promise<any[]>;
    SPDetailsListGroupItems: (params: IDetailsListGroup) => Promise<any>;
    SPGetChoices: (params: ISPListChoiceField) => Promise<import("@pnp/sp/fields/types").IFieldInfo>;
    SPAddAttachments: (params: ISPAttachments) => Promise<void>;
    SPAddAttachment: (params: ISPAttachment) => Promise<import("@pnp/sp/attachments/types").IAttachmentAddResult>;
    SPGetAttachments: (params: ISPList) => Promise<any>;
    SPDeleteAttachments: (params: IAttachDelete) => Promise<void>;
    SPReadItemUsingId: (params: IListItemUsingId) => Promise<any[]>;
    batchInsert: (params: {
        ListName: string;
        responseData: any[];
    }) => Promise<any>;
    batchUpdate: (params: {
        ListName: string;
        responseData: any[];
    }) => Promise<any>;
    batchDelete: (params: {
        ListName: string;
        responseData: any[];
    }) => Promise<any>;
    SPReadAttachments: (params: IAttachDelete) => Promise<string>;
};
export default _default;
//# sourceMappingURL=SpServices.d.ts.map