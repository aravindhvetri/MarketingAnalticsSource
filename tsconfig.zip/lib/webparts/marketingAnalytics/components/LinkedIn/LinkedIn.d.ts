export default function LinkedInAnalytics(): JSX.Element;
//# sourceMappingURL=LinkedIn.d.ts.map