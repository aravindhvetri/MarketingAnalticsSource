import * as React from "react";
import type { IMarketingAnalyticsProps } from "./IMarketingAnalyticsProps";
export default class MarketingAnalytics extends React.Component<IMarketingAnalyticsProps> {
    constructor(prop: IMarketingAnalyticsProps, state: {});
    render(): React.ReactElement<IMarketingAnalyticsProps>;
}
//# sourceMappingURL=MarketingAnalytics.d.ts.map