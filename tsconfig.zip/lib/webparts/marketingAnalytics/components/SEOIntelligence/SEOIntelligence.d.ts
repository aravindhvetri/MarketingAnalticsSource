import * as React from "react";
export interface IKeyword {
    ID: number;
    Keyword: string;
    Clicks: number;
    Impressions: number;
    CTR: number;
    AvgPosition: number;
    Status: string;
    Date: string | null;
}
export interface ITopPage {
    ID: number;
    PageURL: string;
    Clicks: number;
    Impressions: number;
    CTR: number;
    AvgPosition: number;
    Date: string | null;
}
export interface IBacklinkSummary {
    ID: number;
    Metric: string;
    Value: string;
    Notes: string;
    Date: string | null;
}
declare const SeoIntelligenceDashboard: React.FC;
export default SeoIntelligenceDashboard;
//# sourceMappingURL=SEOIntelligence.d.ts.map