import * as React from "react";
export interface IGoogleAdsItem {
    Id: number;
    Date: string;
    CampaignName: string;
    Impressions: number;
    Clicks: number;
    Spend: number;
    CTR: number;
    Leads: number;
    CPL: number;
    ctrType: string;
    Status: string;
}
export interface IFacebookAdsItem {
    Id: number;
    CampaignName: string;
    Spend: number;
    Impressions: number;
    Clicks: number;
    CTR: number;
    Leads: number;
    CPL: number;
    Date: string;
    Status: string;
    Created?: string;
    Modified?: string;
}
export declare const PaidAdsPerformance: React.FC;
export default PaidAdsPerformance;
//# sourceMappingURL=PaidAds.d.ts.map