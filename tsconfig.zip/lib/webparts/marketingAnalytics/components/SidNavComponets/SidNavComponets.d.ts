import "../../../ExternalRef/CSS/ReportsStyle.css";
declare const SECTIONS_META: Record<string, {
    title: string;
    sub: string;
}>;
export interface ISidebarProps {
    activeSection: string;
    onNav: (id: string, title: string, sub: string) => void;
}
declare const Sidebar: ({ activeSection, onNav }: ISidebarProps) => JSX.Element;
export default Sidebar;
export { SECTIONS_META };
//# sourceMappingURL=SidNavComponets.d.ts.map