import * as React from "react";
export interface ICampaign {
    id: number;
    name: string;
    date: Date;
    sent: number;
    opened: number;
    clicked: number;
    bounced: number;
    unsubscribed: number;
    leads: number;
}
export interface IEmailCampaign {
    ID: number;
    CampaignName: string;
    CampaignId: string;
    ReportDate: string | null;
    Date: string | null;
    Sent: number;
    Opened: number;
    Clicked: number;
    Bounced: number;
    UnSubscribed: number;
    Leads: number;
    OpenRate: number;
    CTR: number;
}
declare const EmailCampaignsDashboard: React.FC;
export default EmailCampaignsDashboard;
//# sourceMappingURL=EmailCampaigns.d.ts.map