import * as React from "react";
declare const OverViewDashboard: React.FC;
export default OverViewDashboard;
//# sourceMappingURL=OverViewDashboard.d.ts.map