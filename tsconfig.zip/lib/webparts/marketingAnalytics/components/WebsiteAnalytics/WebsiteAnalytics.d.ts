export declare function filterByDateRange<T extends {
    Date: string | Date | null;
}>(items: T[], startDate: Date, endDate: Date): T[];
declare const WebsiteAnalytics: () => JSX.Element;
export default WebsiteAnalytics;
//# sourceMappingURL=WebsiteAnalytics.d.ts.map