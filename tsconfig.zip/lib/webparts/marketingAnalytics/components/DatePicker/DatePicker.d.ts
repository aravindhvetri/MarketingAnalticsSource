import * as React from "react";
export interface DateRange {
    startDate: Date;
    endDate: Date;
    label: string;
}
export interface DateRangePickerProps {
    value?: DateRange;
    onChange?: (range: DateRange) => void;
    maxDate?: Date;
    minDate?: Date;
}
declare const DateRangePicker: React.FC<DateRangePickerProps>;
export default DateRangePicker;
//# sourceMappingURL=DatePicker.d.ts.map