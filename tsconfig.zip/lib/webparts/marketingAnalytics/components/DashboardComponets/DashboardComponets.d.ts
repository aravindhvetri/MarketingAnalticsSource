import "../../../ExternalRef/CSS/ReportsStyle.css";
declare const MainComponent: (props: any) => JSX.Element;
export default MainComponent;
//# sourceMappingURL=DashboardComponets.d.ts.map