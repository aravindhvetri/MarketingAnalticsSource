import * as React from "react";
export interface ILead {
    id: number;
    date: Date | null;
    leadName: string;
    phoneNumber: string;
    companyName: string;
    email: string;
    enquiry: string;
    source: string;
    campaign: string;
    country: string;
    notes: string;
    status: string;
}
declare const LeadsIntelligenceDashboard: React.FC;
export default LeadsIntelligenceDashboard;
//# sourceMappingURL=LeadsIntelligence.d.ts.map